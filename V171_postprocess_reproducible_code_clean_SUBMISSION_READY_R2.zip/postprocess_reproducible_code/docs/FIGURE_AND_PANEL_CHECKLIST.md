# figure and panel checklist

## Main figures

### Figure 1 | Evidence foundation, claim boundaries and staged contraction
- **1a** Database attrition: retained records at registered screening stages.
- **1b** Evidence provenance alluvial: evidence streams to chemistry families.
- **1c** Candidate evidence matrix: corrosion, cycling/phase, containment, replication and data completeness, with separate application-count and exact-database-link strips.
- **1d** Claim-boundary map: evidence score across database-validated, exact-measured, commercial-benchmark and derived/predicted classes.
- **1e** Service contraction: registered → complete service → evidence-qualified → any selected → ≥1% selected; model-output boundary shown only as a boundary annotation.

### Figure 2 | Strict service-resolved decision landscape
- **2a** Service windows and candidate temperature ranges.
- **2b** Complete-service classification composition.
- **2c** Strict-complete probability versus evidence-qualified selection frequency.
- **2d** Conditional energy-density 5–95% forest.
- **2e** Ranking-pathway composition: stable leader, service-only, evidence-only, joint change and no bounded selection.

### Figure 3 | Gradient regimes and application-dependent switching
- **3a** Stacked shares of robust, conditional and no-bounded-access states across all services.
- **3b** Coverage-threshold no-selection response for Coal, CSP and Industrial heat.
- **3c** Evidence-threshold breakpoints in expected strict-complete candidate count with numerical endpoint badges.
- **3d** Industrial preference response: leader gap and normalized entropy.
- **3e** Service-level regime archetype matrix; repeated flat services compressed.

### Figure 4 | Uncertainty-aware Pareto structure
- **4a** Performance–evidence Pareto plane with 90% joint uncertainty ellipses.
- **4b** Bootstrap Pareto-membership frequency forest.
- **4c** Dominance-mechanism matrix.
- **4d** Robust-Pareto, strict-eligibility and ≥1%-selection intersections.
- **4e** Cross-service robust-Pareto and formal-selection breadth.
- **4f** Retained, redirected and no-selection strict-layer transition shares.

### Figure 5 | Uncertainty-source attribution and structural bottlenecks
- **5a** TES service to decision-uncertainty structure alluvial.
- **5b** Continuous decision-margin Shapley variance attribution.
- **5c** Categorical selected-state Shapley information attribution.
- **5d** Service coverage lost to registered property domains.
- **5e** Atomic evidence unlock contribution.
- **5f** Seven service-specific evidence-closure-depth responses.
- **5g** Pearson–Spearman performance–evidence dependence and near-zero inset.

### Figure 6 | Decision-boundary back-tracing and evidence priorities
- **6a** Current state → precedence-valid action → endpoint alluvial.
- **6b** Complete minimum admissible action-set matrix for scientifically evaluable candidate–service pairs.
- **6c** Registered action decision-benefit forest.
- **6d** Ordinal evidence burden versus decision benefit.
- **6e** Candidate selection-frequency redistribution for |Δ| ≥1%.
- **6f** Service-level research-priority and stopping-rule composition.

## Supplementary figures

### Supplementary Figure 1 | Database curation and chemistry-family structure
- **S1a** Formula-system component count versus composition-record count.
- **S1b** Raw-database versus curated-registry chemistry-family composition.
- **S1c** Non-zero lower-bound application compatibility heatmap.

### Supplementary Figure 2 | Provenance linkage and atomic credibility
- **S2a** Candidate database/provenance match lollipop with numerical match badges.
- **S2b** Candidate atomic-credibility heatmap.

### Supplementary Figure 3 | Unique thermophysical profiles
- **S3** Column-normalized deterministic thermophysical profile heatmap after exact-duplicate collapse.

### Supplementary Figure 4 | Pairwise performance and material-cost boundary
- **S4a** Pairwise energy-density superiority probabilities with endpoint badges.
- **S4b** Conditional raw-material-cost 5–95% forest with median badges.

### Supplementary Figure 5 | Complete-service overclaim penalty
- **S5** Partial-overlap energy-overclaim lollipop with overclaim and coverage annotations.

### Supplementary Figure 6 | Threshold sensitivity and convergence
- **S6a** Full seven-service 630-state coverage–evidence regime registry.
- **S6b** Evidence-threshold response of expected strict-complete candidate count.
- **S6c** Independent Monte Carlo convergence of modal-frequency error.

### Supplementary Figure 7 | Atomic evidence interval profiles
- **S7a** Corrosion credibility intervals.
- **S7b** Cycling/phase credibility intervals.
- **S7c** Containment credibility intervals.

### Supplementary Figure 8 | Omission sensitivity
- **S8a** Candidate-omission decisiveness scatter.
- **S8b** Exact source-omission outcome-group heatmap.

### Supplementary Figure 9 | Credibility shortfall and model sensitivity
- **S9a** Unique credibility-shortfall profile heatmap.
- **S9b** Non-zero model-structure sensitivity.

### Supplementary Figure 10 | Readiness and candidate archetypes
- **S10a** Deduplicated readiness profiles.
- **S10b** PCM strict-complete probabilities.
- **S10c** Bounded-candidate multiplicity.
- **S10d** Exploratory candidate archetype clusters.

### Supplementary Figure 11 | Complementary evidence-action diagnostics
- **S11a** Registered evidence-action ordinal burden.
- **S11b** Action-to-evidence-dimension closure matrix.
- **S11c** Non-zero gate-pair interaction diagnostics.
- **S11d** Programme non-additivity and complementarity.
- **S11e** Favourable, adverse and interpretation-boundary outcome registry.


## Global submission typography and layout checks
- Legends requested above axes are single-row and outside data fields.
- Obsolete legend reserve space is removed.
- Lollipop/forest endpoints use consistent numerical badges where scientifically useful.
- Chemical formulae and units use mathtext subscripts/superscripts, including sCO$_2$, MgCl$_2$, kWh m$^{-3}$ and kWh$_{th}^{-1}$.
- Structurally flat or repeated services are compressed rather than redrawn.
- Main and supplementary figures answer distinct questions; full-detail scans remain supplementary.
- Registered DAG semantics are explicit: containment qualification requires corrosion compatibility; independent replication requires data completeness; atomic cycling can begin independently within a defensible service window.
