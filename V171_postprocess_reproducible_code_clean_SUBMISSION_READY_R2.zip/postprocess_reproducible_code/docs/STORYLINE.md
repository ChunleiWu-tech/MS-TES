# scientific storyline

Evidence provenance and staged contraction → strict service-resolved formal decisions → threshold and preference boundaries → uncertainty-aware non-compensatory Pareto structure → separated continuous/categorical attribution and structural bottlenecks → precedence-constrained research priorities and stopping rules.

The strict-complete, evidence-bounded and ≥1% formal-selection layer remains frozen. submission changes only figure geometry, annotations, legend placement, chemical/unit typography and non-redundant editorial synthesis. No formal scientific recommendation is upgraded or removed.
