# Typography policy

- All ordinary figure text must resolve to the system font **Arial**.
- The package does not contain or distribute font files.
- Matplotlib mathtext is used for chemical and mathematical subscripts/superscripts, including sCO$_2$, NaNO$_3$, Na$_2$CO$_3$, kWh m$^{-3}$ and W m$^{-1}$ K$^{-1}$.
- The environment check fails when Arial is unavailable. `ALLOW_ARIAL_FALLBACK=1` exists only for CI smoke tests and must not be used for submission rendering.
- PDF output uses embedded TrueType fonts (`pdf.fonttype = 42`).
