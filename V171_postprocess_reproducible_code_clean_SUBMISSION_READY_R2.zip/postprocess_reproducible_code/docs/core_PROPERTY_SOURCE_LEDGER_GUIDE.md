# core property-to-source evidence ledger

## Authoritative evidence file

`data/provenance/core_property_source_ledger.csv` is the machine-readable and Git-diffable source of truth. The Excel workbook in `docs/` is a human-readable mirror generated from the same records.

Each of the ten candidate systems has one row for each of nine property groups: composition, melting temperature, practical upper temperature, specific heat, density, thermal conductivity, viscosity, latent heat and reported energy density.

For every implemented field the ledger records the current code value or equation, the exact source ID, title, URL, page/table/figure/equation locator, source-valid temperature interval, unit and temperature basis, transformation or safety margin, model role and the maximum article claim supported by that evidence.

## Scientific eligibility rule

Thermal stability and phase coverage do not extend the validity range of a thermophysical property. For a sensible-heat service, strict-complete eligibility requires both:

1. complete liquid-phase service coverage after the registered freeze margin; and
2. complete joint source-valid coverage of the specific-heat and density models over the same service interval.

Thermal conductivity is evaluated only where its registered source-valid range contains the service reference temperature. A property outside its source-valid range may appear only in a separately labelled diagnostic sensitivity and may not enter strict-complete selection.

## Exact-composition freeze

- QNCC retains the directly reported average liquid heat capacity of 1.56 J g-1 K-1; the paper's temperature equation is a registered model-form sensitivity.
- NaCl-KCl-CaCl2 uses the exact 0.408/0.075/0.517 mol-fraction property set from one paper: 496.3 °C melting temperature, 171.5 J g-1 latent heat, 0.80 J g-1 K-1 average liquid heat capacity and the matching density equation.
- The binary Na2CO3-Li2CO3 candidate is frozen at 51/49 mol%, equivalent to 42.05/57.95 wt%, and uses the binary-carbonate source rather than the ternary LiF paper.
- Na2CO3-Li2CO3-LiF S1 retains its directly measured 413 J g-1 latent heat. Its family-predicted sensible heat capacity is used only in the separate +50 K opportunity diagnostic.
- MgCl2-KCl-NaCl uses the direct exact-composition DSC mean of 401.4 °C as the primary melting input; the MSD-TP value of 382.85 °C is retained only as a sensitivity.

## Validation

Run before every full recompute:

```bash
python src/build_property_source_ledger.py
python src/validate_property_source_ledger.py
```

The validator checks the 10 x 9 property coverage, source referential integrity, source-valid temperature domains, exact-composition decisions and claim boundaries. All rows must have `review_status = CLOSED` for release.

## Source-count interpretation

The extended source register contains 32 IDs: 31 external literature, database or official-source entries and one repository-local declaration ID (`TES_INTERNAL`). The internal ID records predictions, derivations, analytical boundaries and missing-by-design fields; it must not be counted or described as an external publication. Database-internal references remain record-level provenance and are not added to this top-level count.
