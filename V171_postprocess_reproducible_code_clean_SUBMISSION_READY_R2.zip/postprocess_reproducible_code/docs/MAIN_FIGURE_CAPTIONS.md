# main figures

## Fig. 1 — Evidence foundation, claim boundaries and staged contraction
**a**, database attrition lollipop. **b**, evidence-stream to chemistry-family alluvial. **c**, candidate-level atomic evidence matrix with separate application-count and exact-link strips. **d**, registered evidence score by claim class. **e**, service-resolved contraction with a single-row legend above the axis and an embedded model-output-boundary statement.

## Fig. 2 — Strict service-resolved decision landscape
**a**, service windows and candidate temperature ranges with the legend above the x axis. **b**, complete-service classification shares with reduced unused top space. **c**, strict-complete probability versus formal selection frequency, with the evidence-locked PCM annotation moved left and connected by a leader. **d**, conditional energy-density intervals. **e**, draw-level ranking-pathway shares.

## Fig. 3 — Gradient regimes and application-dependent switching
**a**, compact stacked shares of all registered coverage–evidence states. **b**, coverage-threshold response for the three non-degenerate services. **c**, evidence-threshold breakpoints in the expected strict-complete candidate count, with endpoint badges. **d**, industrial preference response with the legend outside the data field. **e**, service-level regime archetypes; structurally flat services are compressed rather than repeated.

## Fig. 4 — No universal salt: uncertainty-aware non-compensatory Pareto structure
**a**, performance–evidence plane with 90% joint ellipses and reference front segments. **b**, bootstrap Pareto-membership forest. **c**, dominance-mechanism matrix. **d**, colour-distinguished Pareto/eligibility/selection intersections. **e**, widened cross-service robust-Pareto and formal-selection breadth. **f**, widened strict-layer transition summary.

## Fig. 5 — Uncertainty-source attribution and structural bottlenecks
**a**, service-to-uncertainty-structure alluvial. **b**, continuous-margin Shapley variance shares. **c**, categorical-state Shapley information shares. **d**, property-domain coverage losses with endpoint badges. **e**, atomic evidence unlock contributions with endpoint badges. **f**, seven service-specific evidence-closure-depth responses showing the median retained frequency and registered minimum–maximum range. **g**, performance–evidence dependence with the PCM500 label displaced from the data point.

## Fig. 6 — Decision-boundary back-tracing and evidence investment priorities
**a**, precedence-valid state–action–endpoint alluvial. **b**, complete minimum admissible action-set matrix for scientifically evaluable candidate–service pairs. **c**, compact action-benefit forest with shortened action labels, widened x range and endpoint badges inside the axis. **d**, ordinal burden–gain map. **e**, candidate selection-frequency redistribution for registered effects with |Δ| ≥1%. **f**, service-level research-priority and stopping-rule summary.
