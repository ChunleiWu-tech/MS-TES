# core scientific freeze decisions

## Changes that alter numerical results and therefore require a full recompute

1. Strict-complete sensible eligibility now uses source-valid Cp-density coverage rather than phase stability alone. This prevents KNC in the 500-700 °C sCO2 service and quaternary nitrate S7 in the 380-550 °C coal service from being treated as fully measured over unvalidated temperature ranges.
2. Sensible mass and volumetric energy densities are analytically integrated over the supported service interval. The former midpoint-product implementation is retained only as historical context and is not used in the release calculation.
3. NaCl-KCl-CaCl2 is aligned to one exact-composition source set, including latent heat 171.5 J g-1 and the matching density equation.
4. The 51/49 mol% binary carbonate is converted consistently to 42.05/57.95 wt% for component-cost calculations.
5. HITEC uses a temperature-dependent density correlation. HITEC XL uses the registered 1.45 J g-1 K-1 review benchmark rather than an unnecessary family prediction.
6. MgCl2-KCl-NaCl uses the direct exact-composition DSC melting value as primary; the database value is a sensitivity.

## Values deliberately retained

- QNCC average liquid Cp = 1.56 J g-1 K-1 and latent heat = 111.9 J g-1.
- Na2CO3-Li2CO3-LiF S1 latent heat = 413 J g-1.
- Solar Salt benchmark values remain harmonized benchmark inputs, with all numerical sources now registered at property level.

## Interpretation boundary

A decomposition temperature, low mass loss or corrosion observation establishes stability/compatibility evidence only. It does not validate Cp, density, viscosity or thermal conductivity outside the measured or fitted temperature interval. Predicted or review-average properties remain explicitly labelled and cannot be described as direct exact-composition measurements.

## Release rule

Because the changes above alter service eligibility, energy density, cost proxies and selection frequencies, no predecessor numerical output may be reused. The full upstream and postprocess workflows must be run from empty generated-output directories. A submission freeze is valid only when all upstream and postprocess validation summaries report PASS.
