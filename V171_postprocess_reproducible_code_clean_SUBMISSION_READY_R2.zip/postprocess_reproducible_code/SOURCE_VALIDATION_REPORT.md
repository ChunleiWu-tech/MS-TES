# Source validation report

## Registered-data integration run

- Upstream contract: PASS against the synchronized registered 20,000-draw outputs.
- Renderer status: PASS.
- Main figures: 6.
- Supplementary figures: 11.
- Post-processing validation: 30/30 checks passed.
- Final release contract: 15/15 checks passed.
- Scientific tables and decision rules changed: no.

## Fig. 1a stage audit

```csv
display_label,screen_step,retained_count
Raw database,Raw MSD-TP composition records,976
Melting data,Melting temperature available,937
Service-compatible,Application-specific melting/phase lower-bound compatibility,250
Minimum coverage,Minimum thermophysical coverage (melting + at least two fields),74
```

The renderer reads exact `screen_step` names and fails if a required stage is absent or duplicated. Independent validation also requires the frozen retained-record sequence 976 → 937 → 250 → 74.

## Environment note

The integration run in this container used the documented CI overrides because CPython 3.12 and Arial are not installed here. Package versions matched the lock file. Formal submission rendering remains fail-closed on CPython 3.12 and real system Arial; no font files are distributed.
