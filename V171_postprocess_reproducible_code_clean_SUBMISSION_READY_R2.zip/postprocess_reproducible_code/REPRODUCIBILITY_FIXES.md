# Reproducibility corrections incorporated

This clean post-processing package reproduces the final six-main-figure and eleven-supplementary-figure submission set from registered 20,000-draw upstream tables.

- Fig. 1a now maps display labels to exact registered `screen_step` names rather than positional indices. The frozen sequence is 976 → 937 → 250 → 74.
- A dedicated `fig1a_stage_mapping_audit.csv` is generated and both renderer QA and release validation fail closed if labels, stages or counts differ.
- Supplementary Fig. 12 has been removed from the renderer, contact sheet, source map, documentation, inventory and release contract; reproducibility hashes remain QC artefacts rather than scientific figures.
- Synchronisation rejects upstream outputs unless the registered Monte Carlo count is exactly 20,000.
- Synchronisation reads the canonical `UPSTREAM_RELEASE_STATUS.json` and accepts `submission_UPSTREAM_STATUS.json` only as a verified identical compatibility alias.
- The renderer preserves the upstream-contract status produced earlier in the same run.
- Ordinary publication text strictly uses system Arial. No font files are bundled.
- Chemical formulae, units, subscripts and superscripts use Matplotlib custom mathtext with Arial as the principal family and STIX only as a missing-glyph fallback.
- Every generated PDF is audited for embedded Arial and rejected if Arimo, Liberation Sans or DejaVu Sans silently replaces it in a formal render.
- The source-only package manifest excludes generated tables, images and QC.

The scientific tables, 20,000-draw results, decision rules and conclusions are unchanged.
