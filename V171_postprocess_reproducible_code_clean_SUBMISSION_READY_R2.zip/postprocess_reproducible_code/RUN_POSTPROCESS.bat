@echo off
setlocal
cd /d "%~dp0"
if "%TES_PYTHON%"=="" set "TES_PYTHON=%CD%\.venv\Scripts\python.exe"
if not exist "%TES_PYTHON%" (echo Run SETUP_ENV.bat first, or set TES_PYTHON.& exit /b 2)
set "PYTHONFAULTHANDLER=1"
set "PYTHONUNBUFFERED=1"
set "OMP_NUM_THREADS=1"
set "OPENBLAS_NUM_THREADS=1"
set "MKL_NUM_THREADS=1"
set "NUMEXPR_NUM_THREADS=1"
for %%S in (clean_generated_outputs.py check_env.py check_upstream_contract.py run_postprocess.py validate_postprocess.py validate_release_contract.py write_package_manifest.py) do (
  echo.
  echo === Running %%S ===
  "%TES_PYTHON%" -X faulthandler -u "src\%%S" || exit /b 1
)
echo.
echo Post-processing completed successfully.
endlocal
