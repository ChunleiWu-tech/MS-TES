@echo off
setlocal
cd /d "%~dp0"
set "UPSTREAM_ROOT=%~1"
if "%UPSTREAM_ROOT%"=="" set "UPSTREAM_ROOT=..\upstream_reproducible_code"
if not exist "%UPSTREAM_ROOT%\outputs\tables" (echo Upstream outputs not found.& exit /b 2)
set "VERIFY_PY=%UPSTREAM_ROOT%\.venv\Scripts\python.exe"
if not exist "%VERIFY_PY%" (echo Upstream virtual environment not found. Complete SETUP_ENV.bat and RUN_FULL_RECOMPUTE.bat first.& exit /b 2)
"%VERIFY_PY%" "%CD%\src\verify_upstream_sync.py" "%UPSTREAM_ROOT%" || exit /b 2
if exist outputs\tables rmdir /s /q outputs\tables
if exist outputs\upstream_qc rmdir /s /q outputs\upstream_qc
mkdir outputs\tables outputs\upstream_qc
xcopy /e /i /y "%UPSTREAM_ROOT%\outputs\tables" outputs\tables >nul
xcopy /e /i /y "%UPSTREAM_ROOT%\outputs\qc" outputs\upstream_qc >nul
echo Registered 20,000-draw upstream outputs synchronized.
endlocal
