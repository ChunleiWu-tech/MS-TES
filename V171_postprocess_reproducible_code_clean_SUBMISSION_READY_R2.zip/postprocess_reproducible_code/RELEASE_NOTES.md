# Clean release notes

- Corrected Fig. 1a label-to-stage mapping using exact `screen_step` names.
- Added fail-closed Fig. 1a QA for the frozen counts 976, 937, 250 and 74.
- Removed Supplementary Fig. 12 from the scientific figure workflow; the final inventory is six main and eleven supplementary figures.
- Updated the public annotation to **model-estimated values** and retained their exclusion from formal evidence-bounded selection.
- No upstream scientific table, model assumption, decision rule or manuscript conclusion was changed.
- Disabled the obsolete standalone support renderer; the sole formal renderer is `src/run_postprocess.py`, producing six main and eleven supplementary figures.

## V171-R2 compatibility note

- This renderer is contract-compatible with the V171-R2 upstream categorical-grouping correction.
- The upstream correction does not change table schemas, scientific values or figure-data contracts.
- No post-processing science or visual encoding changed in this release.

## V171-R2 clean-package correction

- Renamed the version-numbered compatibility evidence file to `COMPATIBILITY_VALIDATION.json`, removing the sole artefact that triggered the clean-package validation gate.
- Regenerated all package manifests and SHA-256 records after the rename.
- Rendering, figure inventory, scientific values and visual encodings are unchanged.
