#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON_BOOTSTRAP="${PYTHON_BOOTSTRAP:-python3.12}"
command -v "$PYTHON_BOOTSTRAP" >/dev/null 2>&1 || { echo "CPython 3.12 is required. Set PYTHON_BOOTSTRAP." >&2; exit 2; }
"$PYTHON_BOOTSTRAP" - <<'PY'
import sys
raise SystemExit(0 if sys.version_info[:2]==(3,12) else f'CPython 3.12 required, found {sys.version}')
PY
if [[ -x .venv/bin/python ]] && ! .venv/bin/python - <<'PY'
import sys
raise SystemExit(0 if sys.version_info[:2]==(3,12) else 1)
PY
then rm -rf .venv; fi
[[ -x .venv/bin/python ]] || "$PYTHON_BOOTSTRAP" -m venv .venv
export PIP_DISABLE_PIP_VERSION_CHECK=1 PYTHONUTF8=1
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install --only-binary=:all: --requirement requirements-lock.txt
.venv/bin/python -u src/check_env.py
echo "Post-processing environment is ready: $PWD/.venv"
