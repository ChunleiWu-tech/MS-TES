# core input data dictionary

- `core_candidate_property_registry.csv`: one row per candidate salt; property correlations, uncertainty ranges and source identifiers.
- `core_candidate_scenario_membership.csv`: application-specific candidate membership.
- `core_corrosion_evidence_registry.csv`: corrosion-evidence tier, bounded claim class, burden range and traceable sources. The `evidence_score` field is an ordinal evidence-adequacy index used only after hard gates; it is not a material-performance score.
- `core_literature_validation_tiers.csv`: independent database or benchmark-validation tier.
- `core_component_cost_supply_safety_proxy.csv`: broad component price and hazard ranges for sensitivity only.
- `core_mixture_cost_overrides.csv`: literature mixture-price cross-checks where available.
- `core_authoritative_source_registry.csv`: DOI or official-source trace.

Raw MSD-TP and MSD-TC snapshots are preserved under `data/raw_databases/`. MSD-TP supports thermophysical validation; MSD-TC is used only as thermochemical and phase context.

## Property validity and provenance fields

The candidate-property registry separately records `cp_Tmin_C/cp_Tmax_C`, `rho_Tmin_C/rho_Tmax_C`, `k_Tmin_C/k_Tmax_C` and analogous model-basis fields. These are source-valid model domains, not decomposition limits. For sensible services, strict-complete thermophysical eligibility is calculated from the joint Cp-density intersection with the physically liquid service interval.

`data/provenance/core_property_source_ledger.csv` is the Git-diffable property-level evidence record. It maps each of the ten candidates and nine property groups to the exact implementation fields, primary source, locator, unit, source/model validity range, transformation and permitted article claim. The Excel file under `docs/` is a human-readable mirror and is not the machine-readable authority.

For latent services, `latent_J_g` is the primary ranking input. Predicted-family heat capacity is used only by the isolated fixed-50-K opportunity diagnostic and is not represented as an exact-composition liquid measurement.
