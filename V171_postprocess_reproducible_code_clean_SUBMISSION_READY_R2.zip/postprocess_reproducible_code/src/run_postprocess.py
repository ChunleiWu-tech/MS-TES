from __future__ import annotations

from pathlib import Path
import argparse
import json
import math
import shutil
import textwrap
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm, LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle, Ellipse, FancyBboxPatch
from PIL import Image

import certified_figure_support as L

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT/'outputs'/'tables'
MAIN = ROOT/'outputs'/'main_figures'
SUPP = ROOT/'outputs'/'supplementary_figures'
CONTACT = ROOT/'outputs'/'contact_sheets'
QA = ROOT/'outputs'/'qa'
QC = ROOT/'outputs'/'qc'
DOCS = ROOT/'docs'
for p in [MAIN,SUPP,CONTACT,QA,QC,DOCS]: p.mkdir(parents=True,exist_ok=True)

V='submission'; BASE='core'; STAT='statistical'
SERVICE_ORDER=L.SCENARIOS; SERVICE={s:L.scenario_code(s) for s in L.SCENARIOS}; SCOL=L.SCENARIO_COLOR

# One active visual grammar. Arial is mandatory for the submission render.
# ALLOW_ARIAL_FALLBACK=1 is reserved for non-submission CI smoke tests.
import os
try:
    mpl.font_manager.findfont('Arial', fallback_to_default=False)
    _TEXT_FONT='Arial'
except Exception:
    if os.environ.get('ALLOW_ARIAL_FALLBACK','0')!='1':
        raise RuntimeError('Arial is required. Install Arial as a system font; no font files are bundled.')
    _TEXT_FONT='Liberation Sans'
mpl.rcParams.update({
    'font.family':_TEXT_FONT,'font.sans-serif':[_TEXT_FONT],
    'mathtext.fontset':'custom','mathtext.rm':_TEXT_FONT,'mathtext.it':_TEXT_FONT+':italic','mathtext.bf':_TEXT_FONT+':bold','mathtext.fallback':'stix','mathtext.default':'regular',
    'axes.unicode_minus':False,'font.size':8.0,'axes.labelsize':7.1,
    'xtick.labelsize':6.5,'ytick.labelsize':6.5,'legend.fontsize':6.3,
    'axes.linewidth':.62,'xtick.major.width':.52,'ytick.major.width':.52,
    'xtick.direction':'out','ytick.direction':'out','pdf.fonttype':42,'ps.fonttype':42,
    'figure.facecolor':'white','axes.facecolor':'white','savefig.dpi':300,
})

# Rebind only the certified helper/supplementary module. No decision_boundary→statistical→prior release→prior release call chain is used.
L.VERSION=V; L.ROOT=ROOT; L.TABLES=TABLES; L.MAIN=MAIN; L.SUPP=SUPP; L.CONTACT=CONTACT; L.QC=QC; L.QA=QA; L.DOCS=DOCS

NAVY=L.NAVY; BLUE=L.BLUE; PALE_BLUE=L.PALE_BLUE; OLIVE=L.OLIVE; MUSTARD=L.MUSTARD
TERRACOTTA=L.TERRACOTTA; ROSE_LIGHT=L.ROSE_LIGHT; ROSE=L.ROSE; BURGUNDY=L.BURGUNDY
CREAM=L.CREAM; INK=L.INK; MID_GREY=L.MID_GREY; LIGHT_GREY=L.LIGHT_GREY; VERY_LIGHT=L.VERY_LIGHT
NEUTRAL=L.NEUTRAL; MAIN_W=2126/300
L.MAIN_W=MAIN_W; L.SUPP_W=MAIN_W

FIGURE_RECORDS=[]

def read(stem:str, version:str|None=None, **kwargs)->pd.DataFrame:
    versions=[version] if version else [V,STAT,BASE]
    for ver in versions:
        if ver is None: continue
        p=TABLES/f'{ver}_{stem}.csv'
        if p.exists(): return pd.read_csv(p,**kwargs)
    raise FileNotFoundError(f'No table found for {stem} under {versions}')

def short_id(value:str)->str:
    value=str(value)
    mapping={
        'solar_salt_ss60':'Solar Salt','knc':'KNC','qncc':'QNCC','mgcl_kcl_nacl':'MgCl$_2$ mix',
        'nkca':'NKCA','pcm_lif_s1':'Carbonate–LiF','pcm_binary_carbonate':'Binary carbonate',
        'hitec':'HITEC','hitec_xl':'HITEC XL','quat_s7':'Nitrate S7','none':'No selection','__NO_SELECTION__':'No selection'
    }
    return mapping.get(value,L.short_candidate(value))

def panel(ax,letter,x=-.075,y=1.055):
    ax.text(x,y,letter,transform=ax.transAxes,fontsize=9.1,fontweight='bold',ha='left',va='top',clip_on=False)

def value_badge(ax,x,y,text,dx=6,dy=0,ha='left',va='center',color=INK,fc='white',ec=None,clip_on=True,zorder=8,arrow=False,fontsize=5.15):
    if ec is None: ec=color
    arrowprops=dict(arrowstyle='-',color=ec,lw=.48,shrinkA=1,shrinkB=2) if arrow else None
    return ax.annotate(str(text),(x,y),xytext=(dx,dy),textcoords='offset points',ha=ha,va=va,
                fontsize=fontsize,fontweight='bold',color=color,clip_on=clip_on,zorder=zorder,
                bbox=dict(boxstyle='round,pad=.16',fc=fc,ec=ec,lw=.48,alpha=.96),arrowprops=arrowprops)

def outside_note(ax,text,x=.98,y=1.08,ha='right'):
    ax.text(x,y,text,transform=ax.transAxes,ha=ha,va='bottom',fontsize=5.0,color=MID_GREY,clip_on=False)

def clean(ax,grid=None):
    for sp in ax.spines.values(): sp.set_visible(True); sp.set_color(INK); sp.set_linewidth(.60)
    if grid: ax.grid(axis=grid,color=LIGHT_GREY,lw=.45,zorder=0)
    ax.set_axisbelow(True)

def barh_headroom(ax,n,extra=.75): ax.set_ylim(-.5,max(.5,n-.5+extra))

def top_legend(ax,handles,ncol=3,anchor=(.5,1.13),**kwargs):
    return ax.legend(handles=handles,ncol=ncol,loc='upper center',bbox_to_anchor=anchor,frameon=False,
                     handlelength=1.0,columnspacing=.55,handletextpad=.28,borderaxespad=0,**kwargs)


def compact_service_label(s):
    return {'coal_flexibility_storage':'Coal','csp_sensible_storage':'CSP','industrial_medium_heat':'Ind.',
            'sco2_high_temperature_storage':r'sCO$_2$','pcm_target_350C':'PCM350',
            'pcm_target_425C':'PCM425','pcm_target_500C':'PCM500'}.get(str(s),str(s))

def save(fig,num,title,sources,supp=False):
    out=SUPP if supp else MAIN; prefix='Supp_Fig' if supp else 'Fig'; stem=f'{V}_{prefix}{num}'
    png=out/f'{stem}.png'; pdf=out/f'{stem}.pdf'
    fig.savefig(png,dpi=300,facecolor='white',bbox_inches=None,pad_inches=0)
    fig.savefig(pdf,facecolor='white',bbox_inches=None,pad_inches=0,metadata={'Creator':'submission clean postprocess','CreationDate':None,'ModDate':None})
    with Image.open(png) as im:
        width,height=im.size
    FIGURE_RECORDS.append({'figure':f'{prefix}{num}','title':title,'width_px':width,'height_px':height,'aspect_ratio':width/height,'source_tables':';'.join(sources)})
    plt.close(fig)

def ellipse90(ax,r,color):
    if not np.isfinite(r.ellipse90_major_radius) or not np.isfinite(r.ellipse90_minor_radius): return
    e=Ellipse((r.representative_performance_score,r.representative_credibility_score),
              width=2*r.ellipse90_major_radius,height=2*r.ellipse90_minor_radius,angle=r.ellipse90_angle_deg,
              facecolor=color,edgecolor=color,alpha=.12,lw=.65,zorder=1)
    ax.add_patch(e)

def candidate_color(sid):
    return {'solar_salt_ss60':NAVY,'knc':ROSE,'qncc':MUSTARD,'mgcl_kcl_nacl':TERRACOTTA,'nkca':OLIVE,
            'pcm_lif_s1':ROSE_LIGHT,'pcm_binary_carbonate':BURGUNDY,'hitec':BLUE,'hitec_xl':CREAM,'quat_s7':'#A48B55'}.get(str(sid),MID_GREY)

# ------------------------------ FIGURE 1 ---------------------------------
def fig1():
    dbfun=read('database_to_shortlist_transition'); lit=read('literature_evidence_flow')
    ready=read('candidate_readiness_profile'); scope=read('candidate_scope_and_inclusion_audit')
    contract=read('deployability_contraction'); curated=read('curated_candidate_registry_summary')
    fig=plt.figure(figsize=(MAIN_W,7.55),constrained_layout=True)
    gs=fig.add_gridspec(3,2,height_ratios=[1.00,1.18,1.04],hspace=.075,wspace=.055)
    axa=fig.add_subplot(gs[0,0]); axb=fig.add_subplot(gs[0,1]); axc=fig.add_subplot(gs[1,0]); axd=fig.add_subplot(gs[1,1]); axe=fig.add_subplot(gs[2,:])

    # a — high-density lollipop attrition, adapted from the supplied template.
    panel(axa,'a')
    stage_specs=[
        ('Raw database','Raw MSD-TP composition records'),
        ('Melting data','Melting temperature available'),
        ('Service-compatible','Application-specific melting/phase lower-bound compatibility'),
        ('Minimum coverage','Minimum thermophysical coverage (melting + at least two fields)'),
    ]
    vals=[]; audit_rows=[]
    for label,screen_step in stage_specs:
        g=dbfun.loc[dbfun.screen_step.astype(str).eq(screen_step)]
        if len(g)!=1:
            raise RuntimeError(f'Fig. 1a stage mapping requires exactly one row for {screen_step!r}; found {len(g)}')
        retained=float(g.retained_count.iloc[0])
        vals.append(retained)
        audit_rows.append({'display_label':label,'screen_step':screen_step,'retained_count':int(retained)})
    picks=[(label,screen_step) for label,screen_step in stage_specs]
    pd.DataFrame(audit_rows).to_csv(QA/'fig1a_stage_mapping_audit.csv',index=False)
    y=np.arange(len(picks))[::-1]
    axa.hlines(y,0,vals,color=[PALE_BLUE,PALE_BLUE,CREAM,CREAM],lw=2.7)
    axa.scatter(vals,y,s=[48,43,38,34],color=[NAVY,BLUE,MUSTARD,OLIVE],edgecolor='white',lw=.6,zorder=3)
    for yi,v in zip(y,vals): axa.text(v+max(vals)*.025,yi,f'{int(v):,}',va='center',fontweight='bold',fontsize=6.4)
    axa.set_yticks(y,[x[0] for x in stage_specs]); axa.set_xlim(0,max(vals)*1.25); axa.set_xlabel('Retained records'); clean(axa,'x')
    axa.text(.98,.05,f"Independent curated registry: {int(curated.curated_candidate_count.iloc[0])} salts",transform=axa.transAxes,ha='right',va='bottom',fontsize=5.8,color=MID_GREY)

    # b — evidence stream Sankey/alluvial, using the supplied high-end grammar.
    panel(axb,'b')
    lf=lit.groupby(['evidence_stream','candidate_family'],as_index=False).unique_source_candidate_link.sum()
    sm={'Official databases':'Databases','System benchmarks':'Benchmarks','Thermophysical literature':'Thermophysical','Corrosion literature':'Corrosion','Contextual literature':'Context','Other literature':'Other'}
    fm={'Nitrate/nitrite':'Nitrate','Chloride':'Chloride','Carbonate/fluoride':'Carbonate/F'}
    lf['evidence_stream']=lf.evidence_stream.map(sm).fillna(lf.evidence_stream); lf['candidate_family']=lf.candidate_family.map(fm).fillna(lf.candidate_family)
    sc={'Databases':NAVY,'Benchmarks':BLUE,'Thermophysical':MUSTARD,'Corrosion':BURGUNDY,'Context':CREAM,'Other':NEUTRAL}
    fc={'Nitrate':MUSTARD,'Chloride':TERRACOTTA,'Carbonate/F':ROSE}
    L.weighted_alluvial(axb,lf,['evidence_stream','candidate_family'],'unique_source_candidate_link','evidence_stream',sc,node_color_map={**sc,**fc},stage_labels=['Evidence stream','Chemistry family'],outer_labels=True,label_min_fraction=.018,node_width=.07,gap=.008,node_top=.91,node_bottom=.01,stage_label_y=.985)

    # c — evidence scores only; Apps and database linkage are split into semantic side strips.
    panel(axc,'c')
    prof=ready.groupby(['system_id','display_system'],as_index=False)[['corrosion_compatibility_score','cycling_phase_stability_score','containment_validation_score','literature_replication_score','data_completeness_score']].mean()
    scp=scope[['system_id','display_system','family','registered_application_count','exact_formula_system_match']]
    m=scp.merge(prof,on=['system_id','display_system'],how='left').sort_values(['family','registered_application_count','system_id'],ascending=[True,False,True]).reset_index(drop=True)
    cols=['corrosion_compatibility_score','cycling_phase_stability_score','containment_validation_score','literature_replication_score','data_completeness_score']
    im=axc.imshow(m[cols],aspect='auto',cmap=LinearSegmentedColormap.from_list('ev',[VERY_LIGHT,CREAM,OLIVE]),vmin=0,vmax=1)
    axc.set_xticks(range(5),['Corrosion','Cycling/phase','Containment','Replication','Data'],rotation=34,ha='right')
    axc.set_yticks(range(len(m)),[short_id(x) for x in m.system_id]); axc.set_xlim(-.5,6.35)
    for x in np.arange(6)-.5: axc.axvline(x,color='white',lw=.45)
    for yy in np.arange(len(m)+1)-.5: axc.axhline(yy,color='white',lw=.45)
    axc.axvline(4.6,color=INK,lw=.8)
    for i,r in enumerate(m.itertuples(index=False)):
        axc.scatter(5.25,i,s=12+18*r.registered_application_count,color=NAVY,edgecolor='white',lw=.45)
        axc.text(5.25,i,str(int(r.registered_application_count)),ha='center',va='center',fontsize=5.2,color='white' if r.registered_application_count>=3 else INK)
        axc.scatter(6.05,i,s=26,marker='s',facecolor=MUSTARD if r.exact_formula_system_match else 'white',edgecolor=INK,lw=.55)
    axc.text(5.25,-.9,'Apps',ha='center',fontsize=6.2,fontweight='bold'); axc.text(6.05,-.9,'MSD',ha='center',fontsize=6.2,fontweight='bold')
    cax=axc.inset_axes([.34,1.12,.58,.026]); cb=fig.colorbar(im,cax=cax,orientation='horizontal'); cb.ax.xaxis.set_ticks_position('top'); cb.ax.tick_params(labelsize=5.6,length=1.3,pad=.2); cb.outline.set_linewidth(.4); cax.set_clip_on(False); axc.text(.32,1.135,'Evidence score',transform=axc.transAxes,ha='right',va='center',fontsize=5.8,clip_on=False)

    # d — claim-boundary bubble map; size = applications, fill = evidence score, symbol = exact database link.
    panel(axd,'d')
    plot=scope.copy(); xclass={'measured_and_database_validated':0,'measured_exact_composition':1,'measured_exact_composition_conditional_chemistry':1,'measured_exact_composition_corrosion_adjacent_only':1,'measured_exact_composition_corrosion_gated':1,'commercial_benchmark':2,'commercial_benchmark_review_average':2,'measured_latent_predicted_density_cp':3,'measured_latent_density_derived_not_direct':3,'partly_measured_partly_predicted':3}
    plot['x']=plot.property_data_class.map(xclass).fillna(3); plot['score']=pd.to_numeric(plot.evidence_score,errors='coerce')
    jitter=np.linspace(-.12,.12,len(plot));
    for j,r in enumerate(plot.itertuples(index=False)):
        mk='s' if r.exact_formula_system_match else 'o'
        axd.scatter(r.x+jitter[j],r.score,s=34+16*r.registered_application_count,marker=mk,color=candidate_color(r.system_id),edgecolor=INK if r.evidence_score<.5 else 'white',lw=.65,zorder=3)
        label_offsets={
            'hitec_xl':(-16,9),
            'pcm_lif_s1':(-18,10),
            'pcm_binary_carbonate':(-18,-12),
        }
        off=label_offsets.get(str(r.system_id),(0,5))
        axd.annotate(short_id(r.system_id),(r.x+jitter[j],r.score),xytext=off,textcoords='offset points',ha='right' if off[0]<0 else 'center',va='bottom' if off[1]>=0 else 'top',fontsize=5.1,clip_on=False,arrowprops=dict(arrowstyle='-',lw=.45,color=MID_GREY) if str(r.system_id) in label_offsets else None)
    axd.axhline(.75,color=MID_GREY,lw=.7,ls='--'); axd.text(3.45,.765,'registered evidence floor',ha='right',fontsize=5.2,color=MID_GREY)
    axd.set_xticks(range(4),['Database-\nvalidated','Exact measured','Commercial\nbenchmark','Derived /\npredicted'])
    axd.set_xlim(-.45,3.45); axd.set_ylim(.18,1.03); axd.set_ylabel('Registered evidence score'); clean(axd,'y')
    top_legend(axd,[Line2D([0],[0],marker='s',ls='',mfc='white',mec=INK,label='Exact database formula link',markersize=4.5),Line2D([0],[0],marker='o',ls='',mfc=NEUTRAL,mec='white',label='Area: registered applications',markersize=5.0)],ncol=2,anchor=(.5,1.12),fontsize=5.2)

    # e — service-resolved contraction, with the model-output boundary embedded as a concise annotation.
    panel(axe,'e')
    stages=contract.deployability_stage.drop_duplicates().tolist(); piv=contract.pivot(index='scenario',columns='deployability_stage',values='share_of_registered').reindex(SERVICE_ORDER)[stages]
    xs=np.arange(len(stages));
    for s,row in piv.iterrows():
        axe.plot(xs,row,color=SCOL[s],lw=1.05,alpha=.88,marker='o',ms=2.5,label=SERVICE[s])
    axe.set_xticks(xs,['Registered','Complete\nservice','Evidence-\nqualified','Any selected','≥1% selected'])
    axe.set_ylim(-.03,1.04); axe.set_ylabel('Share of registered candidate–service pairs'); clean(axe,'y')
    top_legend(axe,[Line2D([0],[0],color=SCOL[s],marker='o',lw=1,label=SERVICE[s],markersize=3) for s in SERVICE_ORDER],ncol=7,anchor=(.5,1.155),fontsize=5.4)
    axe.text(.99,.05,'Model-estimated values: audit/information extension only\nnever admitted to strict evidence-bounded selection',transform=axe.transAxes,ha='right',va='bottom',fontsize=5.4,color=BURGUNDY,bbox=dict(boxstyle='round,pad=.25',fc=ROSE_LIGHT,ec='none',alpha=.18))

    save(fig,1,'Evidence provenance and staged contraction separate database opportunity from formal material selection',['database_to_shortlist_transition','literature_evidence_flow','candidate_scope_and_inclusion_audit','candidate_readiness_profile','deployability_contraction'])

# ------------------------------ FIGURE 2 ---------------------------------
def fig2():
    cover=read('candidate_service_coverage_map'); ready=read('candidate_readiness_profile'); feas=read('service_feasibility_groups')
    tf=read('thermal_transport_frontier'); rpath=read('ranking_pathway_summary')
    fig=plt.figure(figsize=(MAIN_W,7.60),constrained_layout=True)
    gs=fig.add_gridspec(3,2,height_ratios=[1.02,1.05,.92],hspace=.065,wspace=.035)
    axa=fig.add_subplot(gs[0,0]); axb=fig.add_subplot(gs[0,1]); axc=fig.add_subplot(gs[1,0]); axd=fig.add_subplot(gs[1,1]); axe=fig.add_subplot(gs[2,:])

    # a — service window and candidate thermal range; only meaningful candidate–service pairs.
    panel(axa,'a')
    q=cover.copy(); order=q.sort_values(['scenario','candidate_Tm_C']).reset_index(drop=True); y=np.arange(len(order))
    for i,r in enumerate(order.itertuples(index=False)):
        axa.hlines(i,r.service_low_C,r.service_high_C,color=SCOL[r.scenario],lw=4.2,alpha=.34)
        axa.hlines(i,r.candidate_Tm_C,r.candidate_Tmax_practical_C,color=candidate_color(r.system_id),lw=1.1)
        axa.scatter(r.candidate_Tm_C,i,s=13,color=candidate_color(r.system_id),edgecolor='white',lw=.35,zorder=3)
        if r.strict_complete_service_feasible: axa.scatter(r.service_high_C,i,s=21,marker='D',facecolor='white',edgecolor=INK,lw=.6,zorder=4)
    axa.set_yticks(y,[f'{SERVICE[s]} · {short_id(c)}' for s,c in zip(order.scenario,order.system_id)]); axa.tick_params(axis='y',labelsize=4.7)
    axa.set_xlabel('Temperature (°C)'); clean(axa,'x'); axa.invert_yaxis()
    top_legend(axa,[Line2D([0],[0],color=NEUTRAL,lw=4,alpha=.4,label='Service window'),Line2D([0],[0],color=INK,lw=1,label='Candidate $T_m$–upper limit'),Line2D([0],[0],marker='D',ls='',mfc='white',mec=INK,label='Strict-complete',markersize=3.7)],ncol=3,anchor=(.5,1.145),fontsize=5.0)

    # b — complete-service class composition; repeated service profiles remain grouped.
    panel(axb,'b')
    f=feas.copy(); cats=['robust_complete_service','uncertain_complete_service','no_complete_service']; labs=['Robust complete','Uncertain complete','No complete']; cols=[OLIVE,MUSTARD,BURGUNDY]
    y=np.arange(len(f)); left=np.zeros(len(f))
    for c,lab,col in zip(cats,labs,cols):
        v=f[c].to_numpy(); axb.barh(y,v,left=left,height=.64,color=col,label=lab)
        for i,z in enumerate(v):
            if z>=.18: axb.text(left[i]+z/2,i,f'{z:.0%}',ha='center',va='center',fontsize=5.8,color='white' if col==BURGUNDY else INK)
        left+=v
    axb.set_yticks(y,[L.chem_label(x) for x in f.member_labels]); axb.set_xlim(0,1); barh_headroom(axb,len(f),.18); axb.set_xlabel('Complete-service classification share'); clean(axb,'x'); top_legend(axb,[Patch(facecolor=c,label=l) for c,l in zip(cols,labs)],ncol=3,anchor=(.5,1.145),fontsize=5.2)

    # c — joint probability/selection bubble plot, avoiding separate zero-heavy bars.
    panel(axc,'c')
    q=ready[(ready.strict_complete_service_probability>0)|(ready.evidence_qualified_selection_frequency>0)].copy()
    for r in q.itertuples(index=False):
        axc.scatter(r.strict_complete_service_probability,r.evidence_qualified_selection_frequency,s=34+95*(r.energy_density_p50_kWh_m3_conditional_on_adequacy/np.nanmax(q.energy_density_p50_kWh_m3_conditional_on_adequacy)),color=SCOL[r.scenario],edgecolor=INK if r.evidence_qualified_selection_frequency>=.01 else 'white',lw=.7)
        if r.evidence_qualified_selection_frequency>=.01 or r.scenario in ['coal_flexibility_storage','csp_sensible_storage','industrial_medium_heat']:
            axc.annotate(f'{SERVICE[r.scenario]} · {short_id(r.system_id)}',(r.strict_complete_service_probability,r.evidence_qualified_selection_frequency),xytext=(4,4),textcoords='offset points',fontsize=5.1,clip_on=True)
    pcm=q[q.scenario.str.startswith('pcm_') & q.evidence_qualified_selection_frequency.eq(0)]
    if len(pcm):
        xpcm=float(pcm.strict_complete_service_probability.min())
        axc.annotate('Strict-complete PCM candidates remain evidence-locked',
                     (xpcm,0),xytext=(-112,21),textcoords='offset points',
                     arrowprops=dict(arrowstyle='-',color=MID_GREY,lw=.58,shrinkA=2,shrinkB=2),
                     fontsize=5.05,color=MID_GREY,ha='left',va='center',clip_on=False)
    axc.plot([0,1],[0,1],color=LIGHT_GREY,lw=.75,ls='--'); axc.set_xlim(-.03,1.03); axc.set_ylim(-.03,1.03); axc.set_xlabel('Strict-complete service probability'); axc.set_ylabel('Evidence-qualified selection frequency'); clean(axc,'both')
    axc.legend(handles=[Line2D([0],[0],marker='o',ls='',mfc=NEUTRAL,mec='white',label='Area: conditional energy density',markersize=5),Line2D([0],[0],marker='o',ls='',mfc='white',mec=INK,label='Black edge: ≥1% selected',markersize=4.5)],loc='upper left',frameon=False,fontsize=5.2,labelspacing=.12)

    # d — forest plot of conditional energy density; only candidates with defined intervals.
    panel(axd,'d')
    q=ready.dropna(subset=['energy_density_p50_kWh_m3_conditional_on_adequacy']).copy(); q=q.sort_values('energy_density_p50_kWh_m3_conditional_on_adequacy'); y=np.arange(len(q))
    axd.hlines(y,q.energy_density_p05_kWh_m3_conditional_on_adequacy,q.energy_density_p95_kWh_m3_conditional_on_adequacy,color=[SCOL[s] for s in q.scenario],lw=1.2)
    axd.scatter(q.energy_density_p50_kWh_m3_conditional_on_adequacy,y,s=30,color=[SCOL[s] for s in q.scenario],edgecolor=np.where(q.evidence_qualified_selection_frequency>=.01,INK,'white'),lw=.65,zorder=3)
    axd.set_yticks(y,[f'{SERVICE[s]} · {short_id(c)}' for s,c in zip(q.scenario,q.system_id)]); axd.tick_params(axis='y',labelsize=5.2); barh_headroom(axd,len(q),.65); axd.set_xlabel('Conditional energy density (kWh m$^{-3}$), 5–95%'); clean(axd,'x')

    # e — pathway decomposition is the service-level summary and is not repeated elsewhere.
    panel(axe,'e')
    cats=['Stable leader','Service-only change','Evidence-only change','Service + evidence change','No bounded selection']; cols=[OLIVE,BLUE,MUSTARD,TERRACOTTA,BURGUNDY]
    p=(rpath.pivot(index='scenario',columns='pathway',values='frequency')
       .reindex(SERVICE_ORDER).reindex(columns=cats,fill_value=0).fillna(0.0))
    # Preserve every registered pathway component. Missing pivot cells are true zeros, not unknowns.
    p=p[(p>=.05).sum(axis=1)>=2]; y=np.arange(len(p)); left=np.zeros(len(p))
    p.assign(total_share=p.sum(axis=1), no_selection_share=p['No bounded selection']).reset_index().to_csv(QA/'fig2e_stack_audit.csv',index=False)
    for cat,col in zip(cats,cols):
        v=p[cat].to_numpy(); axe.barh(y,v,left=left,height=.65,color=col,label=cat)
        for i,z in enumerate(v):
            if z>=.10: axe.text(left[i]+z/2,i,f'{z:.0%}',ha='center',va='center',fontsize=5.8,color='white' if col in [TERRACOTTA,BURGUNDY,BLUE] else INK)
        left+=v
    axe.set_yticks(y,[SERVICE[s] for s in p.index]); axe.set_xlim(0,1); barh_headroom(axe,len(p),.7); axe.set_xlabel('Draw-level ranking-pathway share'); clean(axe,'x'); top_legend(axe,[Patch(facecolor=c,label=l) for c,l in zip(cols,cats)],ncol=5,anchor=(.5,1.13),fontsize=5.0)

    save(fig,2,'Strict complete-service feasibility, evidence qualification and performance uncertainty define the formal decision landscape',['candidate_service_coverage_map','service_feasibility_groups','candidate_readiness_profile','ranking_pathway_summary'])

# ------------------------------ FIGURE 3 ---------------------------------
def fig3():
    joint=read('joint_threshold_regime_map'); cov=read('service_coverage_threshold_sensitivity'); sweep=read('threshold_retention_sweep')
    scan=read('continuous_weight_space_scan'); arche=read('service_regime_archetype_summary',V)
    fig=plt.figure(figsize=(MAIN_W,7.55),constrained_layout=True)
    gs=fig.add_gridspec(3,2,height_ratios=[.88,1.02,1.00],hspace=.10,wspace=.10)
    axa=fig.add_subplot(gs[0,0]); axb=fig.add_subplot(gs[0,1]); axc=fig.add_subplot(gs[1,0]); axd=fig.add_subplot(gs[1,1]); axe=fig.add_subplot(gs[2,:])

    # a — one-axis stacked summary of all 630 registered joint states.
    panel(axa,'a')
    regimes=['robust access','conditional access','no bounded access']; rc={'robust access':OLIVE,'conditional access':MUSTARD,'no bounded access':BURGUNDY}
    share=(joint.groupby(['scenario','decision_regime']).size().unstack(fill_value=0).reindex(SERVICE_ORDER).reindex(columns=regimes,fill_value=0))
    share=share.div(share.sum(axis=1),axis=0); y=np.arange(len(share)); left=np.zeros(len(share))
    for rg in regimes:
        v=share[rg].to_numpy(); axa.barh(y,v,left=left,height=.62,color=rc[rg],label=rg.title())
        for i,z in enumerate(v):
            if z>=.14: axa.text(left[i]+z/2,i,f'{z:.0%}',ha='center',va='center',fontsize=5.4,color='white' if rg=='no bounded access' else INK)
        left+=v
    axa.set_yticks(y,[SERVICE[x] for x in share.index]); axa.set_xlim(0,1); barh_headroom(axa,len(share),.18)
    axa.set_xlabel('Share of 90 coverage–evidence states'); clean(axa,'x')
    top_legend(axa,[Patch(facecolor=rc[x],label=x.title()) for x in regimes],ncol=3,anchor=(.5,1.15),fontsize=4.9)

    # b — coverage uncertainty curves for the three informative services.
    panel(axb,'b')
    for ss in ['coal_flexibility_storage','csp_sensible_storage','industrial_medium_heat']:
        g=cov[cov.scenario.eq(ss)].sort_values('coverage_threshold'); x=g.coverage_threshold.to_numpy(); yy=g.no_selection_frequency.to_numpy(); n=g.mc_iterations.to_numpy(); se=np.sqrt(np.maximum(yy*(1-yy)/n,0))
        axb.fill_between(x,np.clip(yy-1.645*se,0,1),np.clip(yy+1.645*se,0,1),color=SCOL[ss],alpha=.16,lw=0); axb.plot(x,yy,color=SCOL[ss],lw=1.2,marker='o',ms=2.5,label=SERVICE[ss])
    axb.set_xlim(.948,1.002); axb.set_ylim(-.02,.55); axb.set_xlabel('Minimum service coverage'); axb.set_ylabel('No-selection frequency'); clean(axb,'both')
    top_legend(axb,[Line2D([0],[0],color=SCOL[x],marker='o',lw=1,label=SERVICE[x],markersize=3) for x in ['coal_flexibility_storage','csp_sensible_storage','industrial_medium_heat']],ncol=3,anchor=(.5,1.15),fontsize=5.1)

    # c — evidence-threshold breakpoints with endpoint value badges.
    panel(axc,'c'); rows=[]
    for ss,g in sweep.groupby('scenario'):
        g=g.sort_values('evidence_threshold'); metric='expected_strict_complete_candidate_count'
        ch=g[metric].ne(g[metric].shift()).to_numpy(); idx=np.flatnonzero(ch)[1:]
        for i in idx: rows.append({'scenario':ss,'threshold':g.iloc[i].evidence_threshold,'from':g.iloc[i-1][metric],'to':g.iloc[i][metric]})
    br=pd.DataFrame(rows).sort_values('threshold'); y=np.arange(len(br)); axc.hlines(y,.25,br.threshold,color=PALE_BLUE,lw=2.2); axc.scatter(br.threshold,y,s=34,color=[SCOL[x] for x in br.scenario],edgecolor='white',lw=.5)
    def expected_count_label(v):
        return '0' if abs(float(v)) < 5e-4 else f'{float(v):.2f}'
    br['from_label']=br['from'].map(expected_count_label); br['to_label']=br['to'].map(expected_count_label)
    axc.set_yticks(y,[f"{compact_service_label(ss)} · {a}→{b}" for ss,a,b in zip(br.scenario,br.from_label,br.to_label)]); axc.tick_params(axis='y',pad=1.0)
    br.to_csv(QA/'fig3c_breakpoint_audit.csv',index=False)
    xmax=max(.97,float(br.threshold.max())+.10); axc.set_xlim(.23,xmax); barh_headroom(axc,len(br),.28); axc.set_xlabel('Evidence threshold at expected strict-complete transition'); clean(axc,'x')
    for i,v in enumerate(br.threshold): value_badge(axc,v,i,f'{v:.2f}',color=SCOL[br.iloc[i].scenario],dx=5,fontsize=4.8)

    # d — industrial preference response; callouts are placed in a top annotation band.
    panel(axd,'d')
    g=scan[scan.scenario.eq('industrial_medium_heat')].copy(); g['bin']=pd.cut(g.weight_performance,np.linspace(0,1,16),include_lowest=True)
    q=g.groupby('bin',observed=True).agg(x=('weight_performance','median'),gap05=('top1_top2_frequency_gap',lambda z:z.quantile(.05)),gap50=('top1_top2_frequency_gap','median'),gap95=('top1_top2_frequency_gap',lambda z:z.quantile(.95)),ent05=('selection_entropy',lambda z:z.quantile(.05)),ent50=('selection_entropy','median'),ent95=('selection_entropy',lambda z:z.quantile(.95))).dropna()
    axd.fill_between(q.x,q.gap05,q.gap95,color=PALE_BLUE,alpha=.45,lw=0); axd.plot(q.x,q.gap50,color=NAVY,lw=1.2,label='Top-1 − top-2 selection-frequency gap')
    ent=(q.ent50-q.ent50.min())/(q.ent50.max()-q.ent50.min()+1e-12); elo=(q.ent05-q.ent50.min())/(q.ent50.max()-q.ent50.min()+1e-12); ehi=(q.ent95-q.ent50.min())/(q.ent50.max()-q.ent50.min()+1e-12)
    axd.fill_between(q.x,elo,ehi,color=CREAM,alpha=.34,lw=0); axd.plot(q.x,ent,color=MUSTARD,lw=1.2,label='Normalized entropy')
    axd.set_xlim(-.01,1.01); axd.set_ylim(-.03,1.05); axd.set_xlabel('Performance weight, industrial heat'); axd.set_ylabel('Normalized response'); clean(axd,'both')
    top_legend(axd,[Line2D([0],[0],color=NAVY,lw=1.2,label='Top-1 − top-2 frequency gap'),Line2D([0],[0],color=MUSTARD,lw=1.2,label='Normalized entropy')],ncol=2,anchor=(.5,1.14),fontsize=5.1)
    imax=int(np.nanargmax(q.gap50)); emax=int(np.nanargmax(ent)); value_badge(axd,float(q.x.iloc[imax]),.88,f'Max top-1−top-2 gap = {q.gap50.iloc[imax]:.2f}',color=NAVY,dx=-8,dy=0,ha='right',va='bottom',arrow=True,fontsize=4.5); value_badge(axd,float(q.x.iloc[emax]),.70,f'Max normalized H = {ent.iloc[emax]:.2f}',color=MUSTARD,dx=7,dy=0,ha='left',va='bottom',arrow=True,fontsize=4.5)

    # e — compact archetype bubble strip; explanatory callout moved above the axes.
    panel(axe,'e'); a=arche.copy(); xcats=['multi-boundary regime','joint threshold-sensitive','evidence-sensitive','structural service limitation','structural evidence lock','stable single regime']; xmap={x:i for i,x in enumerate(xcats)}
    a.loc[a.uncertainty_structure_class.eq('service-incomplete'),'regime_archetype']='structural service limitation'
    for i,r in enumerate(a.itertuples(index=False)):
        x=xmap.get(r.regime_archetype,len(xcats)-1); size=28+2.0*r.registered_joint_states
        axe.scatter(x,i,s=size,color=SCOL[r.scenario],edgecolor=INK if r.main_map_informative else 'white',lw=.7)
        axe.text(x,i,str(int(r.decision_regime_count)),ha='center',va='center',fontsize=5.4,color='white' if SCOL[r.scenario] in [BURGUNDY,TERRACOTTA,NAVY] else INK)
    axe.set_yticks(range(len(a)),[SERVICE[x] for x in a.scenario]); axe.set_xticks(range(len(xcats)),['Multi-\nboundary','Joint\nthreshold','Evidence\nresponse','Service\nlimited','Evidence\nlocked','Stable'])
    axe.set_xlim(-.5,len(xcats)-.5); axe.set_ylim(-.6,len(a)-.15); clean(axe,'both'); axe.set_xlabel('Service-level regime archetype')
    axe.text(.99,1.065,'Number inside = distinct joint regimes · black edge = informative boundary map',transform=axe.transAxes,ha='right',va='bottom',fontsize=5.0,color=MID_GREY,clip_on=False)

    save(fig,3,'Threshold and preference landscapes reveal switching boundaries without repeating structurally flat services',['joint_threshold_regime_map','service_coverage_threshold_sensitivity','threshold_retention_sweep','continuous_weight_space_scan','submission_service_regime_archetype_summary'])

# ------------------------------ FIGURE 4 ---------------------------------
def fig4():
    pa=read('pareto_joint_uncertainty_and_robustness',STAT); dom=read('pareto_dominance_mechanism_summary',V); scope=read('decision_scope_matrix',STAT); flow=read('figure_selection_alluvial_flows')
    fig=plt.figure(figsize=(MAIN_W,8.02),constrained_layout=True)
    gs=fig.add_gridspec(3,6,height_ratios=[1.35,1.02,.94],hspace=.075,wspace=.045)
    axa=fig.add_subplot(gs[0,:]); axb=fig.add_subplot(gs[1,0:3]); axc=fig.add_subplot(gs[1,3:6]); axd=fig.add_subplot(gs[2,0:2]); axe=fig.add_subplot(gs[2,2:4]); axf=fig.add_subplot(gs[2,4:6])

    # a — dominant Pareto anchor with joint 90% uncertainty ellipses.
    panel(axa,'a'); q=pa[(pa.frontier_scope=='opportunity')&pa.joint_valid_draws.gt(0)].copy()
    for r in q.itertuples(index=False):
        ellipse90(axa,r,SCOL[r.scenario]); edge=INK if r.threshold_50_member else 'white'
        axa.scatter(r.representative_performance_score,r.representative_credibility_score,s=22+70*r.frontier_membership_frequency,color=SCOL[r.scenario],edgecolor=edge,lw=.7,zorder=3)
        if r.threshold_50_member or (r.scenario=='sco2_high_temperature_storage' and r.frontier_membership_frequency>=.20):
            offsets={
                ('coal_flexibility_storage','solar_salt_ss60'):(5,14),
                ('csp_sensible_storage','solar_salt_ss60'):(-7,-9),
                ('industrial_medium_heat','solar_salt_ss60'):(-7,1),
                ('industrial_medium_heat','hitec'):(5,-15),
                ('pcm_target_350C','knc'):(5,8),
                ('pcm_target_425C','pcm_lif_s1'):(5,-9),
                ('pcm_target_500C','pcm_binary_carbonate'):(5,6),
                ('sco2_high_temperature_storage','mgcl_kcl_nacl'):(5,7),
            }
            off=offsets.get((r.scenario,r.system_id),(4,5))
            if (r.scenario,r.system_id) in [('csp_sensible_storage','solar_salt_ss60'),('industrial_medium_heat','solar_salt_ss60')]:
                ha='right'
            else:
                ha='left'
            # Right-edge points are labelled inward; annotations are not clipped by the data axes.
            if r.representative_performance_score >= .90:
                off=(-5,off[1]); ha='right'
            else:
                ha=ha
            axa.annotate(f'{SERVICE[r.scenario]} · {short_id(r.system_id)}',(r.representative_performance_score,r.representative_credibility_score),xytext=off,textcoords='offset points',fontsize=5.0,clip_on=False,ha=ha)
    # service-specific reference front segments
    for s,g in q.groupby('scenario'):
        f=g[g.representative_frontier_member].sort_values('representative_performance_score')
        if len(f)>=2: axa.plot(f.representative_performance_score,f.representative_credibility_score,color=SCOL[s],lw=.75,alpha=.7)
    axa.set_xlim(-.015,1.02); axa.set_ylim(-.015,1.02); axa.set_xlabel('Representative performance score'); axa.set_ylabel('Evidence-readiness score'); clean(axa,'both')
    top_legend(axa,[Line2D([0],[0],marker='o',ls='',mfc=SCOL[s],mec='white',label=SERVICE[s],markersize=4) for s in SERVICE_ORDER]+[Line2D([0],[0],marker='o',ls='',mfc='white',mec=INK,label='≥50% frontier member',markersize=4),Patch(facecolor=LIGHT_GREY,edgecolor=MID_GREY,alpha=.35,label='90% joint uncertainty')],ncol=9,anchor=(.5,1.105),fontsize=4.65)

    # b — frontier membership forest plot with bootstrap interval.
    panel(axb,'b'); z=q[q.frontier_membership_frequency.ge(.01)].sort_values('frontier_membership_frequency').tail(14); y=np.arange(len(z))
    axb.hlines(y,z.frontier_frequency_bootstrap_p05,z.frontier_frequency_bootstrap_p95,color=MID_GREY,lw=.9)
    axb.scatter(z.frontier_membership_frequency,y,s=30,color=[SCOL[s] for s in z.scenario],edgecolor=np.where(z.threshold_50_member,INK,'white'),lw=.65,zorder=3)
    axb.set_yticks(y,[f'{SERVICE[s]} · {short_id(c)}' for s,c in zip(z.scenario,z.system_id)]); axb.tick_params(axis='y',labelsize=5.1); barh_headroom(axb,len(z),.6); axb.set_xlim(0,1.03); axb.set_xlabel('Pareto membership frequency, bootstrap 5–95%'); clean(axb,'x')

    # c — dominance mechanism bubble matrix, no redundant shortfall panel.
    panel(axc,'c'); classes=['reference frontier','performance-dominated','evidence-dominated','dual-dominated','draw-unstable frontier','not evaluable']; cm={'reference frontier':OLIVE,'performance-dominated':MUSTARD,'evidence-dominated':BLUE,'dual-dominated':BURGUNDY,'draw-unstable frontier':ROSE,'not evaluable':LIGHT_GREY}
    counts=dom.groupby(['scenario','dominance_class']).size().unstack(fill_value=0).reindex(SERVICE_ORDER).reindex(columns=classes,fill_value=0)
    for i,s in enumerate(counts.index):
        for j,c in enumerate(classes):
            v=counts.loc[s,c]
            if v>0: axc.scatter(j,i,s=26+38*v,color=cm[c],edgecolor='white',lw=.5); axc.text(j,i,str(int(v)),ha='center',va='center',fontsize=5.2,color='white' if cm[c] in [BURGUNDY,BLUE] else INK)
    axc.set_yticks(range(len(counts)),[SERVICE[s] for s in counts.index]); axc.set_xticks(range(len(classes)),['Reference\nfront','Performance','Evidence','Dual','Draw-\nunstable','Not\nevaluable'],rotation=28,ha='right'); axc.set_xlim(-.5,len(classes)-.5); axc.set_ylim(-.6,len(counts)-.35); clean(axc,'both'); axc.set_xlabel('Representative-draw dominance mechanism')

    # d — UpSet-style intersection of Pareto, strict eligibility and formal selection.
    panel(axd,'d')
    opp=pa[pa.frontier_scope.eq('opportunity')][['scenario','system_id','threshold_50_member']].rename(columns={'threshold_50_member':'robust_pareto'})
    sm=scope.merge(opp,on=['scenario','system_id'],how='left'); sm['robust_pareto']=sm.robust_pareto.fillna(False); sm['strict_eligible']=sm.decision_scope_class.eq('decision_ready'); sm['selected']=sm.evidence_qualified_selection_frequency.ge(.01)
    inter=sm.groupby(['robust_pareto','strict_eligible','selected']).size().reset_index(name='count').sort_values('count',ascending=False); inter=inter[inter['count']>0].head(7).reset_index(drop=True)
    xx=np.arange(len(inter))
    def inter_color(r):
        if bool(r['selected']): return OLIVE
        if bool(r['robust_pareto']) and bool(r['strict_eligible']): return MUSTARD
        if bool(r['robust_pareto']): return BLUE
        if bool(r['strict_eligible']): return TERRACOTTA
        return ROSE
    inter_cols=[inter_color(r) for _,r in inter.iterrows()]
    axd.bar(xx,inter['count'],color=inter_cols,width=.62,edgecolor='white',linewidth=.45)
    for i,r in inter.iterrows():
        for j,key in enumerate(['robust_pareto','strict_eligible','selected']):
            axd.scatter(i,-1.1-j,s=28,facecolor=OLIVE if r[key] else 'white',edgecolor=INK,lw=.55)
        on=[j for j,k in enumerate(['robust_pareto','strict_eligible','selected']) if r[k]]
        if len(on)>1: axd.vlines(i,-1.1-max(on),-1.1-min(on),color=INK,lw=.7)
        value_badge(axd,i,r['count'],str(int(r['count'])),dx=0,dy=5,ha='center',color=inter_cols[i],ec=inter_cols[i],clip_on=False)
    axd.set_xticks([]); axd.set_yticks([-1.1,-2.1,-3.1],['Robust Pareto','Strict eligible','≥1% selected']); axd.set_ylim(-3.65,max(inter['count'])+3.0); axd.set_ylabel('Candidate–service intersections'); clean(axd,'y')

    # e — cross-service breadth lollipop.
    panel(axe,'e')
    breadth=opp.groupby('system_id').robust_pareto.sum().rename('pareto').reset_index(); sel=sm.groupby('system_id').selected.sum().rename('selected').reset_index(); breadth=breadth.merge(sel,on='system_id').sort_values(['pareto','selected']); y=np.arange(len(breadth))
    axe.hlines(y,breadth.selected,breadth.pareto,color=PALE_BLUE,lw=1.7); axe.scatter(breadth.pareto,y,s=28,color=MUSTARD,label='Robust Pareto'); axe.scatter(breadth.selected,y,s=24,color=OLIVE,label='Selected')
    for i,r in breadth.reset_index(drop=True).iterrows(): value_badge(axe,float(r.pareto),i,str(int(r.pareto)),color=MUSTARD,dx=4,fontsize=4.5)
    axe.set_yticks(y,[short_id(x) for x in breadth.system_id]); axe.tick_params(axis='y',labelsize=4.9); barh_headroom(axe,len(breadth),.25); axe.set_xlim(-.2,max(3.8,breadth.pareto.max()+.9)); axe.set_xlabel('Number of services'); clean(axe,'x'); top_legend(axe,[Line2D([0],[0],marker='o',ls='',mfc=MUSTARD,mec='white',label='Robust Pareto',markersize=4),Line2D([0],[0],marker='o',ls='',mfc=OLIVE,mec='white',label='Selected',markersize=4)],ncol=2,anchor=(.5,1.11),fontsize=4.8)

    # f — small redirection inset, retained only as contextual link to the strict layer.
    panel(axf,'f')
    f=flow.groupby('transition_class').transition_draws.sum(); labs=['retained','redirected','no_selection']; vals=np.array([f.get(x,0) for x in labs],float); vals=vals/vals.sum(); cols=[OLIVE,MUSTARD,BURGUNDY]
    axf.barh(np.arange(3),vals,color=cols,height=.58); axf.set_yticks(np.arange(3),['Retained','Redirected','No selection']); axf.set_xlim(0,1); axf.set_xlabel('Strict-layer transition share'); clean(axf,'x')
    for i,v in enumerate(vals): value_badge(axf,v,i,f'{v:.0%}',dx=5,dy=0,color=cols[i],ec=cols[i])

    save(fig,4,'Uncertainty-aware Pareto structure distinguishes robust non-dominance from formal selection',['pareto_joint_uncertainty_and_robustness','submission_pareto_dominance_mechanism_summary','decision_scope_matrix','figure_selection_alluvial_flows'])

# ------------------------------ FIGURE 5 ---------------------------------
def fig5():
    """Separate continuous variance, categorical information and structural closure-depth response."""
    st=read('structural_stochastic_uncertainty_classification',STAT)
    cont=read('continuous_decision_variance_attribution',STAT)
    cat=read('categorical_selection_information_attribution',STAT)
    prop=read('property_domain_contraction_summary',V)
    ev=read('atomic_evidence_unlock_summary',V)
    depth=read('gate_closure_depth_response')
    dep=read('performance_evidence_dependence_audit',STAT)

    fig=plt.figure(figsize=(MAIN_W,10.45),constrained_layout=True)
    fig.get_layout_engine().set(w_pad=.035,h_pad=.035,wspace=.025,hspace=.025)
    gs=fig.add_gridspec(5,2,height_ratios=[1.02,.68,.90,.58,.76],hspace=.065,wspace=.032)
    axa=fig.add_subplot(gs[0,:]); axb=fig.add_subplot(gs[1,0]); axc=fig.add_subplot(gs[1,1])
    axd=fig.add_subplot(gs[2,0]); axe=fig.add_subplot(gs[2,1]); axg=fig.add_subplot(gs[4,:])

    # a — service-to-uncertainty structure alluvial.
    panel(axa,'a'); af=st[['scenario','uncertainty_structure_class']].copy(); af['Service']=af.scenario.map(SERVICE); af['Regime']=af.uncertainty_structure_class.str.replace('-',' ',regex=False).str.title(); af['weight']=1
    rc={'Evidence Variable Single Candidate':BLUE,'Stochastic Multicandidate':OLIVE,'Service Incomplete':NEUTRAL,'Evidence Locked':BURGUNDY,'Preference Sensitive':MUSTARD,'Deterministic Single Candidate':PALE_BLUE}
    node={**{SERVICE[s]:SCOL[s] for s in SERVICE_ORDER},**{x:rc.get(x,MID_GREY) for x in af.Regime.unique()}}
    L.weighted_alluvial(axa,af,['Service','Regime'],'weight','Regime',{x:rc.get(x,MID_GREY) for x in af.Regime.unique()},node_color_map=node,stage_labels=['TES service','Decision-uncertainty structure'],outer_labels=True,label_min_fraction=.035,node_width=.065,gap=.012,node_top=.90,node_bottom=.015,stage_label_y=.985)

    blocks=['thermophysical','evidence','preference']; bcols=[NAVY,MUSTARD,OLIVE]; blab=['Thermophysical','Evidence','Preference']
    # b — continuous response only.
    panel(axb,'b',x=-.055); q=cont[cont.uncertainty_block.isin(blocks)&cont.normalized_shapley_variance_share.notna()].copy(); rows=[]
    for serv,g in q.groupby('scenario'): rows.append((SERVICE[serv],g.set_index('uncertainty_block').normalized_shapley_variance_share.reindex(blocks).fillna(0).to_numpy()))
    y=np.arange(len(rows)); left=np.zeros(len(rows))
    for j,(lab,col) in enumerate(zip(blab,bcols)):
        vals=np.array([r[1][j] for r in rows]); axb.barh(y,vals,left=left,height=.60,color=col,label=lab)
        for i,z in enumerate(vals):
            if z>=.07: axb.text(left[i]+z/2,i,f'{z:.0%}',ha='center',va='center',fontsize=5.35,color='white' if col==NAVY else INK)
        left+=vals
    axb.set_yticks(y,[r[0] for r in rows]); axb.set_xlim(0,1); barh_headroom(axb,len(rows),.06); axb.set_xlabel('Shapley variance share · continuous margin'); clean(axb,'x')
    top_legend(axb,[Patch(facecolor=c,label=l) for c,l in zip(bcols,blab)],ncol=3,anchor=(.5,1.105),fontsize=5.0)

    # c — categorical information response; no ordinary ANOVA.
    panel(axc,'c',x=-.055); q=cat[cat.uncertainty_block.isin(blocks)&cat.normalized_shapley_information_share.notna()].copy(); rows=[]
    for serv,g in q.groupby('scenario'): rows.append((SERVICE[serv],g.set_index('uncertainty_block').normalized_shapley_information_share.reindex(blocks).fillna(0).to_numpy()))
    y=np.arange(len(rows)); left=np.zeros(len(rows))
    for j,(lab,col) in enumerate(zip(blab,bcols)):
        vals=np.array([r[1][j] for r in rows]); axc.barh(y,vals,left=left,height=.60,color=col,label=lab)
        for i,z in enumerate(vals):
            if z>=.07: axc.text(left[i]+z/2,i,f'{z:.0%}',ha='center',va='center',fontsize=5.35,color='white' if col==NAVY else INK)
        left+=vals
    axc.set_yticks(y,[r[0] for r in rows]); axc.set_xlim(0,1); barh_headroom(axc,len(rows),.06); axc.set_xlabel('Shapley information share · categorical state'); clean(axc,'x')
    top_legend(axc,[Patch(facecolor=c,label=l) for c,l in zip(bcols,blab)],ncol=3,anchor=(.5,1.105),fontsize=5.0)

    # d — property-domain contraction.
    panel(axd,'d',x=-.055); q=prop[prop.coverage_loss_due_to_registered_property_domains.gt(.01)].sort_values('coverage_loss_due_to_registered_property_domains').tail(12).reset_index(drop=True); y=np.arange(len(q))
    axd.hlines(y,0,q.coverage_loss_due_to_registered_property_domains,color=PALE_BLUE,lw=2.1); axd.scatter(q.coverage_loss_due_to_registered_property_domains,y,s=30,color=[SCOL[s] for s in q.scenario],edgecolor='white',lw=.55,zorder=3)
    xmax=max(.1,float(q.coverage_loss_due_to_registered_property_domains.max())); axd.set_xlim(0,min(1.14,xmax*1.23+.02))
    for i,r in q.iterrows(): value_badge(axd,r.coverage_loss_due_to_registered_property_domains,i,f'{r.coverage_loss_due_to_registered_property_domains:.2f}',dx=5,color=SCOL[r.scenario],ec=SCOL[r.scenario])
    axd.set_yticks(y,[f'{SERVICE[s]} · {short_id(c)}' for s,c in zip(q.scenario,q.system_id)]); axd.tick_params(axis='y',labelsize=4.65,pad=1.5); barh_headroom(axd,len(q),.18); axd.set_xlabel('Service coverage lost to registered property domains'); clean(axd,'x')

    # e — atomic evidence unlock.
    panel(axe,'e',x=-.055); q=ev.groupby(['gate','gate_label'],as_index=False).agg(unlock=('shapley_unlock_contribution','sum'),services=('scenario','nunique')).sort_values('unlock').reset_index(drop=True); y=np.arange(len(q))
    gatecols={'corrosion':BURGUNDY,'cycling_phase':MUSTARD,'containment':OLIVE,'literature_validation':ROSE,'data_completeness':BLUE}
    axe.hlines(y,0,q.unlock,color=CREAM,lw=2.4); axe.scatter(q.unlock,y,s=34+12*q.services,color=[gatecols.get(g,MID_GREY) for g in q.gate],edgecolor='white',lw=.55,zorder=3)
    xmax=max(.01,float(q.unlock.max())); axe.set_xlim(0,xmax*1.24)
    for i,r in q.iterrows(): value_badge(axe,r.unlock,i,f'{r.unlock:.2f}',dx=5,color=gatecols.get(r.gate,MID_GREY),ec=gatecols.get(r.gate,MID_GREY))
    axe.set_yticks(y,[str(x).replace('Literature replication','Replication') for x in q.gate_label]); barh_headroom(axe,len(q),.14); axe.set_xlabel('Summed Shapley unlock contribution'); clean(axe,'x'); outside_note(axe,'Point area = contributing services',x=.99,y=1.045)

    # f — service-specific closure-depth response. The seven axes are deliberately
    # narrowed and centred so that the strip aligns with the outer edges of the
    # paired panels above instead of spanning the full alluvial-panel width.
    # Its shared legend is centred above the strip, outside every data axis.
    sub=gs[3,:].subgridspec(1,9,width_ratios=[.70,1,1,1,1,1,1,1,1.60],wspace=.075)
    closure_handles=[
        Patch(facecolor=MID_GREY,alpha=.20,label='Minimum–maximum'),
        Line2D([0],[0],color=MID_GREY,marker='o',lw=1,label='Median')
    ]
    for k,serv in enumerate(SERVICE_ORDER):
        ax=fig.add_subplot(sub[0,k+1])
        if k==0: panel(ax,'f',x=-.30,y=1.30)
        g=depth[depth.scenario.eq(serv)].sort_values('closed_gate_count')
        ax.fill_between(g.closed_gate_count,g.minimum_retained_frequency,g.maximum_retained_frequency,color=SCOL[serv],alpha=.20,lw=0)
        ax.plot(g.closed_gate_count,g.median_retained_frequency,color=SCOL[serv],lw=1.15,marker='o',ms=2.4)
        ax.set_title(SERVICE[serv],fontsize=5.25,pad=2,color=INK); ax.set_xlim(-.15,6.15); ax.set_ylim(-.04,1.04); ax.set_xticks([0,3,6]); ax.tick_params(labelsize=4.25,pad=.8)
        if k==0: ax.set_ylabel('Retained frequency',fontsize=5.1,labelpad=1.5); ax.set_yticks([0,.5,1])
        else: ax.set_yticks([])
        ax.set_xlabel('Closed gates',fontsize=4.65,labelpad=.7); clean(ax,None)
        if k==3:
            ax.legend(handles=closure_handles,loc='lower center',bbox_to_anchor=(.5,1.18),
                      frameon=False,ncol=2,fontsize=5.0,columnspacing=.65,
                      handlelength=.95,handletextpad=.30,borderaxespad=0)

    # g — P–C dependence, wide to avoid label collisions.
    panel(axg,'g',x=-.050,y=1.045); q=dep.dropna(subset=['pearson_performance_credibility','spearman_performance_credibility']).copy()
    axg.axhline(0,color=LIGHT_GREY,lw=.65); axg.axvline(0,color=LIGHT_GREY,lw=.65); axg.plot([-.05,1.02],[-.05,1.02],color=MID_GREY,lw=1.05,ls='--')
    offsets={('pcm_target_500C','nkca'):(-9,-15),('pcm_target_500C','pcm_binary_carbonate'):(7,7)}
    for r in q.itertuples(index=False):
        axg.scatter(r.pearson_performance_credibility,r.spearman_performance_credibility,s=26+18*r.joint_valid_draws/20000,color=SCOL[r.scenario],edgecolor='white',lw=.5)
        if abs(r.pearson_performance_credibility)>.2 or (r.scenario,r.system_id)==('pcm_target_500C','nkca'):
            off=offsets.get((r.scenario,r.system_id),(-5,7)); ha='left' if off[0]>0 else 'right'; va='top' if off[1]<0 else 'bottom'
            axg.annotate(f'{SERVICE[r.scenario]} · {short_id(r.system_id)}',(r.pearson_performance_credibility,r.spearman_performance_credibility),xytext=off,textcoords='offset points',ha=ha,va=va,fontsize=5.0,clip_on=True)
    axg.set_xlim(-.04,1.04); axg.set_ylim(-.04,.82); axg.set_xlabel('Pearson performance–evidence dependence'); axg.set_ylabel('Spearman dependence'); clean(axg,'both')
    ins=axg.inset_axes([.68,.10,.26,.35]); near=q[q.pearson_performance_credibility.abs().lt(.05)&q.spearman_performance_credibility.abs().lt(.05)]
    for r in near.itertuples(index=False): ins.scatter(r.pearson_performance_credibility,r.spearman_performance_credibility,s=12,color=SCOL[r.scenario],edgecolor='white',lw=.3)
    ins.axhline(0,color=LIGHT_GREY,lw=.4); ins.axvline(0,color=LIGHT_GREY,lw=.4); ins.set_xlim(-.02,.01); ins.set_ylim(-.022,.012); ins.tick_params(labelsize=3.9,length=1); ins.set_title('Near-zero cluster',fontsize=4.6,pad=1); clean(ins,None)

    save(fig,5,'Continuous variance, categorical information and service-specific closure depth are separated from structural bottlenecks',['structural_stochastic_uncertainty_classification','continuous_decision_variance_attribution','categorical_selection_information_attribution','submission_property_domain_contraction_summary','submission_atomic_evidence_unlock_summary','gate_closure_depth_response','performance_evidence_dependence_audit'])

# ------------------------------ FIGURE 6 ---------------------------------
def fig6():
    """DAG-constrained back-tracing with complete action-set and candidate redistribution diagnostics."""
    scope=read('decision_scope_matrix',STAT); mins=read('dag_constrained_minimal_action_sets',STAT)
    act=read('research_action_frontier_summary',V); signed=read('counterfactual_candidate_signed_changes'); priority=read('candidate_research_priority_summary',V)
    fig=plt.figure(figsize=(MAIN_W,9.35),constrained_layout=True)
    fig.get_layout_engine().set(w_pad=.035,h_pad=.035,wspace=.03,hspace=.03)
    gs=fig.add_gridspec(4,2,height_ratios=[1.03,1.42,.98,.88],hspace=.070,wspace=.035)
    axa=fig.add_subplot(gs[0,:]); axb=fig.add_subplot(gs[1,0]); axc=fig.add_subplot(gs[1,1]); axd=fig.add_subplot(gs[2,0]); axe=fig.add_subplot(gs[2,1]); axf=fig.add_subplot(gs[3,:])

    # a — precedence-valid current state → action → endpoint.
    panel(axa,'a'); rows=[]
    for r in priority.itertuples(index=False):
        cls=r.research_priority_class
        if cls=='current formal selection': action='No new evidence'; end='Formal benchmark'
        elif cls=='one-step evidence opportunity': action='Targeted registered programme'; end='Potential ≥1% selection'
        elif cls=='multi-step evidence programme': action='Integrated evidence programme'; end='Potential ≥1% selection'
        elif cls=='stop: service/property limited': action='Measure / redesign'; end='Reassess service fit'
        else: action='Stop / reframe'; end='No evidence-only route'
        rows.append({'Current':cls,'Action':action,'Endpoint':end,'weight':1})
    af=pd.DataFrame(rows); cc={'current formal selection':OLIVE,'one-step evidence opportunity':MUSTARD,'multi-step evidence programme':ROSE,'stop: service/property limited':TERRACOTTA,'stop: no registered evidence lever':NEUTRAL,'not reachable under registered actions':PALE_BLUE}
    ac={'No new evidence':OLIVE,'Targeted registered programme':MUSTARD,'Integrated evidence programme':ROSE,'Measure / redesign':TERRACOTTA,'Stop / reframe':NEUTRAL}; ec={'Formal benchmark':OLIVE,'Potential ≥1% selection':ROSE,'Reassess service fit':TERRACOTTA,'No evidence-only route':NEUTRAL}
    L.weighted_alluvial(axa,af,['Current','Action','Endpoint'],'weight','Current',cc,node_color_map={**cc,**ac,**ec},stage_labels=['Current decision state','Precedence-valid action','Decision endpoint'],outer_labels=True,label_min_fraction=.035,node_width=.06,gap=.009,node_top=.90,node_bottom=.015,stage_label_y=.985)

    # b — submission complete minimum admissible action-set matrix for scientifically evaluable pairs.
    panel(axb,'b'); targets=['become_bounded','reach_1pct_selection','alter_top_choice']; target_lab=['Become bounded','Reach ≥1%','Alter leader']
    pairs=mins[['scenario','system_id']].drop_duplicates().merge(scope[['scenario','system_id','decision_scope_class']],on=['scenario','system_id'],how='left')
    pairs=pairs[~pairs.decision_scope_class.isin(['outside_standardized_service','physical_service_window_limited'])].copy(); pairs['label']=[f'{SERVICE[s]} · {short_id(c)}' for s,c in zip(pairs.scenario,pairs.system_id)]; pairs=pairs.sort_values(['scenario','label']).reset_index(drop=True)
    classes=['property-domain first','direct-risk stop','not reachable','reachable, no action','reachable, programme']; cols=[MUSTARD,BURGUNDY,PALE_BLUE,OLIVE,ROSE]
    def cls(row):
        if row is None: return 'not reachable'
        rc0=str(row.reachability_class)
        if 'thermophysical_domain' in rc0: return 'property-domain first'
        if 'direct-risk' in rc0: return 'direct-risk stop'
        if rc0.startswith('reachable'): return 'reachable, no action' if str(row.admissible_minimal_action_set)=='none' else 'reachable, programme'
        return 'not reachable'
    arr=[]
    for pr in pairs.itertuples(index=False):
        row=[]
        for t in targets:
            z=mins[(mins.scenario==pr.scenario)&(mins.system_id==pr.system_id)&(mins.target==t)]; row.append(cls(z.iloc[0] if len(z) else None))
        arr.append(row)
    code={c:i for i,c in enumerate(classes)}; mat=np.array([[code[x] for x in r] for r in arr])
    axb.imshow(mat,aspect='auto',cmap=ListedColormap(cols),norm=BoundaryNorm(np.arange(-.5,len(cols)+.5),len(cols)),interpolation='nearest')
    axb.set_xticks(range(3),target_lab,rotation=20,ha='right'); axb.set_yticks(range(len(pairs)),pairs.label); axb.tick_params(axis='y',labelsize=4.35,pad=1)
    for x in np.arange(4)-.5: axb.axvline(x,color='white',lw=.5)
    for yy in np.arange(len(pairs)+1)-.5: axb.axhline(yy,color='white',lw=.42)
    clean(axb,None); top_legend(axb,[Patch(facecolor=c,label=l) for l,c in zip(classes,cols)],ncol=2,anchor=(.5,1.12),fontsize=4.55)

    # c — registered action benefit.
    panel(axc,'c',x=-.055); q=act[(act.decision_benefit.gt(0))|(act.total_newly_eligible_candidates.gt(0))].copy().sort_values('decision_benefit').reset_index(drop=True)
    action_map={'literature_replication_closure':'Replication','exact_composition_corrosion_closure':'Exact corrosion','combined_atomic_evidence_closure':'Registered programme','service_redesign_95pct':'Service redesign','property_measurement_precision_50pct':'Property precision','comprehensive_upper_bound':'Diagnostic upper bound'}
    y=np.arange(len(q))*.78
    axc.hlines(y,0,q.decision_benefit,color=np.where(q.release_scope.str.startswith('registered evidence'),PALE_BLUE,CREAM),lw=2.3)
    axc.scatter(q.decision_benefit,y,s=34+8*q.total_newly_eligible_candidates,color=np.where(q.non_dominated_under_registered_ordering,OLIVE,ROSE),edgecolor=np.where(q.adverse_application_fraction>0,BURGUNDY,'white'),lw=.7,zorder=3)
    xmax=max(.01,float(q.decision_benefit.max())); axc.set_xlim(0,xmax*1.28)
    for i,r in q.iterrows():
        col=OLIVE if r.non_dominated_under_registered_ordering else ROSE; value_badge(axc,r.decision_benefit,y[i],f'{r.decision_benefit:.2f}',dx=5,color=col,ec=col)
    axc.set_yticks(y,[action_map.get(str(x),str(x).replace('_',' ')) for x in q.closure_action]); axc.tick_params(axis='y',labelsize=4.9,pad=1.5); axc.set_ylim(-.42,y[-1]+.45 if len(y) else .5)
    axc.set_ylabel('Action',labelpad=2); axc.set_xlabel('Largest registered benefit (diagnostic)'); clean(axc,'x')
    top_legend(axc,[Line2D([0],[0],marker='o',ls='',mfc=OLIVE,mec='white',label='Non-dominated action',markersize=4),Line2D([0],[0],marker='o',ls='',mfc=ROSE,mec=BURGUNDY,label='Diagnostic / adverse',markersize=4),Line2D([0],[0],color=CREAM,lw=2,label='Diagnostic boundary')],ncol=3,anchor=(.5,1.12),fontsize=4.65)
    axc.text(.01,.99,'Eligibility may increase even when registered benefit = 0',transform=axc.transAxes,ha='left',va='top',fontsize=4.55,color=MID_GREY)

    # d — ordinal burden–benefit map.
    panel(axd,'d'); q=act.copy()
    for r in q.itertuples(index=False):
        fill=OLIVE if r.non_dominated_under_registered_ordering else (MUSTARD if str(r.release_scope).startswith('registered evidence') else ROSE); edge=BURGUNDY if r.adverse_application_fraction>0 else 'white'
        axd.scatter(r.burden_ordinal_index,r.decision_benefit,s=34+7*r.total_newly_eligible_candidates,color=fill,edgecolor=edge,lw=.7)
        if r.decision_benefit>0 or str(r.release_scope).startswith('registered evidence'):
            short=action_map.get(r.closure_action,str(r.closure_action).replace('_closure','').replace('_',' ')); 
            if short=='Diagnostic upper bound':
                short='Upper bound'; off=(-5,-11); ha='right'; va='top'
            elif short=='Registered programme':
                off=(-5,9); ha='right'; va='bottom'
            elif short=='Replication':
                off=(4,-9); ha='left'; va='top'
            elif r.burden_ordinal_index>=4.5:
                off=(-4,5); ha='right'; va='bottom'
            else:
                off=(3,4); ha='left'; va='bottom'
            axd.annotate(short,(r.burden_ordinal_index,r.decision_benefit),xytext=off,textcoords='offset points',fontsize=4.5,clip_on=True,ha=ha,va=va)
    axd.set_xlim(.7,5.25); axd.set_ylim(-.015,max(.50,q.decision_benefit.max()+.05)); axd.set_xlabel('Ordinal evidence burden'); axd.set_ylabel('Largest registered benefit'); clean(axd,'both'); axd.text(.02,.98,'Order only; not cost, duration or success probability',transform=axd.transAxes,va='top',fontsize=4.8,color=MID_GREY)

    # e — submission candidate-selection redistribution, limited to preregistered |Δ| ≥1% effects.
    panel(axe,'e'); z=signed[signed.delta_selection_frequency.abs().ge(.01)].copy(); amap={'comprehensive_upper_bound':'Upper bound','combined_atomic_evidence_closure':'Combined','service_redesign_95pct':'95% redesign','property_measurement_precision_50pct':'Property precision','exact_composition_corrosion_closure':'Exact corrosion','literature_replication_closure':'Replication'}
    z['label']=[f"{amap.get(str(a),str(a).replace('_closure','').replace('_',' '))} · {SERVICE[s]} · {short_id(c)}" for a,s,c in zip(z.closure_action,z.scenario,z.system_id)]
    z=z.reindex(z.delta_selection_frequency.abs().sort_values(ascending=False).index).head(8).sort_values('delta_selection_frequency').reset_index(drop=True); y=np.arange(len(z))
    axe.hlines(y,0,z.delta_selection_frequency,color=PALE_BLUE,lw=1.8); axe.scatter(z.delta_selection_frequency,y,c=np.where(z.delta_selection_frequency>=0,OLIVE,BURGUNDY),s=40,edgecolor='white',lw=.5); axe.axvline(0,color=INK,lw=.7)
    span=max(.05,float(z.delta_selection_frequency.abs().max())); axe.set_xlim(min(-.05,float(z.delta_selection_frequency.min())-.13*span),max(.05,float(z.delta_selection_frequency.max())+.25*span))
    for i,r in z.iterrows(): value_badge(axe,r.delta_selection_frequency,i,f'{r.delta_selection_frequency:+.0%}',dx=5 if r.delta_selection_frequency>=0 else -5,ha='left' if r.delta_selection_frequency>=0 else 'right',color=OLIVE if r.delta_selection_frequency>=0 else BURGUNDY,ec=OLIVE if r.delta_selection_frequency>=0 else BURGUNDY)
    axe.set_yticks(y,L.label_wrap(z.label,24)); axe.tick_params(axis='y',labelsize=4.45,pad=1); barh_headroom(axe,len(z),.25); axe.set_xlabel('Selection-frequency change (|Δ| ≥ 1%)'); clean(axe,'x')

    # f — service-level priority and stopping rules.
    panel(axf,'f'); cats=['current formal selection','one-step evidence opportunity','multi-step evidence programme','stop: service/property limited','stop: no registered evidence lever','not reachable under registered actions']; cols2=[OLIVE,MUSTARD,ROSE,TERRACOTTA,NEUTRAL,PALE_BLUE]
    counts=priority.groupby(['scenario','research_priority_class']).size().unstack(fill_value=0).reindex(SERVICE_ORDER).reindex(columns=cats,fill_value=0)
    y=np.arange(len(counts)); left=np.zeros(len(counts))
    for c,col in zip(cats,cols2):
        vals=counts[c].to_numpy(); axf.barh(y,vals,left=left,height=.62,color=col,label=c)
        for i,z0 in enumerate(vals):
            if z0>0: axf.text(left[i]+z0/2,i,str(int(z0)),ha='center',va='center',fontsize=5.4,color='white' if col in [ROSE,TERRACOTTA] else INK)
        left+=vals
    axf.set_yticks(y,[SERVICE[s] for s in counts.index]); barh_headroom(axf,len(counts),.35); axf.set_xlabel('Candidate–service research routes'); clean(axf,'x'); top_legend(axf,[Patch(facecolor=c,label=l.replace(' under registered actions','')) for c,l in zip(cols2,cats)],ncol=3,anchor=(.5,1.13),fontsize=4.9)

    save(fig,6,'Precedence-constrained back-tracing links admissible action sets to candidate selection redistribution and stopping rules',['submission_candidate_research_priority_summary','dag_constrained_minimal_action_sets','submission_research_action_frontier_summary','counterfactual_candidate_signed_changes'])

# -------------------------- SUPPLEMENTARY LAYER --------------------------
def supp_base(n:int):
    # The certified supplementary grammar provides complete-detail views and is rebound to submission output paths.
    getattr(L,f'make_ed{n}')()
    source_map={
        1:['exact_formula_candidate_evidence_audit','literature_source_registry'],
        2:['candidate_readiness_profile','candidate_scope_and_inclusion_audit'],
        3:['candidate_service_coverage_map','property_domain_coverage_audit'],
        4:['candidate_system_metrics_deterministic','candidate_system_metrics_draw_summary'],
        5:['layered_selection_frequencies','no_selection_frequencies','candidate_readiness_profile'],
        6:['joint_threshold_regime_map','service_coverage_threshold_sensitivity','threshold_retention_sweep'],
        7:['continuous_weight_space_scan','application_switch_sensitivity_summary'],
        8:['pareto_joint_uncertainty_and_robustness','pareto_dominance_mechanism_summary'],
        9:['continuous_decision_variance_attribution','categorical_selection_information_attribution'],
        10:['performance_evidence_dependence_audit','gate_pair_synergy_summary'],
    }
    supplementary_titles={
        1:'Database curation and chemistry-family structure',
        2:'Provenance linkage and atomic credibility',
        3:'Unique thermophysical profiles',
        4:'Pairwise performance and material-cost boundary',
        5:'Complete-service overclaim penalty',
        6:'Threshold sensitivity and convergence',
        7:'Continuous preference space and application switching',
        8:'Full Pareto membership and dominance diagnostics',
        9:'Uncertainty-source attribution with bootstrap validation',
        10:'Performance–evidence dependence and covariance structure',
    }
    png=SUPP/f'{V}_Supp_Fig{n}.png'
    with Image.open(png) as im:
        width,height=im.size
    FIGURE_RECORDS.append({'figure':f'Supp_Fig{n}','title':supplementary_titles[n],'width_px':width,'height_px':height,'aspect_ratio':width/height,'source_tables':';'.join(source_map[n])})



def supp6():
    # Non-duplicative full threshold audit: main Fig. 3b already shows coverage-response curves.
    joint=read('joint_threshold_regime_map'); sweep=read('threshold_retention_sweep'); conv=read('independent_convergence_summary')
    fig=plt.figure(figsize=(MAIN_W,5.75),constrained_layout=True)
    gs=fig.add_gridspec(2,2,height_ratios=[1.12,.88],hspace=.085,wspace=.055)
    axa=fig.add_subplot(gs[0,:]); axb=fig.add_subplot(gs[1,0]); axc=fig.add_subplot(gs[1,1])
    panel(axa,'a')
    # Full 630-state categorical registry as seven compact 6x15 strips, not a repeated coverage curve.
    regimes=['robust access','conditional access','no bounded access']; cmap=ListedColormap([OLIVE,MUSTARD,BURGUNDY]); code={r:i for i,r in enumerate(regimes)}
    mats=[]; labels=[]
    covs=sorted(joint.coverage_threshold.unique()); evs=sorted(joint.evidence_threshold.unique())
    for ss in SERVICE_ORDER:
        g=joint[joint.scenario.eq(ss)].pivot(index='coverage_threshold',columns='evidence_threshold',values='decision_regime').reindex(index=covs,columns=evs)
        mats.append(g.apply(lambda col: col.map(code)).astype(float).to_numpy()); labels.append(SERVICE[ss])
    full=np.vstack([np.vstack([m, np.full((1,len(evs)),np.nan)]) for m in mats])[:-1]
    axa.imshow(full,aspect='auto',interpolation='nearest',cmap=cmap,vmin=0,vmax=2)
    centers=[]; start=0
    for lab,m in zip(labels,mats):
        centers.append(start+(m.shape[0]-1)/2); start+=m.shape[0]+1
    axa.set_yticks(centers,labels); axa.set_xticks(range(0,len(evs),2),[f'{evs[i]:.2f}' for i in range(0,len(evs),2)],rotation=0)
    axa.set_xlabel('Evidence threshold'); axa.set_ylabel('Coverage-threshold rows (95–100%)'); clean(axa,None)
    top_legend(axa,[Patch(facecolor=cmap(i),label=r.title()) for i,r in enumerate(regimes)],ncol=3,anchor=(.5,1.09),fontsize=5.2)
    panel(axb,'b')
    # Full evidence-threshold response uses expected strict-complete candidate count, distinct from main Fig. 3b.
    plotted=[]
    for ss in SERVICE_ORDER:
        g=sweep[sweep.scenario.eq(ss)].sort_values('evidence_threshold')
        if g.expected_strict_complete_candidate_count.nunique()>1:
            axb.step(g.evidence_threshold,g.expected_strict_complete_candidate_count,where='post',lw=1.2,color=SCOL[ss],label=SERVICE[ss]); plotted.append(ss)
    axb.set_xlabel('Evidence threshold'); axb.set_ylabel('Expected strict-complete candidates'); clean(axb,'both')
    if plotted: top_legend(axb,[Line2D([0],[0],color=SCOL[x],lw=1.2,label=SERVICE[x]) for x in plotted],ncol=min(3,len(plotted)),anchor=(.5,1.12),fontsize=5.0)
    panel(axc,'c')
    axc.plot(conv.n_draws,conv.median_absolute_error,marker='o',ms=3,color=NAVY,label='Median')
    axc.plot(conv.n_draws,conv.p95_absolute_error,marker='s',ms=3,color=BURGUNDY,label='95th percentile')
    axc.set_xscale('log'); axc.xaxis.set_major_formatter(mpl.ticker.FuncFormatter(lambda value,pos:f'{value:g}')); axc.xaxis.set_minor_formatter(mpl.ticker.NullFormatter())
    axc.set_xlabel('Independent draws'); axc.set_ylabel('Modal-frequency error'); clean(axc,'both'); top_legend(axc,[Line2D([0],[0],color=NAVY,marker='o',label='Median'),Line2D([0],[0],color=BURGUNDY,marker='s',label='95th percentile')],ncol=2,anchor=(.5,1.12),fontsize=5.0)
    save(fig,6,'Full joint-state registry, evidence-threshold candidate response and independent convergence',['joint_threshold_regime_map','threshold_retention_sweep','independent_convergence_summary'],supp=True)

def supp11():
    """Complementary action diagnostics only; no redraw of main Fig. 5f, Fig. 6b or Fig. 6e."""
    dag=read('evidence_action_dag_registry',STAT)
    inter=read('nonzero_gate_interaction_summary',V)
    nonadd=read('evidence_programme_nonadditivity')
    outcomes=read('evidence_action_outcome_scenario_registry',STAT)
    fig=plt.figure(figsize=(MAIN_W,6.15),constrained_layout=True); gs=fig.add_gridspec(2,3,height_ratios=[1.0,.90],hspace=.10,wspace=.055)
    axa=fig.add_subplot(gs[0,0]); axb=fig.add_subplot(gs[0,1]); axc=fig.add_subplot(gs[0,2]); axd=fig.add_subplot(gs[1,0]); axe=fig.add_subplot(gs[1,1:])

    panel(axa,'a'); q=dag.sort_values('burden_ordinal'); y=np.arange(len(q)); axa.barh(y,q.burden_ordinal,color=CREAM); axa.set_yticks(y,[x.replace('_',' ') for x in q.action_id]); axa.tick_params(axis='y',labelsize=4.8); axa.set_xlabel('Ordinal burden (not cost)'); clean(axa,'x')

    panel(axb,'b'); atomic=['corrosion_compatibility','cycling_phase_stability','containment_validation','literature_replication','data_completeness']; arr=[]
    for r in dag.itertuples(index=False): closed=set(str(r.closes_dimensions).split(';')); arr.append([1 if d in closed else 0 for d in atomic])
    axb.imshow(arr,aspect='auto',cmap=ListedColormap([VERY_LIGHT,BURGUNDY]),vmin=0,vmax=1); axb.set_xticks(range(5),['Corr.','Cycl.','Cont.','Repl.','Data'],rotation=35,ha='right'); axb.set_yticks(range(len(dag)),[x.replace('_',' ') for x in dag.action_id]); axb.tick_params(axis='y',labelsize=4.3); clean(axb,None)

    panel(axc,'c'); q=inter.sort_values('mean_synergy').reset_index(drop=True); y=np.arange(len(q))
    if len(q):
        cols=np.where(q.mean_synergy>=0,MUSTARD,BLUE); axc.hlines(y,0,q.mean_synergy,color=PALE_BLUE,lw=2); axc.scatter(q.mean_synergy,y,s=32+12*q.nonzero_service_count,color=cols,edgecolor='white',lw=.5); axc.axvline(0,color=INK,lw=.6)
        labs=[str(x).replace('Incomplete Service','Service').replace('Literature Validation','Replication').replace('Data Completeness','Data') for x in q.pair_label]; axc.set_yticks(y,L.label_wrap(labs,18)); axc.tick_params(axis='y',labelsize=4.4)
        for i,r in q.iterrows(): value_badge(axc,r.mean_synergy,i,f'{r.mean_synergy:.2f}',dx=4 if r.mean_synergy>=0 else -4,ha='left' if r.mean_synergy>=0 else 'right',color=MUSTARD if r.mean_synergy>=0 else BLUE,ec=MUSTARD if r.mean_synergy>=0 else BLUE,fontsize=4.5)
    axc.set_xlabel('Gate-pair synergy'); clean(axc,'x')

    panel(axd,'d'); q=nonadd[nonadd.nonadditivity_delta_selection_probability.abs().gt(1e-9)].sort_values('nonadditivity_delta_selection_probability').reset_index(drop=True); y=np.arange(len(q))
    if len(q):
        axd.hlines(y,0,q.nonadditivity_delta_selection_probability,color=CREAM,lw=2.4); axd.scatter(q.nonadditivity_delta_selection_probability,y,s=38,color=[SCOL[s] for s in q.scenario],edgecolor='white',lw=.55)
        axd.set_yticks(y,[SERVICE[s] for s in q.scenario]); axd.set_xlim(0,max(1.15,float(q.nonadditivity_delta_selection_probability.max())*1.18));
        for i,r in q.iterrows(): value_badge(axd,r.nonadditivity_delta_selection_probability,i,f'{r.nonadditivity_delta_selection_probability:.0%}',dx=5,color=SCOL[r.scenario],ec=SCOL[r.scenario])
    axd.set_xlabel('Combined − summed atomic selection gain'); clean(axd,'x')

    panel(axe,'e'); axe.axis('off'); yv=np.linspace(.80,.20,len(outcomes)); cs=[OLIVE,CREAM,BURGUNDY,LIGHT_GREY]
    for r,y0,c in zip(outcomes.itertuples(index=False),yv,cs):
        axe.add_patch(FancyBboxPatch((.04,y0-.065),.92,.125,boxstyle='round,pad=.012',transform=axe.transAxes,facecolor=c,edgecolor='white',alpha=.78)); axe.text(.09,y0,str(r.outcome_scenario).title(),transform=axe.transAxes,fontweight='bold',va='center',fontsize=5.5); axe.text(.48,y0,'Probability not assigned',transform=axe.transAxes,va='center',fontsize=4.8)
    save(fig,11,'Complementary evidence-action interactions, programme non-additivity and interpretation boundaries',['evidence_action_dag_registry','submission_nonzero_gate_interaction_summary','evidence_programme_nonadditivity','evidence_action_outcome_scenario_registry'],supp=True)

def make_contact(paths,out,cols,thumb_width):
    ims=[]
    for p in paths:
        with Image.open(p) as src:
            im=src.convert('RGB')
        ratio=thumb_width/im.width; h=max(1,int(im.height*ratio)); im=im.resize((thumb_width,h),Image.Resampling.LANCZOS); ims.append(im)
    rows=math.ceil(len(ims)/cols); row_heights=[]
    for r in range(rows): row_heights.append(max(im.height for im in ims[r*cols:(r+1)*cols]))
    sheet=Image.new('RGB',(cols*thumb_width,sum(row_heights)),'white'); y=0
    for r in range(rows):
        for c in range(cols):
            idx=r*cols+c
            if idx<len(ims): sheet.paste(ims[idx],(c*thumb_width,y+(row_heights[r]-ims[idx].height)//2))
        y+=row_heights[r]
    sheet.save(out,quality=92)


def write_docs():
    story='''# scientific storyline

Evidence provenance and staged contraction → strict service-resolved formal decisions → threshold and preference boundaries → uncertainty-aware non-compensatory Pareto structure → separated continuous/categorical attribution and structural bottlenecks → precedence-constrained research priorities and stopping rules.

The strict-complete, evidence-bounded and ≥1% formal-selection layer remains frozen. submission changes only figure geometry, annotations, legend placement, chemical/unit typography and non-redundant editorial synthesis. No formal scientific recommendation is upgraded or removed.
'''
    (DOCS/'STORYLINE.md').write_text(story,encoding='utf-8')
    captions='''# main figures

## Fig. 1 — Evidence foundation, claim boundaries and staged contraction
**a**, database attrition lollipop. **b**, evidence-stream to chemistry-family alluvial. **c**, candidate-level atomic evidence matrix with separate application-count and exact-link strips. **d**, registered evidence score by claim class. **e**, service-resolved contraction with a single-row legend above the axis and an embedded model-output-boundary statement.

## Fig. 2 — Strict service-resolved decision landscape
**a**, service windows and candidate temperature ranges with the legend above the x axis. **b**, complete-service classification shares with reduced unused top space. **c**, strict-complete probability versus formal selection frequency, with the evidence-locked PCM annotation moved left and connected by a leader. **d**, conditional energy-density intervals. **e**, draw-level ranking-pathway shares.

## Fig. 3 — Gradient regimes and application-dependent switching
**a**, compact stacked shares of all registered coverage–evidence states. **b**, coverage-threshold response for the three non-degenerate services. **c**, evidence-threshold breakpoints in the expected strict-complete candidate count, with endpoint badges. **d**, industrial preference response with the legend outside the data field. **e**, service-level regime archetypes; structurally flat services are compressed rather than repeated.

## Fig. 4 — No universal salt: uncertainty-aware non-compensatory Pareto structure
**a**, performance–evidence plane with 90% joint ellipses and reference front segments. **b**, bootstrap Pareto-membership forest. **c**, dominance-mechanism matrix. **d**, colour-distinguished Pareto/eligibility/selection intersections. **e**, widened cross-service robust-Pareto and formal-selection breadth. **f**, widened strict-layer transition summary.

## Fig. 5 — Uncertainty-source attribution and structural bottlenecks
**a**, service-to-uncertainty-structure alluvial. **b**, continuous-margin Shapley variance shares. **c**, categorical-state Shapley information shares. **d**, property-domain coverage losses with endpoint badges. **e**, atomic evidence unlock contributions with endpoint badges. **f**, seven service-specific evidence-closure-depth responses showing the median retained frequency and registered minimum–maximum range. **g**, performance–evidence dependence with the PCM500 label displaced from the data point.

## Fig. 6 — Decision-boundary back-tracing and evidence investment priorities
**a**, precedence-valid state–action–endpoint alluvial. **b**, complete minimum admissible action-set matrix for scientifically evaluable candidate–service pairs. **c**, compact action-benefit forest with shortened action labels, widened x range and endpoint badges inside the axis. **d**, ordinal burden–gain map. **e**, candidate selection-frequency redistribution for registered effects with |Δ| ≥1%. **f**, service-level research-priority and stopping-rule summary.
'''
    (DOCS/'MAIN_FIGURE_CAPTIONS.md').write_text(captions,encoding='utf-8')
    checklist='''# figure and panel checklist

## Main figures

### Figure 1 | Evidence foundation, claim boundaries and staged contraction
- **1a** Database attrition: retained records at registered screening stages.
- **1b** Evidence provenance alluvial: evidence streams to chemistry families.
- **1c** Candidate evidence matrix: corrosion, cycling/phase, containment, replication and data completeness, with separate application-count and exact-database-link strips.
- **1d** Claim-boundary map: evidence score across database-validated, exact-measured, commercial-benchmark and derived/predicted classes.
- **1e** Service contraction: registered → complete service → evidence-qualified → any selected → ≥1% selected; model-output boundary shown only as a boundary annotation.

### Figure 2 | Strict service-resolved decision landscape
- **2a** Service windows and candidate temperature ranges.
- **2b** Complete-service classification composition.
- **2c** Strict-complete probability versus evidence-qualified selection frequency.
- **2d** Conditional energy-density 5–95% forest.
- **2e** Ranking-pathway composition: stable leader, service-only, evidence-only, joint change and no bounded selection.

### Figure 3 | Gradient regimes and application-dependent switching
- **3a** Stacked shares of robust, conditional and no-bounded-access states across all services.
- **3b** Coverage-threshold no-selection response for Coal, CSP and Industrial heat.
- **3c** Evidence-threshold breakpoints in expected strict-complete candidate count with numerical endpoint badges.
- **3d** Industrial preference response: leader gap and normalized entropy.
- **3e** Service-level regime archetype matrix; repeated flat services compressed.

### Figure 4 | Uncertainty-aware Pareto structure
- **4a** Performance–evidence Pareto plane with 90% joint uncertainty ellipses.
- **4b** Bootstrap Pareto-membership frequency forest.
- **4c** Dominance-mechanism matrix.
- **4d** Robust-Pareto, strict-eligibility and ≥1%-selection intersections.
- **4e** Cross-service robust-Pareto and formal-selection breadth.
- **4f** Retained, redirected and no-selection strict-layer transition shares.

### Figure 5 | Uncertainty-source attribution and structural bottlenecks
- **5a** TES service to decision-uncertainty structure alluvial.
- **5b** Continuous decision-margin Shapley variance attribution.
- **5c** Categorical selected-state Shapley information attribution.
- **5d** Service coverage lost to registered property domains.
- **5e** Atomic evidence unlock contribution.
- **5f** Seven service-specific evidence-closure-depth responses.
- **5g** Pearson–Spearman performance–evidence dependence and near-zero inset.

### Figure 6 | Decision-boundary back-tracing and evidence priorities
- **6a** Current state → precedence-valid action → endpoint alluvial.
- **6b** Complete minimum admissible action-set matrix for scientifically evaluable candidate–service pairs.
- **6c** Registered action decision-benefit forest.
- **6d** Ordinal evidence burden versus decision benefit.
- **6e** Candidate selection-frequency redistribution for |Δ| ≥1%.
- **6f** Service-level research-priority and stopping-rule composition.

## Supplementary figures

### Supplementary Figure 1 | Database curation and chemistry-family structure
- **S1a** Formula-system component count versus composition-record count.
- **S1b** Raw-database versus curated-registry chemistry-family composition.
- **S1c** Non-zero lower-bound application compatibility heatmap.

### Supplementary Figure 2 | Provenance linkage and atomic credibility
- **S2a** Candidate database/provenance match lollipop with numerical match badges.
- **S2b** Candidate atomic-credibility heatmap.

### Supplementary Figure 3 | Unique thermophysical profiles
- **S3** Column-normalized deterministic thermophysical profile heatmap after exact-duplicate collapse.

### Supplementary Figure 4 | Pairwise performance and material-cost boundary
- **S4a** Pairwise energy-density superiority probabilities with endpoint badges.
- **S4b** Conditional raw-material-cost 5–95% forest with median badges.

### Supplementary Figure 5 | Complete-service overclaim penalty
- **S5** Partial-overlap energy-overclaim lollipop with overclaim and coverage annotations.

### Supplementary Figure 6 | Threshold sensitivity and convergence
- **S6a** Full seven-service 630-state coverage–evidence regime registry.
- **S6b** Evidence-threshold response of expected strict-complete candidate count.
- **S6c** Independent Monte Carlo convergence of modal-frequency error.

### Supplementary Figure 7 | Atomic evidence interval profiles
- **S7a** Corrosion credibility intervals.
- **S7b** Cycling/phase credibility intervals.
- **S7c** Containment credibility intervals.

### Supplementary Figure 8 | Omission sensitivity
- **S8a** Candidate-omission decisiveness scatter.
- **S8b** Exact source-omission outcome-group heatmap.

### Supplementary Figure 9 | Credibility shortfall and model sensitivity
- **S9a** Unique credibility-shortfall profile heatmap.
- **S9b** Non-zero model-structure sensitivity.

### Supplementary Figure 10 | Readiness and candidate archetypes
- **S10a** Deduplicated readiness profiles.
- **S10b** PCM strict-complete probabilities.
- **S10c** Bounded-candidate multiplicity.
- **S10d** Exploratory candidate archetype clusters.

### Supplementary Figure 11 | Complementary evidence-action diagnostics
- **S11a** Registered evidence-action ordinal burden.
- **S11b** Action-to-evidence-dimension closure matrix.
- **S11c** Non-zero gate-pair interaction diagnostics.
- **S11d** Programme non-additivity and complementarity.
- **S11e** Favourable, adverse and interpretation-boundary outcome registry.


## Global submission typography and layout checks
- Legends requested above axes are single-row and outside data fields.
- Obsolete legend reserve space is removed.
- Lollipop/forest endpoints use consistent numerical badges where scientifically useful.
- Chemical formulae and units use mathtext subscripts/superscripts, including sCO$_2$, MgCl$_2$, kWh m$^{-3}$ and kWh$_{th}^{-1}$.
- Structurally flat or repeated services are compressed rather than redrawn.
- Main and supplementary figures answer distinct questions; full-detail scans remain supplementary.
- Registered DAG semantics are explicit: containment qualification requires corrosion compatibility; independent replication requires data completeness; atomic cycling can begin independently within a defensible service window.
'''
    (DOCS/'FIGURE_AND_PANEL_CHECKLIST.md').write_text(checklist,encoding='utf-8')
    rel=pd.DataFrame([
        ('Fig1','Supp1–3','Evidence provenance and contraction','Supplement contains complete source, formula and property registries.'),
        ('Fig2','Supp3–5','Frozen strict decisions','Supplement contains every candidate distribution and no-selection diagnostic.'),
        ('Fig3','Supp6–7','Compact regime shares and non-degenerate boundaries','Supplement shows the full 630-state registry, evidence-threshold candidate response and complete preference grids; it does not repeat the main coverage-response curves.'),
        ('Fig4','Supp8–10','Robust Pareto conclusions','Supplement retains all candidate frontiers, covariance and dependence records.'),
        ('Fig5','Supp9–11','Separated attribution, bottlenecks and closure-depth response','Supplement retains full attribution and gate-interaction diagnostics without redrawing closure-depth curves.'),
        ('Fig6','Supp11','Actionable paths, minimum sets, redistribution and stopping rules','Supplement retains interaction and programme-complementarity diagnostics without redrawing main action matrices or redistribution effects.')],columns=['main_figure','supplement','main_role','nonduplication_rule'])
    rel.to_csv(QA/f'{V}_MAIN_SUPPLEMENT_RELATIONSHIP.csv',index=False)
    style={'native_width_mm':180,'font_family':'Arial (strict system-font requirement)','body_pt':8.0,'axis_pt':7.1,'tick_pt':6.5,'legend_pt':6.3,'panel_letter_pt':9.1,'main_figure_rule':'one dominant anchor plus non-redundant mechanism panels','zero_flat_rule':'do not render all-zero, singleton or repeated-flat states as standalone main panels','annotation_rule':'endpoint badges remain inside axes where possible; leader lines used for displaced labels','typography_rule':'chemical formulae and units use mathtext subscripts/superscripts','scientific_boundary':'statistical strict, Pareto, attribution and DAG definitions unchanged'}
    (ROOT/'config'/'visual_style_lock.json').write_text(json.dumps(style,indent=2),encoding='utf-8')


def build_qa():
    rows=[]
    for kind,folder,prefix,n in [('main',MAIN,'Fig',6),('supplementary',SUPP,'Supp_Fig',11)]:
        for i in range(1,n+1):
            png=folder/f'{V}_{prefix}{i}.png'; pdf=folder/f'{V}_{prefix}{i}.pdf'
            with Image.open(png) as im:
                width,height=im.size
            rows.append({'figure_type':kind,'figure':f'{prefix}{i}','png_exists':png.exists(),'pdf_exists':pdf.exists(),'width_px':width,'height_px':height,'aspect_ratio':width/height,'png_bytes':png.stat().st_size,'pdf_bytes':pdf.stat().st_size})
    idx=pd.DataFrame(rows); idx.to_csv(QC/'figure_index.csv',index=False)

    fig2e=pd.read_csv(QA/'fig2e_stack_audit.csv')
    fig3c=pd.read_csv(QA/'fig3c_breakpoint_audit.csv')
    fig1a=pd.read_csv(QA/'fig1a_stage_mapping_audit.csv')
    expected_fig1a_labels=['Raw database','Melting data','Service-compatible','Minimum coverage']
    expected_fig1a_steps=[
        'Raw MSD-TP composition records',
        'Melting temperature available',
        'Application-specific melting/phase lower-bound compatibility',
        'Minimum thermophysical coverage (melting + at least two fields)',
    ]
    expected_fig1a_counts=[976,937,250,74]
    fig1a_mapping_ok=(
        fig1a.display_label.astype(str).tolist()==expected_fig1a_labels
        and fig1a.screen_step.astype(str).tolist()==expected_fig1a_steps
        and pd.to_numeric(fig1a.retained_count,errors='coerce').tolist()==expected_fig1a_counts
    )
    dag=read('evidence_action_dag_registry',STAT).copy()
    prereq=dag.set_index('action_id').prerequisite_dimensions.fillna('').astype(str).to_dict()
    dag_semantics=(prereq.get('system_containment_qualification')=='corrosion_compatibility'
                   and prereq.get('independent_replication')=='data_completeness'
                   and prereq.get('long_duration_cycling')=='')
    precise_labels=all(
        str(lbl)==('0' if abs(float(v))<5e-4 else f'{float(v):.2f}')
        for lbl,v in zip(fig3c.from_label,fig3c['from'])
    ) and all(
        str(lbl)==('0' if abs(float(v))<5e-4 else f'{float(v):.2f}')
        for lbl,v in zip(fig3c.to_label,fig3c['to'])
    )
    rules=[
        ('Six main and eleven supplementary figures rendered',len(idx)==17),
        ('Fig. 1a labels map to the registered screening stages and frozen counts',bool(fig1a_mapping_ok)),
        ('All PNG/PDF pairs exist',bool(idx.png_exists.all() and idx.pdf_exists.all())),
        ('Exact 180-mm native width',bool((idx.width_px==2126).all())),
        ('Fig. 2e pathway stacks conserve every service share',bool(np.allclose(fig2e.total_share,1.0,atol=1e-12))),
        ('Fig. 2e preserves registered Coal and CSP no-selection shares',bool((fig2e.loc[fig2e.scenario.isin(['coal_flexibility_storage','csp_sensible_storage']),'no_selection_share']>0).all())),
        ('Fig. 3c expected counts retain two-decimal precision rather than integer truncation',bool(precise_labels)),
        ('Three non-degenerate joint-regime maps retained; four flat services compressed',int(read('service_regime_archetype_summary',V).main_map_informative.sum())==3),
        ('No ordinary ANOVA applied to categorical candidate identity',not read('categorical_selection_information_attribution',STAT).method.str.contains(r'(?<!no linear )ANOVA',case=False,regex=True).any()),
        ('Robust Pareto designation requires ≥50% membership',((read('pareto_joint_uncertainty_and_robustness',STAT).threshold_50_member)==(read('pareto_joint_uncertainty_and_robustness',STAT).frontier_membership_frequency>=.5)).all()),
        ('Registered DAG prerequisites match the implemented scientific rationale',bool(dag_semantics)),
        ('Rejected DAG routes are explicitly audited and never evaluated as decision-changing paths',len(read('inadmissible_action_combination_audit',STAT))>0 and read('inadmissible_action_combination_audit',STAT).rejection_reason.astype(str).str.contains('requires',case=False).all()),
        ('Arial font available and explicitly locked',any(f.name=='Arial' for f in mpl.font_manager.fontManager.ttflist) or os.environ.get('ALLOW_ARIAL_FALLBACK','0')=='1'),
        ('Pareto right-edge annotations are inward and not axis-clipped',"clip_on=False,ha=ha" in Path(__file__).read_text(encoding='utf-8')),
        ('Fig. 4e Pareto breadth badges are drawn once',Path(__file__).read_text(encoding='utf-8').split('def build_qa():')[0].count("value_badge(axe,float(r.pareto),i,str(int(r.pareto))") == 1),
        ('Chemical subscripts rendered through mathtext labels',SERVICE['sco2_high_temperature_storage']==r'sCO$_2$'),
        ('Fig. 5f shared legend is centred above the seven-panel strip',"bbox_to_anchor=(.5,1.18)" in Path(__file__).read_text(encoding='utf-8') and "if k==3:" in Path(__file__).read_text(encoding='utf-8')),
        ('Fig. 5f strip uses asymmetric centring margins to align with paired panels above',"width_ratios=[.70,1,1,1,1,1,1,1,1.60]" in Path(__file__).read_text(encoding='utf-8')),
    ]
    pd.DataFrame(rules,columns=['rule','passed']).to_csv(QA/'release_gate.csv',index=False)
    status={'status':'PASS' if all(x[1] for x in rules) else 'REVIEW','main_figures':6,'supplementary_figures':11,'active_renderer':'src/run_postprocess.py','legacy_version_call_chain':False,'science_changed':False,'dag_semantics':'containment requires corrosion; independent replication requires data completeness; atomic cycling has no artificial universal predecessor'}
    (QC/f'{V}_POSTPROCESS_STATUS.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
    return status


def render_all():
    # Clean renderer-owned artefacts only.  Do not delete the environment or
    # upstream-contract status files created by the release pipeline before
    # rendering; those files are consumed by final release validation.
    for folder in [MAIN,SUPP,CONTACT,QA]:
        for p in folder.glob(f'{V}_*'):
            if p.is_file():
                p.unlink()
    for name in [f'{V}_POSTPROCESS_STATUS.json', 'figure_index.csv', 'pdf_font_audit.csv', 'postprocess_release_gate.csv', 'postprocess_validation_status.json', 'POSTPROCESS_RELEASE_STATUS.json', 'POSTPROCESS_RELEASE_CONTRACT_AUDIT.json']:
        p = QC / name
        if p.exists():
            p.unlink()
    fig1(); fig2(); fig3(); fig4(); fig5(); fig6()
    for i in [1,2,3,4,5,7,8,9,10]: supp_base(i)
    supp6()
    supp11()
    make_contact([MAIN/f'{V}_Fig{i}.png' for i in range(1,7)],CONTACT/f'{V}_main_figures_contact_sheet.jpg',2,1250)
    make_contact([SUPP/f'{V}_Supp_Fig{i}.png' for i in range(1,12)],CONTACT/f'{V}_supplementary_figures_contact_sheet.jpg',3,900)
    write_docs(); pd.DataFrame(FIGURE_RECORDS).to_csv(QA/'figure_source_map.csv',index=False); status=build_qa(); print(json.dumps(status,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--render-key',default='all'); args=ap.parse_args()
    funcs={f'fig{i}':globals()[f'fig{i}'] for i in range(1,7)}|{f'supp{i}':(lambda n=i:supp_base(n)) for i in [1,2,3,4,5,7,8,9,10]}|{'supp6':supp6}|{'supp11':supp11}
    if args.render_key=='all': render_all()
    elif args.render_key in funcs: funcs[args.render_key]()
    else: raise SystemExit(f'Unknown render key: {args.render_key}')
