from __future__ import annotations
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
for name in ["main_figures", "supplementary_figures", "contact_sheets", "qa", "qc"]:
    path = OUT / name
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)
print("Postprocess generated figures and local QC cleaned; synced upstream tables/QC preserved.")
