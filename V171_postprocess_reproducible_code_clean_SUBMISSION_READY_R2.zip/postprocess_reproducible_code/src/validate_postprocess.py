from __future__ import annotations

from pathlib import Path
import hashlib
import json
import os
import re
import sys

import numpy as np
import pandas as pd
from PIL import Image

try:
    import fitz  # PyMuPDF
except Exception:
    fitz = None


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
QC = OUT / "qc"
QA = OUT / "qa"
TABLES = OUT / "tables"
VERSION = "submission"
STATISTICAL_VERSION = "statistical"

QC.mkdir(parents=True, exist_ok=True)

checks: list[tuple[str, bool]] = []


def add_check(name: str, passed: object) -> None:
    """Append one release-gate check as an explicit Python bool."""
    checks.append((name, bool(passed)))


def read_csv_or_empty(path: Path, required_columns: tuple[str, ...] = ()) -> pd.DataFrame:
    """Read a CSV safely; return an empty typed frame when absent or invalid."""
    if not path.is_file():
        return pd.DataFrame(columns=list(required_columns))
    try:
        frame = pd.read_csv(path)
    except Exception:
        return pd.DataFrame(columns=list(required_columns))
    for column in required_columns:
        if column not in frame.columns:
            frame[column] = pd.Series(dtype="object")
    return frame


def figure_number(value: object, prefix: str) -> int:
    """Extract a numeric figure identifier from values such as Fig5 or Supp_Fig11."""
    text = str(value)
    text = text.replace(prefix, "", 1)
    return int(text)


def expected_figure_paths(row: object) -> tuple[Path, Path]:
    figure_type = str(row.figure_type)
    if figure_type == "main":
        folder = OUT / "main_figures"
        prefix = "Fig"
    elif figure_type == "supplementary":
        folder = OUT / "supplementary_figures"
        prefix = "Supp_Fig"
    else:
        raise ValueError(f"Unknown figure_type: {figure_type}")
    number = figure_number(row.figure, prefix)
    stem = f"{VERSION}_{prefix}{number}"
    return folder / f"{stem}.png", folder / f"{stem}.pdf"


def source_tables_for(source: pd.DataFrame, figure: str) -> str:
    if not {"figure", "source_tables"}.issubset(source.columns):
        return ""
    rows = source.loc[source["figure"].astype(str).eq(figure), "source_tables"]
    if rows.empty:
        return ""
    return ";".join(rows.fillna("").astype(str).tolist())


def contains_source(source: pd.DataFrame, figure: str, pattern: str) -> bool:
    return bool(re.search(pattern, source_tables_for(source, figure)))


def project_owned_files(root: Path):
    """
    Yield only project-owned files while pruning environments, caches and
    third-party dependencies before descent.

    Matplotlib legitimately installs files such as
    ``seaborn-v0_8-*.mplstyle`` under ``.venv/Lib/site-packages``. Those are
    dependency files, not generated or historical project artefacts.
    """
    ignored_directory_names = {
        ".venv",
        "venv",
        "env",
        "site-packages",
        "__pycache__",
        ".git",
        ".github",
        ".vscode",
        ".idea",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
    }

    for directory, subdirectories, filenames in os.walk(root, topdown=True):
        subdirectories[:] = [
            name
            for name in subdirectories
            if name.lower() not in ignored_directory_names
        ]
        base = Path(directory)
        for filename in filenames:
            yield base / filename


# ---------------------------------------------------------------------------
# Figure inventory, raster integrity and PDF/font audit
# ---------------------------------------------------------------------------
index_path = QC / "figure_index.csv"
index = read_csv_or_empty(
    index_path,
    required_columns=(
        "figure",
        "figure_type",
        "png_exists",
        "pdf_exists",
        "width_px",
    ),
)

valid_inventory = (
    len(index) == 17
    and index["figure"].astype(str).nunique() == 17
    and int(index["figure_type"].astype(str).eq("main").sum()) == 6
    and int(index["figure_type"].astype(str).eq("supplementary").sum()) == 11
)
add_check("Six main and eleven supplementary figures indexed", valid_inventory)

if len(index):
    png_flags = index["png_exists"].fillna(False).astype(bool)
    pdf_flags = index["pdf_exists"].fillna(False).astype(bool)
    files_declared = bool(png_flags.all() and pdf_flags.all())
    width_values = pd.to_numeric(index["width_px"], errors="coerce")
    exact_width = bool(width_values.notna().all() and width_values.eq(2126).all())
else:
    files_declared = False
    exact_width = False

add_check("All PNG and PDF figure files exist", files_declared)
add_check("All figures use exact 2126-pixel 180-mm width at 300 dpi", exact_width)

png_ok = bool(valid_inventory)
pdf_ok = bool(valid_inventory and fitz is not None)
pdf_font_rows: list[dict[str, object]] = []
strict_arial = os.environ.get("ALLOW_ARIAL_FALLBACK", "0") != "1"

if valid_inventory:
    for row in index.itertuples(index=False):
        try:
            png_path, pdf_path = expected_figure_paths(row)
        except Exception:
            png_ok = False
            pdf_ok = False
            continue

        try:
            with Image.open(png_path) as image:
                image.verify()
        except Exception:
            png_ok = False

        names: list[str] = []
        if fitz is None:
            pdf_ok = False
        else:
            try:
                document = fitz.open(pdf_path)
                if len(document) < 1:
                    pdf_ok = False
                for page in document:
                    names.extend(str(item[3]) for item in page.get_fonts(full=True))
                document.close()
            except Exception:
                pdf_ok = False

        unique_names = sorted(set(names))
        pdf_font_rows.append(
            {
                "figure": str(row.figure),
                "fonts": ";".join(unique_names),
                "arial_present": any("Arial" in name for name in unique_names),
                "forbidden_fallback_present": any(
                    token in name
                    for name in unique_names
                    for token in ("DejaVu", "Liberation", "Arimo")
                ),
            }
        )

add_check("All PNG files pass image-integrity validation", png_ok)
add_check("All PDFs open and contain at least one page", pdf_ok)

font_columns = [
    "figure",
    "fonts",
    "arial_present",
    "forbidden_fallback_present",
]
font_audit = pd.DataFrame(pdf_font_rows, columns=font_columns)
font_audit.to_csv(QC / "pdf_font_audit.csv", index=False)

if strict_arial:
    font_ok = (
        len(font_audit) == len(index) == 17
        and bool(font_audit["arial_present"].fillna(False).all())
        and bool((~font_audit["forbidden_fallback_present"].fillna(True)).all())
    )
else:
    # CI smoke tests may permit fallback, but every PDF must still be audited.
    font_ok = len(font_audit) == len(index) == 17
add_check("Submission PDFs embed Arial and no silent fallback font", font_ok)


# ---------------------------------------------------------------------------
# Scientific/visual release gates and source-map non-duplication checks
# ---------------------------------------------------------------------------
release_gate = read_csv_or_empty(QA / "release_gate.csv", ("passed",))
release_gate_pass = (
    len(release_gate) > 0
    and bool(release_gate["passed"].fillna(False).astype(bool).all())
)
add_check("Scientific and visual release gate passes", release_gate_pass)

source = read_csv_or_empty(
    QA / "figure_source_map.csv", ("figure", "source_tables")
)
source_map_complete = (
    len(source) == 17
    and source["figure"].astype(str).nunique() == 17
    and not source["source_tables"].fillna("").astype(str).str.strip().eq("").any()
)
add_check("Every rendered figure has one current source-map entry", source_map_complete)

fig1a = read_csv_or_empty(
    QA / "fig1a_stage_mapping_audit.csv",
    ("display_label", "screen_step", "retained_count"),
)
fig1a_ok = (
    fig1a["display_label"].astype(str).tolist()
    == ["Raw database", "Melting data", "Service-compatible", "Minimum coverage"]
    and fig1a["screen_step"].astype(str).tolist()
    == [
        "Raw MSD-TP composition records",
        "Melting temperature available",
        "Application-specific melting/phase lower-bound compatibility",
        "Minimum thermophysical coverage (melting + at least two fields)",
    ]
    and pd.to_numeric(fig1a["retained_count"], errors="coerce").tolist()
    == [976, 937, 250, 74]
)
add_check(
    "Fig. 1a uses the registered stage labels and frozen retained-record counts",
    fig1a_ok,
)

active_path = ROOT / "src" / "run_postprocess.py"
active = active_path.read_text(encoding="utf-8") if active_path.is_file() else ""
add_check(
    "Single active renderer is present",
    active_path.is_file() and "import run_postprocess_" not in active,
)
add_check(
    "Categorical and continuous attribution remain explicitly separated",
    "categorical state" in active and "continuous margin" in active,
)
add_check(
    "Main Fig. 5 uses service-specific closure depth",
    contains_source(source, "Fig5", r"gate_closure_depth_response"),
)
add_check(
    "Supplementary Fig. 11 does not redraw main closure-depth response",
    not contains_source(source, "Supp_Fig11", r"gate_closure_depth_response"),
)
add_check(
    "Main Fig. 6 contains complete minimum action sets and candidate redistribution",
    contains_source(source, "Fig6", r"dag_constrained_minimal_action_sets")
    and contains_source(source, "Fig6", r"counterfactual_candidate_signed_changes"),
)
add_check(
    "Supplementary Fig. 11 does not repeat minimum-set or redistribution panels",
    not contains_source(
        source,
        "Supp_Fig11",
        r"dag_constrained_minimal_action_sets|counterfactual_candidate_signed_changes",
    ),
)
add_check(
    "Fig. 3 and Supplementary Fig. 6 answer distinct threshold questions",
    bool(
        source_tables_for(source, "Fig3")
        and source_tables_for(source, "Supp_Fig6")
        and source_tables_for(source, "Fig3")
        != source_tables_for(source, "Supp_Fig6")
    ),
)


# ---------------------------------------------------------------------------
# Typography, active renderer and known figure-regression checks
# ---------------------------------------------------------------------------
add_check(
    "Chemical and unit typography uses mathtext conversion",
    "scenario_code(s)" in active and "kWh m$^{-3}$" in active,
)
add_check(
    "Arial is the required ordinary-text font",
    "'font.family':_TEXT_FONT" in active and "findfont('Arial'" in active,
)

support_path = ROOT / "src" / "certified_figure_support.py"
support = support_path.read_text(encoding="utf-8") if support_path.is_file() else ""
add_check(
    "Certified support preserves the same strict Arial mathtext policy",
    "FONT = _TEXT_FONT" in support
    and '"mathtext.fontset": "custom"' in support
    and "def resolve_font" not in support,
)
add_check(
    "No release-version token occurs in the active renderer",
    active_path.is_file() and not bool(re.search(r"(?i)\bvv\d+", active)),
)
add_check(
    "Fig. 5f shared legend is centred above the seven-panel strip",
    "bbox_to_anchor=(.5,1.18)" in active and "if k==3:" in active,
)
add_check(
    "Fig. 5f strip is narrowed and aligned to the paired panels above",
    "width_ratios=[.70,1,1,1,1,1,1,1,1.60]" in active,
)

fig2e = read_csv_or_empty(
    QA / "fig2e_stack_audit.csv",
    ("scenario", "total_share", "no_selection_share"),
)
fig2e_total = pd.to_numeric(fig2e["total_share"], errors="coerce")
add_check(
    "Fig. 2e service pathways sum to one after explicit NaN-to-zero handling",
    len(fig2e) > 0
    and fig2e_total.notna().all()
    and np.allclose(fig2e_total.to_numpy(dtype=float), 1.0, atol=1e-12),
)

coal_csp = fig2e.loc[
    fig2e["scenario"].astype(str).isin(
        ["coal_flexibility_storage", "csp_sensible_storage"]
    )
]
coal_csp_no_selection = pd.to_numeric(
    coal_csp["no_selection_share"], errors="coerce"
)
add_check(
    "Fig. 2e preserves non-zero Coal and CSP no-selection segments",
    len(coal_csp) == 2
    and coal_csp_no_selection.notna().all()
    and bool((coal_csp_no_selection > 0).all()),
)

fig3c = read_csv_or_empty(
    QA / "fig3c_breakpoint_audit.csv",
    ("from_label", "to_label", "from", "to"),
)


def format_expected_count(value: object) -> str:
    number = float(value)
    return "0" if abs(number) < 5e-4 else f"{number:.2f}"


precise = False
if len(fig3c):
    try:
        precise = all(
            str(label) == format_expected_count(value)
            for label, value in zip(fig3c["from_label"], fig3c["from"])
        ) and all(
            str(label) == format_expected_count(value)
            for label, value in zip(fig3c["to_label"], fig3c["to"])
        )
    except Exception:
        precise = False
add_check("Fig. 3c labels preserve expected-count precision", precise)

add_check(
    "Fig. 4 right-edge annotations are inward and not clipped",
    "clip_on=False,ha=ha" in active
    and "representative_performance_score >= .90" in active,
)

renderer_before_qa = active.split("def build_qa():", 1)[0]
pareto_badge_call = "value_badge(axe,float(r.pareto),i,str(int(r.pareto))"
add_check(
    "Fig. 4e contains only one Pareto breadth badge loop",
    renderer_before_qa.count(pareto_badge_call) == 1,
)


# ---------------------------------------------------------------------------
# Evidence-action DAG semantics
# ---------------------------------------------------------------------------
dag = read_csv_or_empty(
    TABLES / f"{STATISTICAL_VERSION}_evidence_action_dag_registry.csv",
    ("action_id", "prerequisite_dimensions"),
)
prerequisites = (
    dag.set_index("action_id")["prerequisite_dimensions"]
    .fillna("")
    .astype(str)
    .to_dict()
    if len(dag) and dag["action_id"].astype(str).is_unique
    else {}
)
dag_ok = (
    prerequisites.get("system_containment_qualification")
    == "corrosion_compatibility"
    and prerequisites.get("independent_replication") == "data_completeness"
    and prerequisites.get("long_duration_cycling") == ""
)
add_check("DAG prerequisite semantics match the implemented registry", dag_ok)


# ---------------------------------------------------------------------------
# Clean-package audit: project-owned files only
# ---------------------------------------------------------------------------
historical_artifacts: list[str] = []
version_pattern = re.compile(r"(?i)(?:^|[_-])v\d+(?:[_-]|$)")
for path in project_owned_files(ROOT):
    relative = path.relative_to(ROOT)
    if version_pattern.search(path.name):
        historical_artifacts.append(str(relative))
historical_artifacts.sort()
add_check(
    "No version-numbered project artefact remains in the clean package",
    len(historical_artifacts) == 0,
)

python_hashes: dict[str, list[str]] = {}
for path in sorted((ROOT / "src").glob("*.py")):
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    python_hashes.setdefault(digest, []).append(path.name)
duplicate_python_groups = sorted(
    (sorted(group) for group in python_hashes.values() if len(group) > 1),
    key=lambda group: group[0],
)
add_check(
    "No duplicate Python source files by SHA-256",
    len(duplicate_python_groups) == 0,
)


# ---------------------------------------------------------------------------
# Write canonical validation outputs and fail closed
# ---------------------------------------------------------------------------
release_gate_frame = pd.DataFrame(checks, columns=["check", "passed"])
release_gate_frame.to_csv(QC / "postprocess_release_gate.csv", index=False)

status = "PASS" if bool(release_gate_frame["passed"].all()) else "FAIL"
output = {
    "status": status,
    "science_changed": False,
    "checks": int(len(release_gate_frame)),
    "checks_passed": int(release_gate_frame["passed"].sum()),
    "main_figures": 6,
    "supplementary_figures": 11,
    "active_renderer": "src/run_postprocess.py",
    "historical_artifacts": historical_artifacts,
    "duplicate_python_groups": duplicate_python_groups,
    "clean_scan_policy": (
        "Only project-owned files are scanned. Virtual environments, caches "
        "and site-packages are excluded before directory descent."
    ),
}

(QC / "postprocess_validation_status.json").write_text(
    json.dumps(output, indent=2, ensure_ascii=False),
    encoding="utf-8",
)
print(json.dumps(output, indent=2, ensure_ascii=False))

if status != "PASS":
    failed = release_gate_frame.loc[~release_gate_frame["passed"]]
    if len(failed):
        print(failed.to_string(index=False))
    sys.exit(2)
