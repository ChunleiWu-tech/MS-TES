from __future__ import annotations
from pathlib import Path
import csv
import json
import sys

from release_paths import UPSTREAM_RELEASE_STATUS, UPSTREAM_RELEASE_STATUS_COMPAT, first_existing

if len(sys.argv) != 2:
    raise SystemExit('Usage: verify_upstream_sync.py UPSTREAM_ROOT')
root = Path(sys.argv[1]).resolve()
table = root / 'outputs' / 'tables' / 'core_system_value_monte_carlo_summary.csv'
qc = root / 'outputs' / 'qc'
status_path = first_existing(qc, UPSTREAM_RELEASE_STATUS, UPSTREAM_RELEASE_STATUS_COMPAT)
if not table.exists():
    raise SystemExit(f'Missing upstream Monte Carlo summary: {table}')
if status_path is None:
    raise SystemExit(
        f'Missing final upstream release status. Expected {qc / UPSTREAM_RELEASE_STATUS} '
        f'or compatibility alias {qc / UPSTREAM_RELEASE_STATUS_COMPAT}.'
    )
with table.open(newline='', encoding='utf-8') as handle:
    rows = csv.DictReader(handle)
    values = sorted({int(float(row['mc_iterations'])) for row in rows})
if values != [20000]:
    raise SystemExit(f'Upstream outputs are not the registered 20,000-draw result: {values}')
status = json.loads(status_path.read_text(encoding='utf-8'))
if status.get('status') != 'PASS' or status.get('science_changed') is not False:
    raise SystemExit(f'Final upstream status is not an unchanged PASS: {status}')
if status.get('mc_iterations') != 20000:
    raise SystemExit(f'Canonical upstream status does not declare 20,000 draws: {status}')
compat = qc / UPSTREAM_RELEASE_STATUS_COMPAT
canonical = qc / UPSTREAM_RELEASE_STATUS
if canonical.exists() and compat.exists():
    if json.loads(canonical.read_text(encoding='utf-8')) != json.loads(compat.read_text(encoding='utf-8')):
        raise SystemExit('Canonical upstream release status and compatibility alias disagree.')
print(f'Verified registered 20,000-draw upstream outputs and final PASS status from {status_path.name}.')
