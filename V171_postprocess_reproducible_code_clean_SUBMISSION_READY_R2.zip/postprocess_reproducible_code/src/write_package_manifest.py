from __future__ import annotations
from pathlib import Path
import hashlib
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "PACKAGE_MANIFEST.csv"
SHA_MANIFEST = ROOT / "PACKAGE_MANIFEST_SHA256.csv"
SHA_TEXT = ROOT / "PACKAGE_SHA256SUMS.txt"
EXCLUDED_DIRS = {".venv", ".git", ".github", ".vscode", ".idea", "__pycache__"}
EXCLUDED_FILES = {MANIFEST, SHA_MANIFEST, SHA_TEXT}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def included(path: Path) -> bool:
    if not path.is_file() or path in EXCLUDED_FILES or path.suffix == ".pyc":
        return False
    relative = path.relative_to(ROOT)
    if any(part in EXCLUDED_DIRS for part in relative.parts):
        return False
    # The public source package never manifests generated tables, figures or
    # QC.  Only the explanatory outputs/README.md is part of the archive.
    if relative.parts and relative.parts[0] == "outputs":
        return relative.as_posix() == "outputs/README.md"
    return True


rows = []
for path in sorted(ROOT.rglob("*")):
    if not included(path):
        continue
    rows.append({
        "relative_path": path.relative_to(ROOT).as_posix(),
        "size_bytes": path.stat().st_size,
        "sha256": sha256(path),
    })
frame = pd.DataFrame(rows)
frame[["relative_path", "size_bytes"]].to_csv(MANIFEST, index=False)
frame.to_csv(SHA_MANIFEST, index=False)
SHA_TEXT.write_text("".join(f"{r.sha256}  {r.relative_path}\n" for r in frame.itertuples(index=False)), encoding="utf-8")
print({"status": "PASS", "manifest_rows": len(frame), "excluded_directories": sorted(EXCLUDED_DIRS)})
