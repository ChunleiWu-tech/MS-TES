from __future__ import annotations
from pathlib import Path
import json
import sys
import pandas as pd

from release_paths import UPSTREAM_RELEASE_STATUS, UPSTREAM_RELEASE_STATUS_COMPAT, first_existing

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'outputs' / 'tables'
UQC = ROOT / 'outputs' / 'upstream_qc'
QC = ROOT / 'outputs' / 'qc'
QC.mkdir(parents=True, exist_ok=True)
V = 'submission'
required = [
    'core_candidate_readiness_profile.csv','core_joint_threshold_regime_map.csv',
    'core_candidate_service_coverage_map.csv','statistical_decision_scope_matrix.csv',
    'statistical_pareto_joint_uncertainty_and_robustness.csv',
    'statistical_continuous_decision_variance_attribution.csv',
    'statistical_categorical_selection_information_attribution.csv',
    'statistical_dag_constrained_minimal_action_sets.csv',
    'submission_service_regime_archetype_summary.csv','submission_pareto_dominance_mechanism_summary.csv',
    'submission_property_domain_contraction_summary.csv','submission_atomic_evidence_unlock_summary.csv',
    'submission_nonzero_gate_interaction_summary.csv','submission_research_action_frontier_summary.csv',
    'submission_candidate_research_priority_summary.csv',
]
rows = [{'file': f, 'exists': (TABLES / f).exists()} for f in required]
frame = pd.DataFrame(rows)
frame.to_csv(QC / f'{V}_UPSTREAM_CONTRACT.csv', index=False)
stat_path = first_existing(UQC, UPSTREAM_RELEASE_STATUS, UPSTREAM_RELEASE_STATUS_COMPAT)
stat = json.loads(stat_path.read_text(encoding='utf-8')) if stat_path else {}
mc_path = TABLES / 'core_system_value_monte_carlo_summary.csv'
mc_iterations: list[int] = []
if mc_path.exists():
    mc_frame = pd.read_csv(mc_path, usecols=['mc_iterations'])
    mc_iterations = sorted(set(pd.to_numeric(mc_frame.mc_iterations, errors='coerce').dropna().astype(int).tolist()))
registered_mc_ok = mc_iterations == [20000]
status_alias_ok = True
canonical = UQC / UPSTREAM_RELEASE_STATUS
compat = UQC / UPSTREAM_RELEASE_STATUS_COMPAT
if canonical.exists() and compat.exists():
    status_alias_ok = json.loads(canonical.read_text(encoding='utf-8')) == json.loads(compat.read_text(encoding='utf-8'))
out = {
    'version': V,
    'status': 'PASS' if frame.exists.all() and stat.get('status') == 'PASS' and stat.get('science_changed') is False and registered_mc_ok and status_alias_ok else 'FAIL',
    'required_tables': len(frame),
    'tables_present': int(frame.exists.sum()),
    'upstream_status': stat.get('status', 'MISSING'),
    'upstream_status_file': stat_path.name if stat_path else 'MISSING',
    'science_changed': stat.get('science_changed'),
    'registered_mc_iterations_required': 20000,
    'mc_iterations_found': mc_iterations,
    'registered_mc_ok': registered_mc_ok,
    'status_alias_consistent': status_alias_ok,
}
(QC / f'{V}_UPSTREAM_CONTRACT_STATUS.json').write_text(json.dumps(out, indent=2), encoding='utf-8')
print(json.dumps(out, indent=2))
if out['status'] != 'PASS':
    sys.exit(2)
