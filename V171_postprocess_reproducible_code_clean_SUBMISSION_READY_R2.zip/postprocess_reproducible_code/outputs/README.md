# Generated outputs

This directory is intentionally empty in the submission code package. Run the package entry script to regenerate all tables, diagnostics and figures locally.
