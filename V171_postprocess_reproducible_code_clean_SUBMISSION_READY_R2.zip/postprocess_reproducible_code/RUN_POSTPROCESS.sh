#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON_EXE="${TES_PYTHON:-$PWD/.venv/bin/python}"
[[ -x "$PYTHON_EXE" ]] || { echo "Run ./SETUP_ENV.sh first, or set TES_PYTHON." >&2; exit 2; }
export PYTHONFAULTHANDLER=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
for script in clean_generated_outputs.py check_env.py check_upstream_contract.py run_postprocess.py validate_postprocess.py validate_release_contract.py write_package_manifest.py; do
  printf '\n=== Running %s ===\n' "$script"
  "$PYTHON_EXE" -X faulthandler -u "src/$script"
done
printf '\nPost-processing completed successfully.\n'
