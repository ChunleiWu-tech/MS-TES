# Post-processing and figure code

This source-only package regenerates the six main figures and eleven supplementary figures from the registered 20,000-draw upstream tables. It contains **no generated tables or images** and no font files.

## Requirements

- 64-bit CPython 3.12
- Exact packages in `requirements-lock.txt`
- Arial installed as a Windows/system font

Ordinary text uses real system Arial. Chemical formulae, units, subscripts and superscripts use Matplotlib custom mathtext with Arial as the principal family and STIX only as a missing-glyph fallback. Formal validation rejects silent Arimo, Liberation Sans or DejaVu Sans substitution.

## Windows PowerShell / VS Code

Run upstream first and wait for:

```text
Upstream full recompute completed successfully.
```

Then run:

```powershell
cd "$env:USERPROFILE\Desktop\postprocess_reproducible_code"
.\SYNC_UPSTREAM_OUTPUTS.bat "$env:USERPROFILE\Desktop\upstream_reproducible_code"
.\SETUP_ENV.bat
.\RUN_POSTPROCESS.bat
```

Synchronisation checks the canonical upstream status:

```text
upstream_reproducible_code\outputs\qc\UPSTREAM_RELEASE_STATUS.json
```

and rejects missing, non-PASS, science-changed or non-20,000-draw outputs.

The post-processing run is complete only when the terminal prints:

```text
Post-processing completed successfully.
```

The canonical final post-processing status is:

```text
outputs\qc\POSTPROCESS_RELEASE_STATUS.json
```

## Linux/macOS

```bash
./SYNC_UPSTREAM_OUTPUTS.sh ../upstream_reproducible_code
./SETUP_ENV.sh
./RUN_POSTPROCESS.sh
```

## Release contract

The environment, upstream contract, renderer, PDF/font audit and final validation use distinct files and cannot delete one another during the run. `validate_release_contract.py` verifies the complete filename contract and the 6-main + 11-supplementary inventory before release.
