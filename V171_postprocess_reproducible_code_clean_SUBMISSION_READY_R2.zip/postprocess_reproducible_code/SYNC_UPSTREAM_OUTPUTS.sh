#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
UPSTREAM_ROOT="${1:-../upstream_reproducible_code}"
SRC="$UPSTREAM_ROOT/outputs"
[[ -d "$SRC/tables" ]] || { echo "Upstream outputs not found: $SRC/tables" >&2; exit 2; }
VERIFY_PY="$UPSTREAM_ROOT/.venv/bin/python"
[[ -x "$VERIFY_PY" ]] || { echo "Upstream virtual environment not found. Complete the upstream setup and full run first." >&2; exit 2; }
"$VERIFY_PY" src/verify_upstream_sync.py "$UPSTREAM_ROOT"
rm -rf outputs/tables outputs/upstream_qc
mkdir -p outputs/tables outputs/upstream_qc
cp -a "$SRC/tables/." outputs/tables/
cp -a "$SRC/qc/." outputs/upstream_qc/
echo "Registered 20,000-draw upstream outputs synchronized from $UPSTREAM_ROOT"
