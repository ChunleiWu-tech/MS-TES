@echo off
setlocal
cd /d "%~dp0"
set "PYTHON_BOOTSTRAP=py -3.12"
if not "%TES_BOOTSTRAP%"=="" set "PYTHON_BOOTSTRAP=%TES_BOOTSTRAP%"
set "PIP_DISABLE_PIP_VERSION_CHECK=1"
set "PYTHONUTF8=1"
if exist .venv\Scripts\python.exe (
  .venv\Scripts\python.exe -c "import sys; raise SystemExit(0 if sys.version_info[:2]==(3,12) and sys.maxsize>2**32 else 1)"
  if errorlevel 1 rmdir /s /q .venv
)
if not exist .venv\Scripts\python.exe %PYTHON_BOOTSTRAP% -m venv .venv || exit /b 1
.venv\Scripts\python.exe -m pip install --upgrade pip || exit /b 1
.venv\Scripts\python.exe -m pip install --only-binary=:all: --requirement requirements-lock.txt || exit /b 1
.venv\Scripts\python.exe -u src\check_env.py || exit /b 1
echo Post-processing environment is ready.
endlocal
