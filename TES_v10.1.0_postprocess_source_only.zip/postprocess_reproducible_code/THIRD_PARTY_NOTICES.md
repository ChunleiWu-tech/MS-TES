
# Third-party notices

The model cites and transforms information from literature, official reports and thermophysical databases. Those sources are not relicensed by this package. Source identifiers, DOI/report identities, locators and claim boundaries are recorded in the provenance ledgers.

No Arial font file is distributed. Arial remains a locally installed system font used only for final rendering. Python packages installed from the release lock retain their respective upstream licences; no portable copy of those packages is bundled.
