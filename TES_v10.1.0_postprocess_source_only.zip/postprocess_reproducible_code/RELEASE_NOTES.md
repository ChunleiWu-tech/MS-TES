
# Release notes — TES-PUB-V10.1.0-MANUSCRIPT-AUDITED-20260816

- Unified Windows, Linux and macOS synchronization and rendering under one Python task graph.
- Removed the duplicated 342 MB upstream result mirror from the distributed post-processing source; it is recreated automatically from the sibling upstream release.
- Updated figure semantics to distinguish thermophysical opportunity, engineering-registry linkage and formal selection.
- Replaced user-facing “No formal selection” with “No formal selection”.
- Updated the 2025 PCM500 chloride opportunity to 23.48% and removed the invalid “0% formal selection” interpretation outside the registry.
- Preserved six main and twelve supplementary figure definitions; 33/33 post-processing checks passed in the validated build.
- Removed all exported PNG/PDF/contact-sheet files from distribution so the user can render locally with Arial.
