
# Runtime-synchronized data

`data/input/` and `data/provenance/` are intentionally absent from the distribution to avoid duplicating the authoritative upstream release. They are recreated by `src/sync_upstream.py` before every standard post-processing run.
