from __future__ import annotations

from pathlib import Path
import hashlib
import json
import math
import re
import textwrap
import argparse
import subprocess
import sys
from itertools import combinations

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.colors import LinearSegmentedColormap, Normalize, TwoSlopeNorm
from matplotlib.lines import Line2D
from matplotlib.ticker import FuncFormatter, NullFormatter
from matplotlib.patches import Rectangle, Patch, PathPatch
from matplotlib.path import Path as MplPath
from PIL import Image, ImageDraw

VERSION = "core"
ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
MAIN = ROOT / "outputs" / "main_figures"
SUPP = ROOT / "outputs" / "supplementary_figures"
CONTACT = ROOT / "outputs" / "contact_sheets"
QC = ROOT / "outputs" / "qc"
QA = ROOT / "outputs" / "qa"
CFG = ROOT / "config"
IN = ROOT / "data" / "input"
DOCS = ROOT / "docs"
for directory in [MAIN, SUPP, CONTACT, QC, QA, DOCS]:
    directory.mkdir(parents=True, exist_ok=True)

STYLE = json.loads((CFG / "figure_style.json").read_text(encoding="utf-8"))

# Submission typography: Arial for all ordinary text. Mathtext uses Arial where
# glyphs are available and STIX Sans only as a fallback for mathematical glyphs.
import os as _os
try:
    _ARIAL_PATH = font_manager.findfont("Arial", fallback_to_default=False)
    _TEXT_FONT = "Arial"
except Exception:
    if _os.environ.get("ALLOW_ARIAL_FALLBACK", "0") != "1":
        raise RuntimeError("Arial is required. Install Arial as a system font; no font files are bundled.")
    _TEXT_FONT = "Liberation Sans"
plt.rcParams.update({
    "font.family": _TEXT_FONT,
    "font.sans-serif": [_TEXT_FONT],
    "mathtext.fontset": "custom",
    "mathtext.rm": _TEXT_FONT,
    "mathtext.it": _TEXT_FONT + ":italic",
    "mathtext.bf": _TEXT_FONT + ":bold",
    "mathtext.fallback": "stix",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "axes.unicode_minus": False,
})

# core visual language; certified science and palette retained with audited layout refinements.
NAVY = "#405F7A"
BLUE = "#779DBB"
PALE_BLUE = "#B7CAD9"
OLIVE = "#788253"
MUSTARD = "#C7A23C"
TERRACOTTA = "#C9785E"
ROSE_LIGHT = "#D7A5A7"
ROSE = "#B76F82"
BURGUNDY = "#7F4058"
CREAM = "#D8C7A0"
INK = "#263238"
MID_GREY = "#7B878D"
LIGHT_GREY = "#E8ECEE"
VERY_LIGHT = "#F6F7F7"
POSITIVE = OLIVE
NEGATIVE = BURGUNDY
NEUTRAL = "#AEB7BC"
EPS = 1e-12

SCENARIOS = [
    "coal_flexibility_storage",
    "csp_sensible_storage",
    "industrial_medium_heat",
    "sco2_high_temperature_storage",
    "pcm_target_350C",
    "pcm_target_425C",
    "pcm_target_500C",
]
SCENARIO_LABEL = {
    "coal_flexibility_storage": "Coal flexibility",
    "csp_sensible_storage": "CSP sensible",
    "industrial_medium_heat": "Industrial heat",
    "sco2_high_temperature_storage": r"sCO$_2$ high-T",
    "pcm_target_350C": "PCM 350 °C",
    "pcm_target_425C": "PCM 425 °C",
    "pcm_target_500C": "PCM 500 °C",
}
SCENARIO_CODE = {
    "coal_flexibility_storage": "Coal",
    "csp_sensible_storage": "CSP",
    "industrial_medium_heat": "Industrial",
    "sco2_high_temperature_storage": r"sCO$_2$",
    "pcm_target_350C": "PCM350",
    "pcm_target_425C": "PCM425",
    "pcm_target_500C": "PCM500",
}
SCENARIO_COLOR = {
    "coal_flexibility_storage": NAVY,
    "csp_sensible_storage": MUSTARD,
    "industrial_medium_heat": OLIVE,
    "sco2_high_temperature_storage": TERRACOTTA,
    "pcm_target_350C": ROSE_LIGHT,
    "pcm_target_425C": ROSE,
    "pcm_target_500C": BURGUNDY,
}
GATE_ORDER = ["incomplete_service", "corrosion", "cycling_phase", "containment", "literature_validation", "data_completeness"]
GATE_LABEL = {
    "incomplete_service": "Incomplete service",
    "corrosion": "Corrosion",
    "cycling_phase": "Cycling/phase",
    "containment": "Containment",
    "literature_validation": "Literature replication",
    "data_completeness": "Data completeness",
}
ACTION_ORDER = [
    "property_measurement_precision_50pct",
    "service_redesign_95pct",
    "exact_composition_corrosion_closure",
    "pcm_cycling_phase_closure",
    "containment_validation_closure",
    "literature_replication_closure",
    "data_completeness_closure",
    "combined_atomic_evidence_closure",
    "comprehensive_upper_bound",
]
ATOMIC_ACTIONS = [
    "exact_composition_corrosion_closure",
    "pcm_cycling_phase_closure",
    "containment_validation_closure",
    "literature_replication_closure",
    "data_completeness_closure",
]
RESEARCH_ACTIONS = [
    "property_measurement_precision_50pct",
    "exact_composition_corrosion_closure",
    "pcm_cycling_phase_closure",
    "containment_validation_closure",
    "literature_replication_closure",
    "data_completeness_closure",
    "combined_atomic_evidence_closure",
]
DIAGNOSTIC_BOUNDARY_ACTIONS = [
    "service_redesign_95pct",
    "comprehensive_upper_bound",
]
ACTION_LABEL = {
    "property_measurement_precision_50pct": "Property precision",
    "service_redesign_95pct": "Service redesign",
    "exact_composition_corrosion_closure": "Exact corrosion",
    "pcm_cycling_phase_closure": "PCM cycling/phase",
    "containment_validation_closure": "Containment",
    "literature_replication_closure": "Literature replication",
    "data_completeness_closure": "Data completeness",
    "combined_atomic_evidence_closure": "Combined evidence",
    "comprehensive_upper_bound": "Comprehensive",
}
CANDIDATE_SHORT = {
    "Solar Salt SS60": "Solar Salt",
    "KNO2-KNO3-K2CO3 eutectic": "KNC",
    "NaNO3-KNO3-Na2CO3-NaCl eutectic": "QNCC",
    "MgCl2-KCl-NaCl eutectic": "MgCl2 ternary",
    "NaCl-KCl-CaCl2 eutectic (27.5-6.5-66.0 wt%)": "NKCA",
    "Na2CO3-Li2CO3-LiF S1": "Carbonate–LiF",
    "Na2CO3-Li2CO3 eutectic": "Binary carbonate",
    "HITEC": "HITEC",
    "HITEC XL": "HITEC XL",
    "Quaternary nitrate S7": "Nitrate S7",
    "No formal selection": "No selection",
    "none": "No selection",
    "__NO_SELECTION__": "No selection",
}
CANDIDATE_COLORS = {
    "Solar Salt": NAVY,
    "KNC": ROSE,
    "QNCC": MUSTARD,
    "MgCl2 ternary": TERRACOTTA,
    "NKCA": OLIVE,
    "Carbonate–LiF": ROSE_LIGHT,
    "Binary carbonate": BURGUNDY,
    "HITEC": BLUE,
    "HITEC XL": CREAM,
    "Nitrate S7": "#A48B55",
    "No selection": NEUTRAL,
}


CHEMICAL_MATHTEXT = [
    ("Ca(NO3)2", r"Ca(NO$_3$)$_2$"),
    ("sCO2", r"sCO$_2$"),
    ("Na2CO3", r"Na$_2$CO$_3$"),
    ("Li2CO3", r"Li$_2$CO$_3$"),
    ("K2CO3", r"K$_2$CO$_3$"),
    ("NaNO3", r"NaNO$_3$"),
    ("KNO3", r"KNO$_3$"),
    ("NaNO2", r"NaNO$_2$"),
    ("KNO2", r"KNO$_2$"),
    ("MgCl2", r"MgCl$_2$"),
    ("CaCl2", r"CaCl$_2$"),
    ("CO2", r"CO$_2$"),
]

def chem_label(value: str) -> str:
    """Return a Matplotlib-mathtext label with chemical subscripts.

    Arial is retained for ordinary text. Math fragments are rendered by the
    bundled STIX Sans mathtext engine, avoiding missing-glyph failures on
    systems where Arial does not contain complete superscript/subscript glyphs.
    """
    text = str(value)
    for raw, formatted in CHEMICAL_MATHTEXT:
        text = text.replace(raw, formatted)
    return text

def scenario_code(value: str) -> str:
    return chem_label(SCENARIO_CODE[str(value)])

def short_candidate(value: str) -> str:
    return chem_label(CANDIDATE_SHORT.get(str(value), str(value).replace(" eutectic", "")))


THERMOPHYSICAL_DISPLAY_COLUMNS = [
    "fixed_window_coverage",
    "cp_at_service_J_gK",
    "density_at_service_kg_m3",
    "thermal_k_at_service_W_mK",
    "complete_service_energy_fixed_kWh_m3",
]


def collapse_thermophysical_display_profiles(frame: pd.DataFrame) -> pd.DataFrame:
    """Collapse numerically identical Supplementary Fig. 3 display rows.

    The upstream table preserves candidate identity when constructing profiles.
    Two different candidate-service pairs can therefore have the same displayed
    five-variable vector (notably a bounded-out vector of zero supported
    coverage and undefined out-of-domain properties). Supplementary Fig. 3 is a
    profile-diversity panel, so every exact displayed vector must occur once.
    This function collapses only exact ``profile_signature`` duplicates and
    retains every contributing candidate-service pair in ``display_label``.
    No scientific value, eligibility decision or Monte Carlo result is changed.
    """
    required = {
        "profile_signature", "system_id", "display_system",
        "member_scenarios", "member_labels", "member_count",
        *THERMOPHYSICAL_DISPLAY_COLUMNS,
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"unique_thermophysical_profiles missing columns: {missing}")

    rows: list[dict] = []
    for signature, group in frame.groupby("profile_signature", sort=False, dropna=False):
        first = group.iloc[0]
        labels = []
        for record in group.itertuples(index=False):
            label = f"{short_candidate(record.display_system)} · {chem_label(str(record.member_labels))}"
            if label not in labels:
                labels.append(label)
        row = {
            "profile_signature": signature,
            "system_id": ";".join(dict.fromkeys(group.system_id.astype(str))),
            "display_system": " / ".join(dict.fromkeys(group.display_system.astype(str))),
            "member_scenarios": ";".join(dict.fromkeys(
                item
                for value in group.member_scenarios.astype(str)
                for item in value.split(";")
                if item
            )),
            "member_labels": " / ".join(dict.fromkeys(group.member_labels.astype(str))),
            "member_count": int(pd.to_numeric(group.member_count, errors="coerce").fillna(0).sum()),
            "display_label": " / ".join(labels),
            "source_profile_rows": int(len(group)),
            "cross_candidate_duplicate_collapsed": bool(group.system_id.astype(str).nunique() > 1),
        }
        row.update({column: first[column] for column in THERMOPHYSICAL_DISPLAY_COLUMNS})
        rows.append(row)

    out = pd.DataFrame(rows)
    if out.profile_signature.duplicated().any():
        raise RuntimeError("Supplementary Fig. 3 display-profile collapse is not one-row-per-signature")
    return out


def load(name: str, **kwargs) -> pd.DataFrame:
    return pd.read_csv(TABLES / f"{VERSION}_{name}.csv", **kwargs)


D = load("candidate_system_metrics_deterministic")
MC = load("system_value_monte_carlo_summary")
PEN = load("partial_vs_complete_service_penalty")
DBINV = load("raw_database_record_inventory")
DBFAM = load("database_family_summary")
DBCOV = load("family_property_coverage")
DBFUN = load("database_to_shortlist_transition")
LINK = load("candidate_database_linkage_audit")
CURATED = load("curated_candidate_registry_summary")
RED = load("decision_redirection_system_consequences")
FLOW = load("figure_selection_alluvial_flows")
GINT = load("figure_gate_intersection_summary")
GOVER = load("gate_overlap_summary")
SHAP = load("gate_shapley_attribution")
JOINT = load("joint_gate_closure")
WREG = load("weight_space_decision_regions")
WSCAN = load("continuous_weight_space_scan")
WREP = load("weight_space_region_replicates")
CRED = load("credibility_model_sensitivity")
PERT = load("evidence_score_perturbation_sensitivity")
LOC = load("leave_one_candidate_out_sensitivity")
LOS = load("leave_one_source_out_sensitivity")
CONV = load("independent_seed_convergence")
CCHANGE = load("counterfactual_selection_changes")
CSIGNED = load("counterfactual_candidate_signed_changes")
AFOR = load("figure_action_effect_forest_summary")
PORT = load("research_action_nondominance_assessment")
THRESH = load("service_coverage_threshold_sensitivity")
PAIR = load("pairwise_superiority_matrix")
RANKP = load("rank_probability_matrix")
PF = load("system_value_pareto_fronts")
LITFLOW = load("literature_evidence_flow")
READY = load("candidate_readiness_profile")
FEAS = load("service_feasibility_composition")
SYNERGY = load("gate_pair_synergy")
SYNSUM = load("gate_pair_synergy_summary")
CONSENSUS = load("robustness_consensus_summary")
DENSITY = load("action_response_density")
STORY = load("scenario_storyline_summary")
CONTRACT = load("deployability_contraction")
RREV = load("partial_complete_rank_reversal_summary")
RREVC = load("partial_complete_rank_reversal_candidates")
FRONT = load("service_conditioned_deployability_frontier")
ARCHSUM = load("candidate_archetype_cluster_summary")
ARCHMETHOD = load("candidate_archetype_method")
SMAA = load("smaa_rank_acceptability")
SMAAC = load("smaa_central_weights")
SMAAD = load("smaa_design")
EVI = load("prospective_evidence_value_by_service")
EVISUM = load("prospective_evidence_value_summary")
LADDER = load("rank_ladder_by_draw")
LADSUM = load("rank_ladder_transition_summary")
COVERMAP = load("candidate_service_coverage_map")
CSHORT = load("credibility_shortfall_decomposition")
CSHORTSUM = load("credibility_shortfall_summary")
XCONS = load("cross_scenario_candidate_consensus")
STRESS = load("stress_case_outcomes")
FRAG = load("decision_fragility_scorecard")
SCSCORE = load("service_consequence_scorecard")
ASCORE = load("action_service_scorecard")
ROUTE = load("redirection_route_summary")
RCRED = load("redirection_credibility_change")
GINTH = load("gate_intersection_horizontal_summary")
GDEPTH = load("gate_closure_depth_response")
GMULT = load("gate_failure_multiplicity_summary")
ANONZERO = load("atomic_action_service_nonzero_scorecard")
AICURRENT = load("ai_model_validation")
AIAPP = load("ai_candidate_applicability_audit")
AIFIRE = load("ai_decision_firewall_audit")
JTHRESH = load("joint_threshold_regime_summary")
BCOUNT = load("bounded_candidate_count_summary")
DSHORT = load("displaced_leader_shortfall_composition")
RTRADE = load("redirection_tradeoff_routes")
GTRANSFER = load("gate_bottleneck_transfer")
UTRANS = load("selection_uncertainty_transition")
NONADD = load("evidence_programme_nonadditivity")
URVALUE = load("uncertainty_reduction_value")
TFRONT = load("thermal_transport_frontier")
RPATH = load("ranking_pathway_summary")
DTRAJ = load("deployability_trajectory_groups")
FGRP = load("service_feasibility_groups")
RDIV = load("redirection_route_diversity")
WSTAB = load("weight_space_stability_summary")
SMAAG = load("smaa_rank1_groups")
OMSUM = load("omission_influence_summary")
UPROF_RAW = load("unique_thermophysical_profiles")
UPROF = collapse_thermophysical_display_profiles(UPROF_RAW)
UPROF.to_csv(QA / f"{VERSION}_SUPP3_DISPLAYED_THERMOPHYSICAL_PROFILES.csv", index=False)
PENGRP = load("unique_partial_service_penalty_profiles")
AINT = load("unique_atomic_interval_profiles")
AINTDIM = load("atomic_interval_profiles_by_dimension")
SOMRANK = load("supplementary_candidate_omission_rank_residuals")
SOMRES = load("supplementary_candidate_omission_residuals")
SOMDEC = load("supplementary_candidate_omission_decisiveness_residuals")
SOGRP = load("source_omission_effect_groups")
MSGRP = load("nonzero_model_sensitivity_groups")
USPROF = load("unique_credibility_shortfall_profiles")
RPROF = load("unique_readiness_profiles")
MGRP = load("bounded_multiplicity_groups")
CVSUM = load("independent_convergence_summary")
UFS = load("unique_formula_system_inventory")
DBAPP = load("database_application_lower_bound_compatibility")
TOPMARGIN = load("top_two_margin_summary")
CREDMODEL = load("credibility_model_sensitivity")
SERV = pd.read_csv(CFG / f"{VERSION}_system_benchmarks.csv")
ATOMIC = pd.read_csv(IN / f"{VERSION}_atomic_engineering_credibility_registry.csv")
CSCOPE = load("candidate_scope_and_inclusion_audit")
MEMBERSHIP = pd.read_csv(IN / f"{VERSION}_candidate_scenario_membership.csv")


# The submission renderer uses the strict Arial policy established at import.
# Do not re-resolve to a fallback family later in the module, because that can
# silently change prose or math typography across operating systems.
FONT = _TEXT_FONT
plt.rcParams.update({
    "font.family": FONT,
    "font.sans-serif": [FONT],
    "mathtext.fontset": "custom",
    "mathtext.rm": FONT,
    "mathtext.it": FONT + ":italic",
    "mathtext.bf": FONT + ":bold",
    "mathtext.fallback": "stix",
    "mathtext.default": "regular",
    "axes.unicode_minus": False,
    "font.size": 8.0,
    "axes.labelsize": 7.2,
    "xtick.labelsize": 6.6,
    "ytick.labelsize": 6.6,
    "legend.fontsize": 6.6,
    "axes.linewidth": 0.65,
    "xtick.major.width": 0.55,
    "ytick.major.width": 0.55,
    "xtick.direction": "out",
    "ytick.direction": "out",
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.dpi": 300,
})

FIGURE_RECORDS: list[dict] = []
MAIN_W = 180.0 / 25.4  # exact Nature Energy double-column width (180 mm)
MAIN_H = 7.55
SUPP_W = MAIN_W  # supplementary figures also use an exact 180 mm native page


def panel(ax, letter: str, x: float = -0.078, y: float = 1.055) -> None:
    # Submission geometry: panel letters sit clearly outside the upper-left frame.
    ax.text(x, y, letter, transform=ax.transAxes, ha="left", va="top",
            fontsize=9.1, fontweight="bold", clip_on=False)

def value_badge(ax, x, y, text, dx=6, dy=0, ha="left", color=INK, clip_on=True):
    ax.annotate(str(text), (x, y), xytext=(dx, dy), textcoords="offset points",
                ha=ha, va="center", fontsize=5.9, color=color, clip_on=clip_on, zorder=6,
                bbox=dict(boxstyle="round,pad=.15", fc="white", ec=color, lw=.45, alpha=.96))


def barh_headroom(ax, n_rows: int, extra_top: float = 0.90) -> None:
    # Add controlled vertical headroom so in-axis legends never cover the upper bar.
    ax.set_ylim(-0.5, max(0.5, n_rows - 0.5 + extra_top))


def categorical_marker_padding(ax, n_rows: int, pad: float = 0.68) -> None:
    # Symmetric categorical-axis padding prevents large markers and error-bar caps from clipping.
    ax.set_ylim(-pad, max(pad, n_rows - 1 + pad))


def clean(ax, grid: str | None = None) -> None:
    # Framed axes: upper and right spines remain visible.
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color(INK)
        spine.set_linewidth(0.62)
    if grid:
        ax.grid(axis=grid, color=LIGHT_GREY, linewidth=0.48, zorder=0)
    ax.set_axisbelow(True)


def top_legend(ax, handles=None, labels=None, ncol=3, anchor=(0.5, 1.12), loc="upper center", **kwargs):
    return ax.legend(handles=handles, labels=labels, ncol=ncol, loc=loc, bbox_to_anchor=anchor,
                     frameon=False, handlelength=1.4, columnspacing=0.9, borderaxespad=0, **kwargs)


def value_badge(ax,x,y,text,color=INK,dx=6,dy=0,ha="left",va="center",fontsize=6.0):
    return ax.annotate(text,(x,y),xytext=(dx,dy),textcoords="offset points",ha=ha,va=va,
                       fontsize=fontsize,fontweight="bold",color=color,clip_on=True,zorder=8,
                       bbox=dict(boxstyle="round,pad=.14",fc="white",ec=color,lw=.48,alpha=.96))


def label_wrap(values, width=20):
    return ["\n".join(textwrap.wrap(str(v), width=width)) for v in values]


def save_figure(fig, number: str, title: str, source_tables: list[str], extended: bool = False) -> None:
    out = SUPP if extended else MAIN
    stem = f"{VERSION}_{'Supp_Fig' if extended else 'Fig'}{number}"
    png = out / f"{stem}.png"
    pdf = out / f"{stem}.pdf"
    # Every publication figure is exported on an exact 180 mm native page; no post-hoc width expansion.
    bbox = None
    pad = 0.0
    fig.savefig(png, dpi=300, bbox_inches=bbox, pad_inches=pad, facecolor="white")
    fig.savefig(pdf, bbox_inches=bbox, pad_inches=pad, facecolor="white", metadata={"Creator": "core deterministic postprocess", "CreationDate": None, "ModDate": None})
    with Image.open(png) as _im:
        width, height = _im.size
    FIGURE_RECORDS.append({
        "figure": f"Supplementary Fig. {number}" if extended else f"Fig. {number}",
        "title": title,
        "png": str(png.relative_to(ROOT)),
        "pdf": str(pdf.relative_to(ROOT)),
        "width_px": width,
        "height_px": height,
        "aspect_ratio": width / height,
        "source_tables": ";".join(source_tables),
    })
    plt.close(fig)


def top_colorbar(fig, ax, image, label):
    cbar = fig.colorbar(image, ax=ax, orientation="horizontal", location="top", fraction=0.052, pad=0.025, aspect=28)
    cbar.set_label(label, fontsize=6.5, labelpad=1.0)
    cbar.ax.tick_params(labelsize=6.5, length=1.8, pad=0.8)
    cbar.outline.set_linewidth(0.45)
    return cbar


def attached_top_colorbar(fig, ax, image, label, y=1.018, height=0.032):
    """Attach a compact horizontal colour scale directly above one panel.

    The inset strip is panel-local rather than figure-global, so it remains close to
    the upper x-axis and cannot drift into the page header under constrained layout.
    """
    cax = ax.inset_axes([0.0, y, 1.0, height], transform=ax.transAxes)
    cbar = fig.colorbar(image, cax=cax, orientation="horizontal")
    cbar.ax.xaxis.set_ticks_position("top")
    cbar.ax.xaxis.set_label_position("top")
    cbar.set_label(label, fontsize=6.5, labelpad=0.8)
    cbar.ax.tick_params(labelsize=6.5, length=1.6, pad=0.6)
    cbar.outline.set_linewidth(0.45)
    cax.set_clip_on(False)
    return cbar


def bottom_colorbar(fig, ax, image, label, pad=0.16):
    # Bottom placement is used where a top legend or panel title already occupies the headroom.
    # Constrained layout reserves a separate strip, preventing collision with the axis frame.
    cbar = fig.colorbar(image, ax=ax, orientation="horizontal", location="bottom", fraction=0.052, pad=pad, aspect=28)
    cbar.set_label(label, fontsize=6.5, labelpad=1.0)
    cbar.ax.tick_params(labelsize=6.5, length=1.8, pad=0.8)
    cbar.outline.set_linewidth(0.45)
    return cbar


def heatmap(ax, matrix, row_labels, col_labels, cmap=LinearSegmentedColormap.from_list("muted_seq2",[VERY_LIGHT,CREAM,OLIVE]), vmin=None, vmax=None, fmt=None, annotate=False, cbar_label=None, center=None, fig=None, cbar_location="top", cbar_pad=None):
    arr = np.asarray(matrix, dtype=float)
    norm = None
    if center is not None:
        lim = max(abs(np.nanmin(arr)), abs(np.nanmax(arr)), 1e-9)
        norm = TwoSlopeNorm(vmin=-lim, vcenter=center, vmax=lim)
    image = ax.imshow(arr, aspect="auto", interpolation="nearest", cmap=cmap, vmin=None if norm else vmin, vmax=None if norm else vmax, norm=norm)
    ax.set_xticks(np.arange(len(col_labels)), col_labels, rotation=35, ha="right")
    ax.set_yticks(np.arange(len(row_labels)), row_labels)
    for x in np.arange(len(col_labels) + 1) - 0.5:
        ax.axvline(x, color="white", lw=0.45)
    for y in np.arange(len(row_labels) + 1) - 0.5:
        ax.axhline(y, color="white", lw=0.45)
    if annotate:
        formatter = fmt or "{:.2f}"
        for i in range(arr.shape[0]):
            for j in range(arr.shape[1]):
                if np.isfinite(arr[i, j]):
                    rgba = image.cmap(image.norm(arr[i, j]))
                    luminance = 0.2126*rgba[0]+0.7152*rgba[1]+0.0722*rgba[2]
                    ax.text(j, i, formatter.format(arr[i, j]), ha="center", va="center", fontsize=6.5,
                            color="white" if luminance < 0.48 else INK)
    clean(ax, None)
    if cbar_label and fig is not None:
        if cbar_location == "bottom":
            bottom_colorbar(fig, ax, image, cbar_label, pad=0.16 if cbar_pad is None else cbar_pad)
        else:
            top_colorbar(fig, ax, image, cbar_label)
    return image


def weighted_alluvial(ax, frame: pd.DataFrame, stages: list[str], weight_col: str, color_col: str,
                      color_map: dict[str, str], node_color_map: dict[str, str] | None = None,
                      stage_labels: list[str] | None = None, min_fraction=0.0, node_width=0.05,
                      gap=0.010, outer_labels=True, label_min_fraction=0.015,
                      label_min_fraction_left=None, label_min_fraction_right=None,
                      node_top=0.982, node_bottom=0.037, stage_label_y=0.992):
    df = frame.copy()
    df[weight_col] = pd.to_numeric(df[weight_col], errors="coerce").fillna(0)
    total = float(df[weight_col].sum())
    if total <= 0:
        ax.axis("off")
        return
    if min_fraction > 0:
        df = df[df[weight_col] / total >= min_fraction].copy()
        total = float(df[weight_col].sum())
    xs = np.linspace(0.08, 0.92, len(stages))
    bounds, totals = {}, {}
    outer_label_records = []
    for si, stage in enumerate(stages):
        counts = df.groupby(stage)[weight_col].sum().sort_values(ascending=False)
        totals[stage] = counts
        # Explicit top/bottom bounds keep stage headings clear while preserving a tall flow field.
        usable = (node_top - node_bottom) - gap * max(0, len(counts) - 1)
        top = node_top
        for value, wt in counts.items():
            value = str(value)
            height = usable * float(wt) / total
            bounds[(stage, value)] = (xs[si]-node_width/2, top-height, xs[si]+node_width/2, top)
            fill = (node_color_map or {}).get(value, VERY_LIGHT)
            ax.add_patch(Rectangle((xs[si]-node_width/2, top-height), node_width, height,
                                   facecolor=fill, edgecolor="white", linewidth=0.5, zorder=3))
            label_threshold = label_min_fraction
            if si == 0 and label_min_fraction_left is not None:
                label_threshold = label_min_fraction_left
            elif si == len(stages)-1 and label_min_fraction_right is not None:
                label_threshold = label_min_fraction_right
            if height >= label_threshold:
                if outer_labels and si in {0, len(stages)-1}:
                    side = "left" if si == 0 else "right"
                    outer_label_records.append({
                        "side": side, "node_x": xs[si]-node_width/2 if side == "left" else xs[si]+node_width/2,
                        "text_x": xs[si]-node_width/2-0.008 if side == "left" else xs[si]+node_width/2+0.008,
                        "desired_y": top-height/2, "value": value
                    })
                else:
                    ax.text(xs[si], top-height/2, value, ha="center", va="center", fontsize=6.5,
                            color="white" if fill not in {VERY_LIGHT, "#FFFFFF"} else INK)
            top -= height + gap
    # Resolve outer-label collisions deterministically while retaining node-to-label traceability.
    for side in ("left", "right"):
        records = sorted((r for r in outer_label_records if r["side"] == side), key=lambda r: r["desired_y"])
        if not records:
            continue
        min_sep, lower, upper = 0.038, max(0.004, node_bottom - 0.010), min(0.992, node_top + 0.010)
        placed = []
        for i, record in enumerate(records):
            y = max(record["desired_y"], lower if i == 0 else placed[-1] + min_sep)
            placed.append(y)
        overflow = placed[-1] - upper
        if overflow > 0:
            placed = [y - overflow for y in placed]
            for i in range(len(placed)-2, -1, -1):
                placed[i] = min(placed[i], placed[i+1] - min_sep)
            if placed[0] < lower:
                shift = lower - placed[0]
                placed = [y + shift for y in placed]
        for record, y in zip(records, placed):
            ha = "right" if side == "left" else "left"
            ax.text(record["text_x"], y, record["value"], ha=ha, va="center", fontsize=6.5)
            if abs(y-record["desired_y"]) > 0.004:
                ax.plot([record["node_x"], record["text_x"]], [record["desired_y"], y],
                        color=MID_GREY, lw=0.45, zorder=4, solid_capstyle="round")

    for si in range(len(stages)-1):
        left, right = stages[si], stages[si+1]
        group_cols = list(dict.fromkeys([left, right, color_col]))
        agg = df.groupby(group_cols, as_index=False)[weight_col].sum().sort_values(weight_col, ascending=False)
        out_offset = {(left, str(v)): 0.0 for v in totals[left].index}
        in_offset = {(right, str(v)): 0.0 for v in totals[right].index}
        for row in agg.itertuples(index=False):
            lv, rv = str(getattr(row, left)), str(getattr(row, right))
            key, wt = str(getattr(row, color_col)), float(getattr(row, weight_col))
            lb, rb = bounds[(left, lv)], bounds[(right, rv)]
            lh = (lb[3]-lb[1]) * wt / float(totals[left].loc[getattr(row, left)])
            rh = (rb[3]-rb[1]) * wt / float(totals[right].loc[getattr(row, right)])
            y0a = lb[1] + out_offset[(left, lv)]; y0b = y0a + lh
            y1a = rb[1] + in_offset[(right, rv)]; y1b = y1a + rh
            out_offset[(left, lv)] += lh; in_offset[(right, rv)] += rh
            x0, x1 = lb[2], rb[0]; dx = (x1-x0)*0.44
            verts = [(x0,y0a),(x0+dx,y0a),(x1-dx,y1a),(x1,y1a),(x1,y1b),(x1-dx,y1b),(x0+dx,y0b),(x0,y0b),(x0,y0a)]
            codes = [MplPath.MOVETO,MplPath.CURVE4,MplPath.CURVE4,MplPath.CURVE4,MplPath.LINETO,MplPath.CURVE4,MplPath.CURVE4,MplPath.CURVE4,MplPath.CLOSEPOLY]
            ax.add_patch(PathPatch(MplPath(verts,codes), facecolor=color_map.get(key, NEUTRAL), edgecolor="none", alpha=0.42, zorder=1))
    if stage_labels:
        for x, label in zip(xs, stage_labels):
            ax.text(x, stage_label_y, label, ha="center", va="top", fontsize=6.5, fontweight="bold")
    ax.set_xlim(-0.03, 1.03); ax.set_ylim(0, 1.0); ax.set_anchor("C"); ax.axis("off")


def candidate_color(label: str) -> str:
    return CANDIDATE_COLORS.get(short_candidate(label), MID_GREY)


# --------------------------- Main Figure 1 ---------------------------

def make_fig1():
    fig=plt.figure(figsize=(MAIN_W, 7.42), constrained_layout=True)
    # A–D share one aligned two-column grid so the upper panels use the full 180 mm width.
    gs=fig.add_gridspec(3,2,height_ratios=[1.10,1.02,1.0],width_ratios=[1.0,1.0],hspace=0.052,wspace=0.016)
    axa=fig.add_subplot(gs[0,0]); axb=fig.add_subplot(gs[0,1])
    axc=fig.add_subplot(gs[1,0]); axd=fig.add_subplot(gs[1,1]); axe=fig.add_subplot(gs[2,:])

    panel(axa,'a')
    raw=int(DBFUN.loc[DBFUN.screen_order==1,'retained_count'].max())
    melt=int(DBFUN.loc[DBFUN.screen_step.str.contains('Melting temperature available'),'retained_count'].max())
    service=int(DBFUN.loc[DBFUN.screen_step.str.contains('melting/phase lower-bound compatibility'),'retained_count'].max())
    coverage=int(DBFUN.loc[DBFUN.screen_step.str.contains('Minimum thermophysical coverage'),'retained_count'].max())
    stages=['Raw records','Melting data','Service-compatible','Minimum coverage']
    values=np.array([raw,melt,service,coverage],dtype=float)
    colors=[NAVY,BLUE,MUSTARD,OLIVE]
    y=np.arange(len(stages))[::-1]
    axa.barh(y,values,color=colors,height=.58)
    xmax=raw*1.235
    for yi,val,prev in zip(y,values,[raw,raw,melt,service]):
        label=f'{int(val):,}' if prev==val else f'{int(val):,}  (−{int(prev-val):,})'
        xlab=min(val+raw*.015, xmax-raw*.015)
        axa.text(xlab,yi,label,va='center',ha='left',fontweight='bold',fontsize=6.5)
    axa.set_yticks(y,stages); axa.set_xlim(0,xmax); axa.set_xlabel('Retained records'); clean(axa,'x')

    panel(axb,'b')
    lf=LITFLOW.groupby(['evidence_stream','candidate_family'],as_index=False).unique_source_candidate_link.sum()
    stream_short={'Official databases':'Databases','System benchmarks':'Benchmarks','Thermophysical literature':'Thermophysical lit.','Corrosion literature':'Corrosion lit.','Contextual literature':'Context lit.','Other literature':'Other lit.'}
    family_short={'Nitrate/nitrite':'Nitrate','Chloride':'Chloride','Carbonate/fluoride':'Carbonate/F'}
    lf['evidence_stream']=lf.evidence_stream.map(stream_short).fillna(lf.evidence_stream)
    lf['candidate_family']=lf.candidate_family.map(family_short).fillna(lf.candidate_family)
    stream={'Databases':NAVY,'Benchmarks':BLUE,'Thermophysical lit.':MUSTARD,'Corrosion lit.':BURGUNDY,'Context lit.':CREAM,'Other lit.':NEUTRAL}
    fam={'Nitrate':MUSTARD,'Chloride':TERRACOTTA,'Carbonate/F':ROSE}
    weighted_alluvial(axb,lf,['evidence_stream','candidate_family'],'unique_source_candidate_link','evidence_stream',stream,node_color_map={**stream,**fam},stage_labels=['Evidence stream','Chemistry family'],outer_labels=True,label_min_fraction=.020,node_width=.074,gap=.009,node_top=.905,node_bottom=.012,stage_label_y=.985)

    panel(axc,'c')
    prof=READY.groupby('display_system',as_index=False)[['corrosion_compatibility_score','cycling_phase_stability_score','containment_validation_score','literature_replication_score','data_completeness_score']].mean()
    scope=CSCOPE[['display_system','family','registered_application_count','exact_formula_system_match']].drop_duplicates('display_system')
    mat=scope.merge(prof,on='display_system',how='left')
    mat['short']=mat.display_system.map(short_candidate)
    fam_order=['nitrate','nitrate_nitrite','nitrate_nitrite_carbonate','nitrate_carbonate_chloride','nitrate_nitrite_lithium_calcium','chloride','carbonate','carbonate_fluoride']
    fam_rank={k:i for i,k in enumerate(fam_order)}
    mat['family_rank']=mat['family'].map(lambda x:fam_rank.get(str(x),999))
    mat=mat.sort_values(['family_rank','registered_application_count','short'],ascending=[True,False,True]).reset_index(drop=True)
    mat['apps_norm']=mat['registered_application_count']/max(1,float(mat['registered_application_count'].max()))
    mat['msd_link']=mat['exact_formula_system_match'].astype(float)
    cols=['corrosion_compatibility_score','cycling_phase_stability_score','containment_validation_score','literature_replication_score','data_completeness_score','apps_norm','msd_link']
    clabels=['Corrosion','Cycling/phase','Containment','Literature','Data','Apps','MSD link']
    image=heatmap(axc,mat[cols],mat['short'],clabels,cmap=LinearSegmentedColormap.from_list('evidence_readiness',[VERY_LIGHT,CREAM,OLIVE]),vmin=0,vmax=1,annotate=False)
    # family strip and group labels
    fam_group=[]
    for fam in mat['family']:
        s=str(fam)
        if 'nitrate' in s or 'nitrite' in s:
            fam_group.append('Nitrate-containing')
        elif 'chloride' in s:
            fam_group.append('Chloride')
        else:
            fam_group.append('Carbonate-containing')
    fam_color={'Nitrate-containing':MUSTARD,'Chloride':TERRACOTTA,'Carbonate-containing':ROSE}
    axc.set_xlim(-0.92,len(cols)-0.5)
    for i,g in enumerate(fam_group):
        axc.add_patch(Rectangle((-0.88,i-0.5),0.18,1.0,facecolor=fam_color[g],edgecolor='white',lw=.45,clip_on=False,zorder=3))
    # informative annotations only for scope columns
    for i,r in enumerate(mat.itertuples(index=False)):
        axc.text(5,i,f'{int(r.registered_application_count)}',ha='center',va='center',fontsize=6.5,color=INK)
        axc.text(6,i,'Y' if bool(r.exact_formula_system_match) else '—',ha='center',va='center',fontsize=6.5,color=INK)
    # family block separators
    prev=fam_group[0]
    for i,g in enumerate(fam_group[1:],start=1):
        if g!=prev:
            axc.axhline(i-0.5,color=INK,lw=.85)
            prev=g
    axc.tick_params(axis='y',labelsize=6.5)
    axc.tick_params(axis='x',labelsize=6.5)
    short_fam={'Nitrate-containing':'Nitrate','Chloride':'Chloride','Carbonate-containing':'Carbonate/F'}
    handles=[Patch(facecolor=fam_color[k],label=short_fam[k]) for k in ['Nitrate-containing','Chloride','Carbonate-containing']]
    axc.legend(handles=handles,loc='upper center',bbox_to_anchor=(.57,1.082),frameon=False,fontsize=6.5,ncol=3,columnspacing=.50,handlelength=.88,handletextpad=.28,borderaxespad=0,labelspacing=.16)
    # Replace the obsolete violin/boxplot legend with a scale that matches the new matrix.
    cax=axc.inset_axes([0.24,1.126,0.76,0.028],transform=axc.transAxes)
    cbar=fig.colorbar(image,cax=cax,orientation='horizontal')
    cbar.ax.xaxis.set_ticks_position('top')
    cbar.ax.tick_params(labelsize=6.5,length=1.4,pad=.25)
    cbar.outline.set_linewidth(.45); cax.set_clip_on(False)
    axc.text(.225,1.141,'Score',transform=axc.transAxes,ha='right',va='center',fontsize=6.5,color=INK,clip_on=False)

    panel(axd,'d')
    grouped_scheme='nested_group_split_conformal_test'
    random_scheme='random_record_cv_optimism_diagnostic'
    aim=AICURRENT[AICURRENT.validation_scheme.isin([grouped_scheme,random_scheme])].copy()
    metric_x=np.arange(3,dtype=float); metric_labels=['Formula-group\n$R^2$','Random-split CV\n$R^2$','Conformal\ncoverage']
    plotted=[]
    for target,label,color,marker in [('melting_temperature_K','Melting',NAVY,'o'),('density_kg_m3','Density',TERRACOTTA,'D')]:
        sub=aim[aim.target.eq(target)].set_index('validation_scheme')
        vals=np.array([float(sub.loc[grouped_scheme,'r2']),float(sub.loc[random_scheme,'r2']),float(sub.loc[grouped_scheme,'interval_empirical_coverage'])])
        plotted.append((label,color,marker,vals))
    for j in range(3):
        ys=[row[3][j] for row in plotted]; axd.vlines(metric_x[j],min(ys),max(ys),color=LIGHT_GREY,lw=2.2,zorder=1)
    metric_offsets={
        ('Melting',0):(8,8,'left','bottom'), ('Density',0):(15,-17,'left','top'),
        ('Melting',1):(-12,10,'right','bottom'), ('Density',1):(13,-15,'left','top'),
        ('Melting',2):(-20,11,'right','bottom'), ('Density',2):(9,-14,'left','top'),
    }
    for label,color,marker,vals in plotted:
        axd.scatter(metric_x,vals,s=50,color=color,marker=marker,edgecolor='white',lw=.6,zorder=3,label=label)
        for j,(x0,y0) in enumerate(zip(metric_x,vals)):
            dx,dy,ha,va=metric_offsets[(label,j)]
            axd.annotate(f'{y0:.2f}',(x0,y0),xytext=(dx,dy),textcoords='offset points',
                         ha=ha,va=va,fontsize=6.5,color=INK,clip_on=True,
                         arrowprops=dict(arrowstyle='-',color=MID_GREY,lw=.38,shrinkA=2,shrinkB=4))
    nominal=float(aim.loc[aim.validation_scheme.eq(grouped_scheme),'interval_nominal_coverage'].dropna().median())
    axd.axhline(nominal,color=MID_GREY,lw=.8,ls='--',zorder=0)
    axd.set_xticks(metric_x,metric_labels); axd.set_xlim(-.35,2.45); axd.set_ylim(0,1.05); axd.set_ylabel('Validation metric'); clean(axd,'y')
    handles=[Line2D([0],[0],marker='o',ls='',color=NAVY,label='Melting',markersize=5),Line2D([0],[0],marker='D',ls='',color=TERRACOTTA,label='Density',markersize=5),Line2D([0],[0],ls='--',color=MID_GREY,label='Nominal coverage',lw=.8)]
    axd.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,1.13),frameon=False,ncol=3,fontsize=6.5,handletextpad=.35,columnspacing=.7,borderaxespad=0)

    panel(axe,'e')
    stage_fields=['registered_share','complete_service_share','evidence_qualified_share','any_selected_share','material_selected_share']
    stage_labels=['Registered','Strict complete','Evidence qualified','Selected in any draw','Selected in ≥1% of draws']
    stage_colors=[NAVY,BLUE,MUSTARD,ROSE,BURGUNDY]; stage_markers=['o','s','D','^','v']
    traj=DTRAJ.sort_values('group_order').reset_index(drop=True); y=np.arange(len(traj))
    for i,r in enumerate(traj.itertuples(index=False)):
        vals=[float(getattr(r,f)) for f in stage_fields]
        axe.plot(vals,np.full(len(vals),i),color=LIGHT_GREY,lw=1.6,zorder=1)
        for v,c,mk in zip(vals,stage_colors,stage_markers):
            axe.scatter(v,i,s=50,marker=mk,color=c,edgecolor='white',lw=.6,zorder=2)
    labels=[chem_label(str(x)) for x in traj.member_labels]
    axe.set_yticks(y,labels); axe.set_xlim(-.02,1.02); axe.set_xlabel('Share of registered candidate–service pairs'); clean(axe,'x')
    handles=[Line2D([0],[0],marker=mk,ls='',color=c,label=lab,markersize=6) for mk,c,lab in zip(stage_markers,stage_colors,stage_labels)]
    top_legend(axe,handles=handles,ncol=5,anchor=(.5,1.16),fontsize=6.5)
    save_figure(fig,'1','From database opportunity to evidence-qualified deployability',['database_to_shortlist_transition','literature_evidence_flow','unique_formula_system_inventory','ai_model_validation','ai_candidate_applicability_audit','ai_decision_firewall_audit','deployability_trajectory_groups'])

def make_fig2():
    fig=plt.figure(figsize=(MAIN_W, MAIN_H), constrained_layout=True)
    gs=fig.add_gridspec(3,2,height_ratios=[1.0,1.0,1.02],width_ratios=[1.08,1.06],hspace=0.072,wspace=0.022)
    axa=fig.add_subplot(gs[0,0]); axb=fig.add_subplot(gs[0,1]); axc=fig.add_subplot(gs[1,0]); axd=fig.add_subplot(gs[1,1]); axe=fig.add_subplot(gs[2,:])

    panel(axa,'a')
    ybase={s:i for i,s in enumerate(SCENARIOS[::-1])}
    for sname in SCENARIOS:
        row=SERV[SERV.scenario==sname].iloc[0]; y=ybase[sname]
        lo=float(row.fixed_Tcold_C if row.service_mode=='sensible' else row.phase_target_min_C); hi=float(row.fixed_Thot_C if row.service_mode=='sensible' else row.phase_target_max_C)
        axa.plot([lo,hi],[y,y],lw=7.6,color=SCENARIO_COLOR[sname],solid_capstyle='butt',alpha=.82)
        sub=COVERMAP[COVERMAP.scenario==sname].sort_values('candidate_Tm_C')
        jitter=np.linspace(-.18,.18,len(sub)) if len(sub)>1 else [0]
        for j,r in zip(jitter,sub.itertuples(index=False)):
            face=SCENARIO_COLOR[sname] if r.strict_complete_service_feasible else 'white'
            axa.scatter(r.candidate_Tm_C,y+j,s=28,facecolor=face,edgecolor=SCENARIO_COLOR[sname],lw=.8,zorder=3)
    axa.set_yticks(range(len(SCENARIOS)),[scenario_code(x) for x in SCENARIOS[::-1]]); axa.set_xlim(145,735); barh_headroom(axa,len(SCENARIOS),1.90); axa.set_xlabel('Service window and candidate melting temperature (°C)'); clean(axa,'x')
    h2=[Line2D([0],[0],marker='o',ls='',markerfacecolor=NAVY,markeredgecolor=NAVY,label='Strict-complete service feasible',markersize=4.5),Line2D([0],[0],marker='o',ls='',markerfacecolor='white',markeredgecolor=NAVY,label='Not strict-complete feasible',markersize=4.5),Line2D([0],[0],color=NEUTRAL,lw=5,label='Service-temperature window')]
    axa.legend(handles=h2,loc='upper left',bbox_to_anchor=(.01,.985),frameon=False,fontsize=6.5,ncol=1,handlelength=1.4,columnspacing=.8,borderaxespad=0)

    panel(axb,'b')
    cats=['robust_complete_service','uncertain_complete_service','no_complete_service']
    col={'robust_complete_service':OLIVE,'uncertain_complete_service':MUSTARD,'no_complete_service':BURGUNDY}; lab={'robust_complete_service':'Robust complete service','uncertain_complete_service':'Uncertain complete service','no_complete_service':'No complete service'}
    piv=FGRP.sort_values('group_order').set_index('member_labels')[cats].fillna(0)
    y=np.arange(len(piv)); left=np.zeros(len(piv))
    for k in cats:
        v=piv[k].to_numpy(float); axb.barh(y,v,left=left,height=.66,color=col[k],label=lab[k])
        for i,val in enumerate(v):
            if val>.14: axb.text(left[i]+val/2,i,f'{val:.0%}',ha='center',va='center',fontsize=6.5,color='white' if k!='uncertain_complete_service' else INK)
        left+=v
    axb.set_yticks(y,[chem_label(str(x)) for x in piv.index]); axb.set_xlim(0,1.0); barh_headroom(axb,len(piv),1.18); axb.set_xlabel('Complete-service classification share'); clean(axb,'x')
    axb.legend(loc='upper left',bbox_to_anchor=(.01,.985),frameon=False,fontsize=6.5,ncol=2,columnspacing=.6,handlelength=1.1,borderaxespad=0)

    panel(axc,'c')
    e=READY.copy(); scorecols=['corrosion_compatibility_score','cycling_phase_stability_score','containment_validation_score','literature_replication_score','data_completeness_score']; e['engineering_credibility']=e[scorecols].clip(lower=1e-12).prod(axis=1).pow(1/5)
    e=e[(e.strict_complete_service_probability>0)|(e.evidence_qualified_selection_frequency>0)].copy()
    for r in e.itertuples(index=False):
        axc.scatter(r.strict_complete_service_probability,r.evidence_qualified_selection_frequency,s=38+95*r.engineering_credibility,color=SCENARIO_COLOR[r.scenario],edgecolor=INK if r.evidence_qualified_selection_frequency>=.01 else 'white',lw=.8,zorder=3)
    labs=e[e.evidence_qualified_selection_frequency>=.01].sort_values('evidence_qualified_selection_frequency').groupby('scenario',as_index=False).tail(1)
    label_offsets={'coal_flexibility_storage':(20,16,'left'),'csp_sensible_storage':(-18,40,'right'),'industrial_medium_heat':(24,18,'left'),'sco2_high_temperature_storage':(-26,-34,'right'),'pcm_target_350C':(12,14,'left'),'pcm_target_425C':(12,-18,'left'),'pcm_target_500C':(-58,14,'right')}
    for r in labs.itertuples(index=False):
        dx,dy,ha=label_offsets.get(r.scenario,(5,5,'left'))
        line_color=SCENARIO_COLOR[r.scenario]
        axc.annotate(f'{scenario_code(r.scenario)} · {short_candidate(r.display_system)}',(r.strict_complete_service_probability,r.evidence_qualified_selection_frequency),xytext=(dx,dy),textcoords='offset points',fontsize=6.5,ha=ha,color=line_color,clip_on=False,arrowprops=dict(arrowstyle='-',color=line_color,lw=.55,shrinkA=1,shrinkB=2))
    axc.set_xlim(-.10,1.65); axc.set_ylim(-.10,1.16); axc.set_xlabel('Strict-complete service probability'); axc.set_ylabel('Evidence-bounded selection frequency'); clean(axc,'both')
    cleg=[Line2D([0],[0],marker='o',ls='',markerfacecolor=NEUTRAL,markeredgecolor='white',label='Marker area: engineering credibility',markersize=5),Line2D([0],[0],marker='o',ls='',markerfacecolor='white',markeredgecolor=INK,label='Black edge: selected in ≥1% of draws',markersize=5)]
    axc.legend(handles=cleg,loc='upper left',bbox_to_anchor=(.02,.98),frameon=False,fontsize=6.5,ncol=1,handletextpad=.35,borderaxespad=0,labelspacing=.25)

    panel(axd,'d')
    tf=TFRONT.dropna(subset=['thermal_k_at_service_W_mK','energy_density_p50_kWh_m3_conditional_on_adequacy']).copy()
    for r in tf.itertuples(index=False):
        axd.scatter(r.thermal_k_at_service_W_mK,r.energy_density_p50_kWh_m3_conditional_on_adequacy,s=32+120*r.strict_complete_service_probability,color=SCENARIO_COLOR[r.scenario],edgecolor=INK if r.substantively_selected else 'white',lw=.9 if r.substantively_selected else .4,alpha=.92)
    labs=tf[tf.substantively_selected].sort_values('evidence_qualified_selection_frequency').groupby('scenario',as_index=False).tail(1)
    offsets={'coal_flexibility_storage':(18,-26,'left','top'),'csp_sensible_storage':(-16,-18,'right','top'),'industrial_medium_heat':(18,-4,'left','center'),'sco2_high_temperature_storage':(14,10,'left','bottom')}
    for r in labs.itertuples(index=False):
        dx,dy,ha,va=offsets.get(r.scenario,(12,8,'left','bottom'))
        axd.annotate(f'{scenario_code(r.scenario)} · {short_candidate(r.display_system)}',(r.thermal_k_at_service_W_mK,r.energy_density_p50_kWh_m3_conditional_on_adequacy),xytext=(dx,dy),textcoords='offset points',fontsize=6.5,ha=ha,va=va,color=INK,clip_on=True,arrowprops=dict(arrowstyle='-',color=MID_GREY,lw=.42,shrinkA=2,shrinkB=4))
    axd.set_xlim(tf.thermal_k_at_service_W_mK.min()-.065, tf.thermal_k_at_service_W_mK.max()+.115); axd.set_ylim(tf.energy_density_p50_kWh_m3_conditional_on_adequacy.min()-28, tf.energy_density_p50_kWh_m3_conditional_on_adequacy.max()+45)
    axd.set_xlabel('Thermal conductivity at service temperature\n(W m$^{-1}$ K$^{-1}$)'); axd.set_ylabel('Conditional median energy density\n(kWh m$^{-3}$)'); clean(axd,'both')
    dleg=[Line2D([0],[0],marker='o',ls='',markerfacecolor=NEUTRAL,markeredgecolor='white',label='Marker area: strict-complete probability',markersize=5),Line2D([0],[0],marker='o',ls='',markerfacecolor='white',markeredgecolor=INK,label='Black edge: selected in ≥1% of draws',markersize=5)]
    axd.legend(handles=dleg,loc='upper left',bbox_to_anchor=(.02,.98),frameon=False,fontsize=6.5,ncol=1,handletextpad=.35,borderaxespad=0,labelspacing=.25)

    panel(axe,'e')
    cats=['Stable leader','Service-only change','Evidence-only change','Service + evidence change','No formal selection']; colors=[OLIVE,BLUE,MUSTARD,TERRACOTTA,BURGUNDY]
    pathway_label={'Stable leader':'Stable leader','Service-only change':'Service-only change','Evidence-only change':'Evidence-only change','Service + evidence change':'Service and evidence change','No formal selection':'No evidence-bounded selection'}
    rp_all=RPATH.pivot(index='scenario',columns='pathway',values='frequency').reindex(index=SCENARIOS,columns=cats).fillna(0); material=(rp_all>=.05).sum(axis=1)>=2
    rp=rp_all.loc[material].copy(); y=np.arange(len(rp)); left=np.zeros(len(rp))
    for cat,color in zip(cats,colors):
        vals=rp[cat].to_numpy(); axe.barh(y,vals,left=left,height=.66,color=color,label=pathway_label[cat])
        for i,v in enumerate(vals):
            if v>=.10: axe.text(left[i]+v/2,i,f'{v:.0%}',ha='center',va='center',fontsize=6.5,color='white' if color in [BURGUNDY,TERRACOTTA,BLUE] else INK)
        left+=vals
    axe.set_yticks(y,[scenario_code(x) for x in rp.index]); axe.set_xlim(0,1.0); barh_headroom(axe,len(rp),.64); axe.set_xlabel('Draw-level ranking-pathway share'); clean(axe,'x')
    axe.legend(loc='upper center',bbox_to_anchor=(.50,.985),frameon=False,fontsize=6.5,ncol=5,handlelength=.95,handletextpad=.30,columnspacing=.48,labelspacing=.18,borderaxespad=0)
    save_figure(fig,'2','Complete-service translation connects usable energy, thermal transport and ranking pathways',['candidate_service_coverage_map','service_feasibility_groups','candidate_readiness_profile','thermal_transport_frontier','ranking_pathway_summary'])

def make_fig3():
    fig=plt.figure(figsize=(MAIN_W, MAIN_H), constrained_layout=True)
    gs=fig.add_gridspec(2,2,height_ratios=[1.10,1.0],width_ratios=[1.02,1.0],hspace=0.038,wspace=0.030)
    axa=fig.add_subplot(gs[0,0]); axb=fig.add_subplot(gs[0,1]); axc=fig.add_subplot(gs[1,0]); axd=fig.add_subplot(gs[1,1])

    panel(axa,'a')
    f=FLOW.copy(); f['From']=f.from_display_system.map(short_candidate); f['To']=f.to_display_system.map(short_candidate); f['Outcome']=f.transition_class
    out={'retained':OLIVE,'redirected':MUSTARD,'no_selection':BURGUNDY}; node={**CANDIDATE_COLORS,'No selection':NEUTRAL}
    weighted_alluvial(axa,f,['From','To'],'transition_draws','Outcome',out,node_color_map=node,stage_labels=['Strict-complete thermophysical','Strict-complete evidence-bounded'],outer_labels=True,label_min_fraction=.018,label_min_fraction_left=.030,label_min_fraction_right=.020,node_width=.06,gap=.008,node_top=.895,node_bottom=.010,stage_label_y=.982)
    axa.legend(handles=[Line2D([0],[0],color=out[k],lw=5,alpha=.8,label={'retained':'Retained','redirected':'Redirected','no_selection':'No selection'}[k]) for k in out],loc='upper center',bbox_to_anchor=(.5,1.095),frameon=False,ncol=3,fontsize=6.5,handlelength=1.3,borderaxespad=0)

    panel(axb,'b')
    dims=['corrosion','cycling_phase','containment','literature_replication','data_completeness','inverse_burden']
    dlab={'corrosion':'Corrosion','cycling_phase':'Cycling/phase','containment':'Containment','literature_replication':'Literature','data_completeness':'Data','inverse_burden':'Burden'}
    dcol={'corrosion':BURGUNDY,'cycling_phase':MUSTARD,'containment':OLIVE,'literature_replication':ROSE,'data_completeness':BLUE,'inverse_burden':NAVY}
    sp=DSHORT.pivot(index='scenario',columns='credibility_dimension',values='weighted_shortfall_share').reindex(SCENARIOS).fillna(0); sp=sp.loc[sp.sum(axis=1)>EPS]
    left=np.zeros(len(sp)); y=np.arange(len(sp))
    for d in dims:
        v=sp.get(d,pd.Series(0,index=sp.index)).to_numpy(float)
        axb.barh(y,v,left=left,height=.66,color=dcol[d],label=dlab[d])
        for i,val in enumerate(v):
            if val>.16: axb.text(left[i]+val/2,i,f'{val:.0%}',ha='center',va='center',fontsize=6.5,color='white' if d not in {'cycling_phase'} else INK)
        left+=v
    axb.set_yticks(y,[scenario_code(x) for x in sp.index]); axb.set_xlim(0,1.0); barh_headroom(axb,len(sp),.82); axb.set_xlabel('Displaced-leader shortfall share'); clean(axb,'x')
    axb.legend(loc='upper left',bbox_to_anchor=(.01,.985),frameon=False,fontsize=6.5,ncol=3,columnspacing=.42,handlelength=.90,handletextpad=.30,labelspacing=.18,borderaxespad=0)

    panel(axc,'c')
    rv=RDIV[(RDIV.redirected_draw_frequency>0)&RDIV.effective_route_count.notna()].copy()
    offsets_c={'coal_flexibility_storage':(24,14,'left','bottom'),'csp_sensible_storage':(-14,7,'right','bottom'),'industrial_medium_heat':(26,-18,'left','top'),'sco2_high_temperature_storage':(22,-18,'left','top'),'pcm_target_350C':(22,14,'left','bottom'),'pcm_target_425C':(22,14,'left','bottom'),'pcm_target_500C':(22,14,'left','bottom')} 
    for r in rv.itertuples(index=False):
        axc.scatter(r.top_route_share_within_redirected,r.effective_route_count,s=52+430*r.redirected_draw_frequency,color=SCENARIO_COLOR[r.scenario],edgecolor='white',lw=.6,zorder=3)
        dx,dy,ha,va=offsets_c.get(r.scenario,(20,12,'left','bottom'))
        axc.annotate(scenario_code(r.scenario),(r.top_route_share_within_redirected,r.effective_route_count),xytext=(dx,dy),textcoords='offset points',fontsize=6.5,ha=ha,va=va,clip_on=True,arrowprops=dict(arrowstyle='-',color=MID_GREY,lw=.40,shrinkA=2,shrinkB=5))
    axc.set_xlim(-.10,1.12); axc.set_ylim(.68,float(rv.effective_route_count.max())+.72); axc.set_xlabel('Top-route share among redirected draws'); axc.set_ylabel('Effective route count'); clean(axc,'both')
    h3=[Line2D([0],[0],marker='o',ls='',markerfacecolor=NEUTRAL,markeredgecolor='white',label='Marker area: redirection frequency',markersize=5)]
    axc.legend(handles=h3,loc='upper left',bbox_to_anchor=(.03,.97),frameon=False,fontsize=6.5,borderaxespad=0)

    panel(axd,'d')
    rt=RTRADE[RTRADE.application_equal_route_frequency>=.0005].copy().sort_values('application_equal_route_frequency',ascending=False); sizes=36+1550*rt.application_equal_route_frequency; edge=np.where(rt.raw_cost_change_usd_kWhth>0,BURGUNDY,OLIVE)
    axd.scatter(rt.additional_volume_p50_m3_MWh,rt.engineering_credibility_change,s=sizes,c=[SCENARIO_COLOR[x] for x in rt.scenario],edgecolor=edge,lw=.85,alpha=.92)
    axd.axvline(0,color=INK,lw=.6); axd.axhline(0,color=INK,lw=.6)
    route_offsets={
        ('coal_flexibility_storage','Solar Salt SS60'):(12,12,'left','bottom'),
        # Short local CSP leader routes down-left; Industrial remains separated down-right.
        ('csp_sensible_storage','Solar Salt SS60'):(36,-10,'left','top'),
        ('industrial_medium_heat','Solar Salt SS60'):(24,-28,'left','top'),
        ('coal_flexibility_storage','KNO2-KNO3-K2CO3 eutectic'):(12,9,'left','bottom'),
    }
    for r in rt.head(4).itertuples(index=False):
        dx,dy,ha,va=route_offsets.get((r.scenario,r.to_display_system),(18,10,'left','bottom'))
        route_name_map={'Quaternary nitrate S7':'S7','NaNO3-KNO3-Na2CO3-NaCl eutectic':'QNCC','KNO2-KNO3-K2CO3 eutectic':'KNC','Solar Salt SS60':'Solar Salt','HITEC XL':'HITEC XL'}
        from_name=route_name_map.get(r.from_display_system,short_candidate(r.from_display_system)); to_name=route_name_map.get(r.to_display_system,short_candidate(r.to_display_system))
        label=f"{scenario_code(r.scenario)} · {from_name}→{to_name}"
        axd.annotate(label,(r.additional_volume_p50_m3_MWh,r.engineering_credibility_change),xytext=(dx,dy),textcoords='offset points',
                     fontsize=6.5,ha=ha,va=va,clip_on=True,
                     arrowprops=dict(arrowstyle='-',lw=.40,color=MID_GREY,shrinkA=2,shrinkB=5))
    axd.set_xlim(rt.additional_volume_p50_m3_MWh.min()-1.30, rt.additional_volume_p50_m3_MWh.max()+2.35)
    axd.set_ylim(min(-.10,float(rt.engineering_credibility_change.min())-.08), max(.45,float(rt.engineering_credibility_change.max())+.08))
    axd.set_xlabel('Route-level volume penalty (m$^3$ MWh$_{th}^{-1}$)'); axd.set_ylabel('Engineering-credibility change'); clean(axd,'both')
    hs=[Line2D([0],[0],marker='o',ls='',color=SCENARIO_COLOR[s],label=scenario_code(s),markersize=4) for s in ['coal_flexibility_storage','csp_sensible_storage','industrial_medium_heat']] + [Line2D([0],[0],marker='o',ls='',markerfacecolor='white',markeredgecolor=OLIVE,label='Raw-cost proxy decreases',markersize=4),Line2D([0],[0],marker='o',ls='',markerfacecolor='white',markeredgecolor=BURGUNDY,label='Raw-cost proxy increases',markersize=4)]
    axd.legend(handles=hs,loc='upper right',bbox_to_anchor=(.985,.985),frameon=False,fontsize=6.5,ncol=2,columnspacing=.38,handletextpad=.28,labelspacing=.16,borderaxespad=0)
    save_figure(fig,'3','Evidence gating redirects strict-service choices through identifiable shortfalls, route concentration and trade-offs',['figure_selection_alluvial_flows','displaced_leader_shortfall_composition','redirection_route_diversity','redirection_tradeoff_routes'])

def make_fig4():
    fig=plt.figure(figsize=(MAIN_W, MAIN_H), constrained_layout=True)
    gs=fig.add_gridspec(3,2,height_ratios=[1.0,1.0,1.08],hspace=0.070,wspace=0.055)
    axa=fig.add_subplot(gs[0,0]); axb=fig.add_subplot(gs[0,1]); axc=fig.add_subplot(gs[1,0]); axd=fig.add_subplot(gs[1,1])
    sub=gs[2,:].subgridspec(1,5,wspace=.06)
    axe_list=[fig.add_subplot(sub[0,i]) for i in range(5)]

    panel(axa,'a')
    gf=load('gate_multilabel_failure_breakdown'); gate_map={'incomplete_service':'incomplete_service','corrosion_gate':'corrosion','cycling_phase_gate':'cycling_phase','containment_gate':'containment','validation_gate':'literature_validation','data_completeness_gate':'data_completeness'}; gf=gf[gf.gate_reason.isin(gate_map)].copy(); gf['gate']=gf.gate_reason.map(gate_map); piv=gf.pivot_table(index='scenario',columns='gate',values='observed_failure_frequency',aggfunc='mean').reindex(index=SCENARIOS,columns=GATE_ORDER).fillna(0)
    heatmap(axa,piv,[scenario_code(x) for x in piv.index],['Service','Corrosion','Cycling','Containment','Literature','Data'],cmap=LinearSegmentedColormap.from_list('gate',[VERY_LIGHT,CREAM,BURGUNDY]),vmin=0,vmax=max(.01,piv.to_numpy().max()),annotate=False,cbar_label='Observed failure frequency',fig=fig); axa.tick_params(axis='x',labelsize=6.5,rotation=28); axa.tick_params(axis='y',labelsize=6.5)

    panel(axb,'b')
    inter=GINTH[(GINTH.gate_count>0)&(GINTH.application_equal_frequency>=.004)].head(9).sort_values('application_equal_frequency'); norm=Normalize(vmin=1,vmax=max(2,int(inter.gate_count.max()))); cmap=LinearSegmentedColormap.from_list('depth',[MUSTARD,ROSE,BURGUNDY]); y=np.arange(len(inter))
    axb.barh(y,inter.application_equal_frequency,color=[cmap(norm(v)) for v in inter.gate_count],height=.66)
    labels=[str(x).replace('incomplete service','Svc').replace('cycling phase','Cyc').replace('containment','Cont').replace('literature validation','Lit').replace('data completeness','Data').replace('corrosion','Corr').replace(' + ',' + ') for x in inter.intersection_label]
    axb.set_yticks(y,label_wrap(labels,18)); axb.tick_params(axis='y',labelsize=6.5); axb.set_xlabel('Application-equal gate-intersection frequency'); axb.xaxis.set_major_formatter(plt.FuncFormatter(lambda x,pos:f'{x:.0%}')); clean(axb,'x')

    panel(axc,'c')
    sh=SHAP[SHAP.scope=='application'].pivot(index='scenario',columns='gate',values='shapley_unlock_contribution').reindex(index=SCENARIOS,columns=GATE_ORDER).fillna(0); base=SHAP[SHAP.scope=='application'].groupby('scenario').baseline_retained_frequency.first().reindex(SCENARIOS).fillna(0); y=np.arange(len(SCENARIOS)); left=base.to_numpy(float)
    axc.barh(y,left,height=.64,color=LIGHT_GREY,label='Baseline retained')
    gate_cols=[NAVY,BURGUNDY,MUSTARD,OLIVE,ROSE,BLUE]
    for g,color in zip(GATE_ORDER,gate_cols):
        v=sh[g].to_numpy(float); axc.barh(y,v,left=left,height=.64,color=color,label=GATE_LABEL[g]); left+=v
    axc.set_yticks(y,[scenario_code(x) for x in SCENARIOS]); axc.set_xlim(0,1.08); barh_headroom(axc,len(SCENARIOS),1.95); axc.set_xlabel('Shapley share of retained-frequency restoration'); clean(axc,'x')
    gate_handle_map={g:Patch(facecolor=c,label=GATE_LABEL[g]) for g,c in zip(GATE_ORDER,gate_cols)}
    # ncol=3 yields three rows; this order places Data completeness in the first visual row.
    gate_handles=[Patch(facecolor=LIGHT_GREY,label='Baseline'),
                  gate_handle_map['corrosion'],gate_handle_map['cycling_phase'],
                  gate_handle_map['incomplete_service'],gate_handle_map['containment'],
                  gate_handle_map['data_completeness'],gate_handle_map['literature_validation']]
    axc.legend(handles=gate_handles,loc='upper left',bbox_to_anchor=(.01,.985),frameon=False,fontsize=6.5,ncol=3,columnspacing=.35,borderaxespad=0,handlelength=.82,handletextpad=.30,labelspacing=.24)

    panel(axd,'d')
    gt=GTRANSFER.set_index('scenario').reindex(SCENARIOS).reset_index(); y=np.arange(len(gt)); gate_colors={'incomplete_service':NAVY,'corrosion':BURGUNDY,'cycling_phase':MUSTARD,'containment':OLIVE,'literature_validation':ROSE,'data_completeness':BLUE}
    for i,r in enumerate(gt.itertuples(index=False)):
        axd.plot([r.baseline_retained_frequency,r.retained_frequency_after_top_gate_closure],[i,i],color=LIGHT_GREY,lw=2.0,zorder=1)
        axd.scatter(r.baseline_retained_frequency,i,s=28,color=NEUTRAL,edgecolor='white',lw=.45,zorder=2)
        axd.scatter(r.retained_frequency_after_top_gate_closure,i,s=44,color=gate_colors.get(r.closed_gate,MID_GREY),edgecolor='white',lw=.55,zorder=3)
        residual='resolved' if r.residual_dominant_failure_frequency<EPS else str(r.residual_dominant_gate_label).replace('Literature validation','Literature').replace('Incomplete service','Service')
        axd.text(1.05,i,f"{str(r.closed_gate_label).replace('Data completeness','Data').replace('Incomplete service','Service')} → {residual}",va='center',fontsize=6.5,color=INK)
    axd.set_yticks(y,[scenario_code(x) for x in gt.scenario]); axd.set_xlim(-.03,1.70); axd.set_xticks([0,.25,.5,.75,1.0]); axd.set_xlabel('Retained frequency'); clean(axd,'x')
    axd.legend(handles=[Line2D([0],[0],marker='o',ls='',color=NEUTRAL,label='Baseline',markersize=4),Line2D([0],[0],marker='o',ls='',color=NAVY,label='After top-gate closure',markersize=4)],loc='upper left',bbox_to_anchor=(.01,.98),frameon=False,ncol=1,fontsize=6.5,borderaxespad=0)

    order=['Coal','CSP','Industrial','sCO2','PCM targets']; colors=[NAVY,MUSTARD,OLIVE,TERRACOTTA,BURGUNDY]
    gd=GDEPTH.copy(); gd['service_group']=gd.scenario.map(lambda x:'PCM targets' if str(x).startswith('pcm_target') else SCENARIO_CODE[x]); rows=[]
    for (g,k),subdf in gd.groupby(['service_group','closed_gate_count']): rows.append({'service_group':g,'closed_gate_count':k,'median':subdf.median_retained_frequency.mean(),'minimum':subdf.minimum_retained_frequency.min(),'maximum':subdf.maximum_retained_frequency.max()})
    ag=pd.DataFrame(rows)
    for ax,g,color in zip(axe_list,order,colors):
        z=ag[ag.service_group.eq(g)].sort_values('closed_gate_count'); x=z.closed_gate_count.to_numpy(float); med=z['median'].to_numpy(float); lo=z['minimum'].to_numpy(float); hi=z['maximum'].to_numpy(float)
        ax.fill_between(x,lo,hi,color=color,alpha=.12,lw=0,zorder=1); ax.plot(x,med,color=color,lw=1.6,marker='o',ms=4.0,markeredgecolor='white',markeredgewidth=.6,zorder=2)
        ax.set_title(g,fontsize=6.5,pad=2.0); ax.set_xlim(-.10,6.10); ax.set_ylim(-.04,1.05); ax.set_xticks(range(7)); clean(ax,'both')
    panel(axe_list[0],'e')
    for i,ax in enumerate(axe_list):
        if i==0: ax.set_ylabel('Retained frequency')
        else: ax.set_yticklabels([])
        ax.set_xlabel('Number of jointly closed gates' if i==2 else '')
    axe_list[2].legend(handles=[Line2D([0],[0],color=INK,lw=1.4,marker='o',markersize=4,label='Median'),Patch(facecolor=MID_GREY,alpha=.16,label='Min–max subset range')],loc='lower center',bbox_to_anchor=(.50,1.14),frameon=False,ncol=2,fontsize=6.5,columnspacing=.65,borderaxespad=0)
    save_figure(fig,'4','Deployability bottlenecks have distinct prevalence, co-occurrence, Shapley importance, substitution and closure-depth response',['gate_multilabel_failure_breakdown','gate_intersection_horizontal_summary','gate_shapley_attribution','gate_bottleneck_transfer','gate_closure_depth_response'])

def make_fig5():
    fig=plt.figure(figsize=(MAIN_W, MAIN_H), constrained_layout=True)
    gs=fig.add_gridspec(3,2,height_ratios=[1.0,1.0,1.0],width_ratios=[1.10,.90],hspace=0.040,wspace=0.020)
    axa=fig.add_subplot(gs[0,:]); axb=fig.add_subplot(gs[1,0]); axc=fig.add_subplot(gs[1,1]); axd=fig.add_subplot(gs[2,0]); axe=fig.add_subplot(gs[2,1])

    panel(axa,'a')
    ws=WSTAB.copy(); y=np.arange(len(ws)); off=.12
    axa.hlines(y+off,ws.top1_top2_gap_p05,ws.top1_top2_gap_p95,color=PALE_BLUE,lw=3.4)
    axa.scatter(ws.top1_top2_gap_p50,y+off,s=46,color=NAVY,edgecolor='white',lw=.45,label='Top1–top2 gap')
    axa.hlines(y-off,ws.leader_frequency_p05,ws.leader_frequency_p95,color=CREAM,lw=3.4)
    axa.scatter(ws.leader_frequency_p50,y-off,s=46,color=MUSTARD,edgecolor='white',lw=.45,label='Modal-leader frequency')
    for i,r in enumerate(ws.itertuples(index=False)): axa.text(.99,i,short_candidate(r.modal_leader),ha='right',va='center',fontsize=6.5,color=MID_GREY)
    axa.set_yticks(y,[scenario_code(x) for x in ws.scenario]); axa.set_xlim(0,1.02); axa.set_xlabel('Decision metric across weight space (5th–50th–95th percentiles)'); clean(axa,'x')
    axa.legend(loc='lower left',bbox_to_anchor=(.012,.055),frameon=False,ncol=1,fontsize=6.5,columnspacing=.65,handletextpad=.35,labelspacing=.22,borderaxespad=0)

    panel(axb,'b')
    meta={'profile_signature','member_count','member_scenarios','member_labels','group_order'}; cand_cols=[c for c in SMAAG.columns if c not in meta]; active=[c for c in cand_cols if float(SMAAG[c].max())>=.01 or c=='No formal selection']; y=np.arange(len(SMAAG)); left=np.zeros(len(SMAAG))
    for cand in active:
        vals=SMAAG[cand].to_numpy(float); lab='No selection' if cand=='No formal selection' else short_candidate(cand)
        axb.barh(y,vals,left=left,height=.66,color=NEUTRAL if lab=='No selection' else CANDIDATE_COLORS.get(lab,NEUTRAL),label=lab); left+=vals
    smaa_labels=['PCM targets' if 'PCM350' in str(x) and 'PCM425' in str(x) and 'PCM500' in str(x) else chem_label(str(x)) for x in SMAAG.member_labels]
    axb.set_yticks(y,smaa_labels); axb.set_xlim(0,1.0); barh_headroom(axb,len(SMAAG),1.15); axb.set_xlabel('SMAA rank-1 acceptability'); clean(axb,'x')
    axb.legend(loc='upper left',bbox_to_anchor=(.01,.985),frameon=False,fontsize=6.5,ncol=3,columnspacing=.32,handlelength=.85,handletextpad=.30,labelspacing=.22,borderaxespad=0)

    panel(axc,'c')
    t=JTHRESH.copy(); t['service_group']=t.scenario.map(lambda x:'PCM targets' if str(x).startswith('pcm_target') else SCENARIO_CODE[x]); t=t.groupby('service_group',as_index=False)[['robust_regime_share','conditional_regime_share','no_access_regime_share']].mean().set_index('service_group').reindex(['Coal','CSP','Industrial','sCO2','PCM targets']).reset_index(); y=np.arange(len(t)); left=np.zeros(len(t))
    for field,label,color in [('robust_regime_share','Robust',OLIVE),('conditional_regime_share','Conditional',MUSTARD),('no_access_regime_share','No access',BURGUNDY)]:
        vals=t[field].to_numpy(float); axc.barh(y,vals,left=left,height=.66,color=color,label=label)
        for i,v in enumerate(vals):
            if v>.12: axc.text(left[i]+v/2,i,f'{v:.0%}',ha='center',va='center',fontsize=6.5,color='white' if color!=MUSTARD else INK)
        left+=vals
    axc.set_yticks(y,t.service_group); axc.set_xlim(0,1.0); barh_headroom(axc,len(t),1.15); axc.set_xlabel('Joint coverage–evidence regime share'); clean(axc,'x')
    axc.legend(loc='upper left',bbox_to_anchor=(.01,.985),frameon=False,fontsize=6.5,ncol=2,columnspacing=.55,borderaxespad=0)

    panel(axd,'d')
    om=OMSUM.copy().sort_values('delta_modal_leader_frequency'); y=np.arange(len(om)); marker={'candidate':'o','source':'s'}
    axd.hlines(y,0,om.delta_modal_leader_frequency,color=LIGHT_GREY,lw=1.3)
    for i,r in enumerate(om.itertuples(index=False)):
        axd.scatter(r.delta_modal_leader_frequency,i,s=46+135*r.influence_magnitude,marker=marker.get(r.omission_type,'o'),color=OLIVE if r.leader_changed else ROSE,edgecolor=INK,lw=.6,zorder=3)
    labels=[f"{scenario_code(s)} · {('cand' if t=='candidate' else 'source')}" for s,t in zip(om.scenario,om.omission_type)]
    axd.set_yticks(y,labels); axd.tick_params(axis='y',labelsize=6.5); axd.axvline(0,color=INK,lw=.65); axd.set_xlim(om.delta_modal_leader_frequency.min()-.05, om.delta_modal_leader_frequency.max()+.08)
    axd.set_xlabel('Modal-leader-frequency change'); clean(axd,'x')
    # Show only cross-combinations that actually occur; the released table contains two, not four.
    observed=om[['omission_type','leader_changed']].drop_duplicates().sort_values(['omission_type','leader_changed'],ascending=[True,False])
    hs=[]
    for r in observed.itertuples(index=False):
        unit='Candidate omitted' if r.omission_type=='candidate' else 'Source omitted'
        outcome='leader changed' if bool(r.leader_changed) else 'leader retained'
        hs.append(Line2D([0],[0],marker=marker.get(r.omission_type,'o'),ls='',
                         markerfacecolor=OLIVE if bool(r.leader_changed) else ROSE,markeredgecolor=INK,
                         color='none',label=f'{unit} · {outcome}',markersize=4.5))
    axd.legend(handles=hs,loc='lower center',bbox_to_anchor=(.50,1.035),frameon=False,fontsize=6.5,ncol=2,handletextpad=.24,columnspacing=.55,labelspacing=.14,borderaxespad=0)

    panel(axe,'e')
    ut=UTRANS.copy()
    data_xmin=float(ut.delta_selection_entropy.min()); data_xmax=float(ut.delta_selection_entropy.max()); data_xspan=max(data_xmax-data_xmin,.50)
    xmin=min(-.95,data_xmin-.18*data_xspan); xmax=max(.62,data_xmax+.22*data_xspan)
    axe.axvspan(xmin,0,color=ROSE_LIGHT,alpha=.10,lw=0)
    label_offset={'pcm_target_500C':(8,8,'left'),'pcm_target_425C':(-8,-14,'right'),'pcm_target_350C':(-14,-10,'right'),'coal_flexibility_storage':(8,10,'left'),'csp_sensible_storage':(8,8,'left'),'industrial_medium_heat':(-10,10,'right'),'sco2_high_temperature_storage':(-10,10,'right')}
    for r in ut.itertuples(index=False):
        marker_i='X' if r.collapse_to_no_selection else 'o'
        axe.scatter(r.delta_selection_entropy,r.delta_no_selection_frequency,s=62 if not r.collapse_to_no_selection else 78,marker=marker_i,color=SCENARIO_COLOR[r.scenario],edgecolor=INK if r.collapse_to_no_selection else 'white',lw=.75,zorder=3)
        dx,dy,ha=label_offset.get(r.scenario,(6,4,'left')); axe.annotate(scenario_code(r.scenario),(r.delta_selection_entropy,r.delta_no_selection_frequency),xytext=(dx,dy),textcoords='offset points',fontsize=6.5,ha=ha,va='bottom' if dy>=0 else 'top',clip_on=True,arrowprops=dict(arrowstyle='-',color=MID_GREY,lw=.36,shrinkA=2,shrinkB=3))
    axe.axvline(0,color=INK,lw=.65); axe.axhline(0,color=INK,lw=.65)
    axe.set_xlim(xmin,xmax); axe.set_ylim(-.10,1.34); axe.set_xlabel('Selection-entropy change (strict → bounded; bits)'); axe.set_ylabel('No-selection-frequency change'); clean(axe,'both')
    h5=[Line2D([0],[0],marker='o',ls='',markerfacecolor=NEUTRAL,markeredgecolor='white',label='No collapse',markersize=4),Line2D([0],[0],marker='X',ls='',markerfacecolor=NEUTRAL,markeredgecolor=INK,label='Collapse to no selection',markersize=5)]
    axe.legend(handles=h5,loc='lower center',bbox_to_anchor=(.50,1.035),frameon=False,fontsize=6.5,ncol=2,columnspacing=.55,handletextpad=.25,borderaxespad=0)
    save_figure(fig,'5','Robustness is resolved through weight-space decisiveness, SMAA, thresholds, omission influence and uncertainty transition',['weight_space_stability_summary','smaa_rank1_groups','joint_threshold_regime_summary','omission_influence_summary','selection_uncertainty_transition'])

def make_fig6():
    fig=plt.figure(figsize=(MAIN_W, MAIN_H), constrained_layout=True)
    gs=fig.add_gridspec(3,2,height_ratios=[1.0,1.0,1.0],hspace=0.040,wspace=0.020)
    axa=fig.add_subplot(gs[0,:]); axb=fig.add_subplot(gs[1,0]); axc=fig.add_subplot(gs[1,1]); axd=fig.add_subplot(gs[2,0]); axe=fig.add_subplot(gs[2,1])
    eligible=PORT[PORT.comparison_eligible].closure_action.unique().tolist()
    action_compact={'combined_atomic_evidence_closure':'Combined','exact_composition_corrosion_closure':'Corrosion','literature_replication_closure':'Replication'}

    panel(axa,'a')
    nz=ANONZERO[ANONZERO.closure_action.isin(eligible)].copy(); nz['label']=nz.apply(lambda r:f"{action_compact.get(r.closure_action,ACTION_LABEL.get(r.closure_action,r.closure_action))} · {scenario_code(r.scenario)}",axis=1); nz=nz.sort_values('delta_expected_normalized_service_value'); y=np.arange(len(nz))
    axa.hlines(y,0,nz.delta_expected_normalized_service_value,color=PALE_BLUE,lw=1.9); axa.scatter(nz.delta_expected_normalized_service_value,y,s=50+135*nz.delta_selection_probability.clip(lower=0),c=[SCENARIO_COLOR[x] for x in nz.scenario],edgecolor='white',lw=.55); axa.axvline(0,color=INK,lw=.75)
    for xi,yi in zip(nz.delta_expected_normalized_service_value,y):
        direction=1 if xi>=0 else -1
        axa.annotate(f'{xi:+.2f}',(xi,yi),xytext=(7*direction,0),textcoords='offset points',
                     va='center',ha='left' if direction>0 else 'right',fontsize=6.5,color=INK,clip_on=True)
    xlo=float(nz.delta_expected_normalized_service_value.min()); xhi=float(nz.delta_expected_normalized_service_value.max()); span=max(xhi-xlo,.50)
    axa.set_yticks(y,nz.label); categorical_marker_padding(axa,len(nz),.74); axa.tick_params(axis='y',labelsize=6.5); axa.set_xlim(min(-.05,xlo-.05*span), xhi+.14*span); axa.set_xlabel('Normalized service-value gain; marker area = selection-probability gain'); clean(axa,'x')

    panel(axb,'b')
    metrics=['delta_selection_entropy','delta_top1_top2_frequency_gap','delta_mean_top_two_utility_margin','delta_leader_exceeds_benchmark_probability']; uv=URVALUE[URVALUE.closure_action.isin(eligible)].groupby('closure_action',as_index=False)[metrics].mean().set_index('closure_action').reindex(eligible).dropna(how='all')
    heatmap(axb,uv,[ACTION_LABEL.get(x,x) for x in uv.index],['Entropy','Rank-frequency gap','Utility margin','Benchmark exceedance'],cmap=LinearSegmentedColormap.from_list('signed_action',[BURGUNDY,VERY_LIGHT,OLIVE]),center=0,annotate=True,fmt='{:+.2f}',cbar_label='Mean decision-quality change',fig=fig); axb.tick_params(axis='x',labelsize=6.5); axb.tick_params(axis='y',labelsize=6.5)

    panel(axc,'c')
    ev=PORT[PORT.comparison_eligible].copy()
    levels=sorted(ev.burden_ordinal_index.dropna().unique().tolist())
    xpos={float(v):i for i,v in enumerate(levels)}
    level_label={'moderate':'Moderate','high':'High','very_high':'Very high','moderate_to_high':'Moderate–high','low_to_moderate':'Low–moderate','low':'Low'}
    for r in ev.itertuples(index=False):
        x=xpos[float(r.burden_ordinal_index)]
        axc.scatter(x,r.mean_no_selection_reduction,s=70+300*r.largest_positive_decision_benefit,color=OLIVE if r.non_dominated_under_registered_ordering else ROSE,edgecolor=BURGUNDY if r.adverse_application_fraction>0 else 'white',lw=.95)
        off=(-60,-12) if x==max(xpos.values()) else (4,4)
        axc.annotate(ACTION_LABEL.get(r.closure_action,r.closure_action),(x,r.mean_no_selection_reduction),xytext=off,textcoords='offset points',fontsize=6.5)
    tick_labels=[]
    for v in levels:
        row=ev.loc[ev.burden_ordinal_index.eq(v)].iloc[0]
        tick_labels.append(f"{level_label.get(str(row.burden_level),str(row.burden_level))}\n({v:g})")
    axc.set_xticks(range(len(levels)),tick_labels)
    axc.set_xlim(-.28,max(xpos.values())+.42); axc.set_ylim(-.01,ev.mean_no_selection_reduction.max()+.09); axc.set_xlabel('Registered research-burden level (ordinal)'); axc.set_ylabel('Mean reduction in no-selection frequency'); clean(axc,'both')
    action_leg=[
        Line2D([0],[0],marker='o',ls='',markerfacecolor=OLIVE,markeredgecolor='white',label='Non-dominated under registered criteria',markersize=5),
        Line2D([0],[0],marker='o',ls='',markerfacecolor=ROSE,markeredgecolor='white',label='Other comparison-eligible action',markersize=5),
        Line2D([0],[0],marker='o',ls='',markerfacecolor=NEUTRAL,markeredgecolor='white',label='Marker area: largest decision benefit',markersize=5),
    ]
    axc.legend(handles=action_leg,loc='upper left',bbox_to_anchor=(.02,.98),frameon=False,fontsize=6.5,borderaxespad=0,handletextpad=.35,labelspacing=.30)

    panel(axd,'d')
    z=CSIGNED[(CSIGNED.closure_action.isin(eligible))&(CSIGNED.delta_selection_frequency.abs()>=.01)].copy(); z['label']=z.apply(lambda r:f"{action_compact.get(r.closure_action,ACTION_LABEL.get(r.closure_action,r.closure_action))} · {scenario_code(r.scenario)}",axis=1); z=z.reindex(z.delta_selection_frequency.abs().sort_values(ascending=False).index).head(10).sort_values('delta_selection_frequency'); y=np.arange(len(z))
    axd.hlines(y,0,z.delta_selection_frequency,color=PALE_BLUE,lw=1.7); axd.scatter(z.delta_selection_frequency,y,c=np.where(z.delta_selection_frequency>=0,OLIVE,BURGUNDY),s=44,edgecolor='white',lw=.4); axd.axvline(0,color=INK,lw=.75);
    for xi,yi in zip(z.delta_selection_frequency,y):
        direction=1 if xi>=0 else -1
        axd.annotate(f'{xi:+.2f}',(xi,yi),xytext=(7*direction,0),textcoords='offset points',
                     va='center',ha='left' if direction>0 else 'right',fontsize=6.5,color=INK,clip_on=False)
    xlo=float(z.delta_selection_frequency.min()); xhi=float(z.delta_selection_frequency.max()); span=max(xhi-xlo,.25)
    axd.set_yticks(y,z.label); barh_headroom(axd,len(z),1.10); axd.tick_params(axis='y',labelsize=6.5); axd.set_xlim(xlo-.16*span,xhi+.18*span); axd.set_xlabel('Selection-frequency change (|Δ| ≥ 1%)'); clean(axd,'x')

    panel(axe,'e')
    na=NONADD.sort_values('nonadditivity_delta_expected_normalized_service_value').copy(); y=np.arange(len(na)); class_color={'complementary':OLIVE,'overlapping':BURGUNDY,'additive':NEUTRAL}; vals=na.nonadditivity_delta_expected_normalized_service_value.to_numpy(float)
    axe.hlines(y,0,vals,color=PALE_BLUE,lw=1.8); axe.scatter(vals,y,s=52+115*na.nonadditivity_delta_selection_probability.abs(),c=[class_color[x] for x in na.interaction_class],edgecolor='white',lw=.55,zorder=3); axe.axvline(0,color=INK,lw=.75)
    for xi,yi in zip(vals,y):
        direction=1 if xi>=0 else -1
        axe.annotate(f'{xi:+.2f}',(xi,yi),xytext=(7*direction,0),textcoords='offset points',
                     va='center',ha='left' if direction>0 else 'right',fontsize=6.5,color=INK,clip_on=False)
    xlo=float(vals.min()); xhi=float(vals.max()); span=max(xhi-xlo,.25)
    axe.set_yticks(y,[scenario_code(x) for x in na.scenario]); barh_headroom(axe,len(na),1.18); axe.tick_params(axis='y',labelsize=6.5); axe.set_xlim(xlo-.22*span, xhi+.28*span); axe.set_xlabel('Programme nonadditivity in normalized service value'); clean(axe,'x')
    hs=[Line2D([0],[0],marker='o',ls='',color=class_color[k],label=k.title(),markersize=4.5) for k in ['complementary','additive','overlapping']]
    axe.legend(handles=hs,loc='upper center',bbox_to_anchor=(.5,1.15),frameon=False,ncol=3,fontsize=6.5,columnspacing=.8,borderaxespad=0)
    save_figure(fig,'6','Evidence actions differ in value, decision quality, burden, redistribution and programme interaction',['atomic_action_service_nonzero_scorecard','uncertainty_reduction_value','research_action_nondominance_assessment','counterfactual_candidate_signed_changes','evidence_programme_nonadditivity'])

def make_ed1():
    fig=plt.figure(figsize=(SUPP_W,5.15),constrained_layout=False)
    gs=fig.add_gridspec(1,3,width_ratios=[0.92,1.62,1.02],wspace=.56)
    fig.subplots_adjust(left=0.085,right=0.985,top=0.87,bottom=0.14)
    axa=fig.add_subplot(gs[0,0]); axb=fig.add_subplot(gs[0,1]); axc=fig.add_subplot(gs[0,2])
    panel(axa,'a')
    fam_order=UFS.groupby('formula_family').composition_records.sum().sort_values().index.tolist()
    for fam in fam_order:
        z=UFS[UFS.formula_family==fam]; axa.scatter(z.component_count,z.composition_records,s=16+2.2*z.composition_records.clip(upper=50),alpha=.70,label=fam)
    axa.set_xlabel('Components per formula system'); axa.set_ylabel('Composition records per system'); axa.set_yscale('log'); axa.yaxis.set_major_formatter(FuncFormatter(lambda value, pos: f'{value:g}')); axa.yaxis.set_minor_formatter(NullFormatter()); clean(axa,'both'); axa.legend(loc='lower center',bbox_to_anchor=(.64,1.005),frameon=False,ncol=3,fontsize=6.5,columnspacing=.55,handletextpad=.25,labelspacing=.18,borderaxespad=0)

    panel(axb,'b')
    raw_counts={
        'Chloride':int(DBFAM.loc[DBFAM.formula_family.eq('chloride'),'unique_formula_systems'].sum()),
        'Fluoride':int(DBFAM.loc[DBFAM.formula_family.eq('fluoride'),'unique_formula_systems'].sum()),
        'Chloride–fluoride':int(DBFAM.loc[DBFAM.formula_family.eq('chloride–fluoride'),'unique_formula_systems'].sum()),
        'Nitrate-containing':0,
        'Carbonate-containing':0,
    }
    scope=CSCOPE[['display_system','family','exact_formula_system_match']].drop_duplicates('display_system').copy()
    def _cand_group(x):
        s=str(x)
        if 'nitrate' in s or 'nitrite' in s:
            return 'Nitrate-containing'
        if 'chloride' in s:
            return 'Chloride'
        return 'Carbonate-containing'
    scope['family_group']=scope['family'].map(_cand_group)
    cur_counts={k:int(v) for k,v in scope.groupby('family_group').size().to_dict().items()}
    for key in ['Chloride','Fluoride','Chloride–fluoride','Nitrate-containing','Carbonate-containing']:
        cur_counts.setdefault(key,0)
    order=['Chloride','Fluoride','Chloride–fluoride','Nitrate-containing','Carbonate-containing']
    palette={'Chloride':TERRACOTTA,'Fluoride':BLUE,'Chloride–fluoride':ROSE,'Nitrate-containing':MUSTARD,'Carbonate-containing':OLIVE}
    bars=[('Raw database',raw_counts),('Curated registry',cur_counts)]
    ypos=np.array([1,0],dtype=float)
    for yi,(label,counts) in zip(ypos,bars):
        total=sum(counts[k] for k in order)
        left=0.0
        for key in order:
            val=counts[key]
            if val<=0:
                continue
            share=val/total
            axb.barh(yi,share,left=left,height=.52,color=palette[key])
            if share>=.10:
                axb.text(left+share/2,yi,f'{share:.0%}',ha='center',va='center',fontsize=6.5,color='white' if key in {'Chloride','Fluoride','Chloride–fluoride'} else INK)
            left+=share
        axb.text(1.155,yi,f'n={total}',ha='right',va='center',fontsize=6.5,fontweight='bold',color=INK)
    exact_links=int(scope['exact_formula_system_match'].sum())
    axb.set_yticks(ypos,[x[0] for x in bars])
    axb.set_xlim(0,1.18)
    axb.xaxis.set_major_formatter(plt.FuncFormatter(lambda x,pos:f'{x:.0%}' if x<=1 else ''))
    axb.set_xlabel('Chemistry-family share')
    clean(axb,'x')
    handles=[Patch(facecolor=palette[k],label=k) for k in order if raw_counts.get(k,0)>0 or cur_counts.get(k,0)>0]
    axb.legend(handles=handles,loc='upper center',bbox_to_anchor=(.50,1.065),frameon=False,ncol=2,fontsize=6.5,columnspacing=.52,handlelength=.98,handletextpad=.30,borderaxespad=0,labelspacing=.18)

    panel(axc,'c')
    app=DBAPP.merge(UFS[['formula','formula_family']].drop_duplicates('formula'),on='formula',how='left'); comp=app.groupby(['scenario','formula_family'],as_index=False).lower_boundary_compatible.mean(); mat=comp.pivot(index='formula_family',columns='scenario',values='lower_boundary_compatible').reindex(columns=SCENARIOS).fillna(0)
    omitted=mat.index[mat.sum(axis=1)<=EPS].tolist(); mat=mat.loc[mat.sum(axis=1)>EPS]
    image=heatmap(axc,mat,mat.index,[scenario_code(x) for x in mat.columns],cmap=LinearSegmentedColormap.from_list('compat',[VERY_LIGHT,CREAM,OLIVE]),vmin=0,vmax=1,annotate=True,fmt='{:.0%}'); attached_top_colorbar(fig,axc,image,'Lower-bound compatibility',y=1.006,height=.032); axc.tick_params(axis='x',labelsize=6.5); axc.tick_params(axis='y',labelsize=6.5)
    save_figure(fig,'1','Formula-system granularity, database-versus-curated chemistry-family shares and non-zero application compatibility',['unique_formula_system_inventory','database_family_summary','candidate_scope_and_inclusion_audit','database_application_lower_bound_compatibility'],True)

def make_ed2():
    fig,axes=plt.subplots(1,2,figsize=(SUPP_W,6.2),constrained_layout=True,gridspec_kw={'wspace':.12,'width_ratios':[1.10,1.0]})
    panel(axes[0],'a')
    l=LINK.copy(); l['candidate']=l.display_system.map(short_candidate); l=l.sort_values(['best_component_set_jaccard','exact_formula_system_match'])
    y=np.arange(len(l)); axes[0].hlines(y,0,l.best_component_set_jaccard,color=LIGHT_GREY,lw=2.45)
    axes[0].scatter(l.best_component_set_jaccard,y,s=76,color=np.where(l.exact_formula_system_match,NAVY,MUSTARD),edgecolor='white',lw=.65,zorder=3)
    for i,r in enumerate(l.itertuples(index=False)):
        tag='exact' if r.exact_formula_system_match else 'literature anchored'
        value_badge(axes[0],r.best_component_set_jaccard,i,f'{r.best_component_set_jaccard:.2f}',dx=6,dy=0,color=NAVY if r.exact_formula_system_match else MUSTARD); axes[0].annotate(tag,(r.best_component_set_jaccard,i),xytext=(6,11),textcoords='offset points',fontsize=5.6,ha='left',va='center',color=MID_GREY,clip_on=True)
    axes[0].set_yticks(y,l.candidate); categorical_marker_padding(axes[0],len(l),.66); axes[0].set_xlim(-.045,1.25); axes[0].set_xlabel('Best component-set match / provenance context'); clean(axes[0],'x')
    panel(axes[1],'b'); a=ATOMIC.groupby('display_system')[['corrosion_compatibility_mid','cycling_phase_stability_mid','containment_validation_mid','literature_replication_mid','data_completeness_mid']].mean(); a.index=a.index.map(short_candidate); heatmap(axes[1],a,a.index,['Corrosion','Cycling','Containment','Literature','Data'],cmap=LinearSegmentedColormap.from_list('muted_seq',[VERY_LIGHT,PALE_BLUE,NAVY]),vmin=0,vmax=1,annotate=True,fmt='{:.2f}')
    save_figure(fig,'2','Candidate provenance context and average atomic credibility',['candidate_database_linkage_audit','atomic_engineering_credibility_registry'],True)

def make_ed3():
    fig,ax=plt.subplots(figsize=(SUPP_W,6.5),constrained_layout=False)
    # Long exact-composition labels require a fixed publication-width gutter.
    # Reserving it explicitly prevents silent clipping on the native 180 mm page.
    fig.subplots_adjust(left=.39,right=.98,bottom=.19,top=.88)
    cols=['fixed_window_coverage','cp_at_service_J_gK','density_at_service_kg_m3','thermal_k_at_service_W_mK','complete_service_energy_fixed_kWh_m3']
    rows=UPROF.copy(); rows['label']=rows.display_label
    rows.loc[rows.label.astype(str).str.len().gt(100),'label']='TMS-2 / NKN-KCl / FLiNaK RR / Nitrate S7 / KNC · shared profile'
    x=rows[cols].copy(); denom=(x.max()-x.min()).replace(0,np.nan); x=(x-x.min())/denom; x=x.fillna(.5)
    heatmap(ax,x,rows.label,['Coverage','Heat capacity','Density','Conductivity','Complete-service energy'],cmap=LinearSegmentedColormap.from_list('muted_seq2',[VERY_LIGHT,CREAM,OLIVE]),vmin=0,vmax=1,annotate=False,cbar_label='Column-normalized value',fig=fig); ax.tick_params(axis='y',labelsize=6.5)
    save_figure(fig,'3','Unique deterministic thermophysical profiles after collapsing exact duplicates',['unique_thermophysical_profiles'],True)

def make_ed4():
    fig,axes=plt.subplots(1,2,figsize=(SUPP_W,3.45),constrained_layout=True,gridspec_kw={'wspace':.11})
    panel(axes[0],'a')
    p=PAIR[PAIR.energy_comparable_draws>0].copy(); p['superiority_probability']=p.energy_superiority_i_gt_j; grouped_extremes=[]
    for _,g in p.sort_values('superiority_probability').groupby('scenario',sort=False):
        grouped_extremes.append(pd.concat([g.head(2),g.tail(2)]).drop_duplicates(['scenario','display_i','display_j']))
    top=pd.concat(grouped_extremes,ignore_index=True) if grouped_extremes else p.head(0).copy(); y=np.arange(len(top))
    axes[0].hlines(y,.5,top.superiority_probability,color=LIGHT_GREY,lw=1.55); axes[0].scatter(top.superiority_probability,y,c=[SCENARIO_COLOR[x] for x in top.scenario],s=48,edgecolor='white',lw=.55,zorder=3); [value_badge(axes[0],r.superiority_probability,i,f'{r.superiority_probability:.0%}',dx=5,dy=0,color=SCENARIO_COLOR[r.scenario]) for i,r in top.reset_index(drop=True).iterrows()]; axes[0].axvline(.5,color=INK,lw=.7); axes[0].set_xlim(-.02,1.16); axes[0].set_yticks(y,[f"{scenario_code(sc)} · {short_candidate(a)} > {short_candidate(b)}" for sc,a,b in zip(top.scenario,top.display_i,top.display_j)]); categorical_marker_padding(axes[0],len(top),.62); axes[0].tick_params(axis='y',labelsize=6.5); axes[0].set_xlabel('Energy-density superiority probability'); clean(axes[0],'x')
    panel(axes[1],'b')
    q=MC.dropna(subset=['raw_cost_p50_usd_kWhth_conditional_on_adequacy']).sort_values('raw_cost_p50_usd_kWhth_conditional_on_adequacy'); y=np.arange(len(q)); med=q.raw_cost_p50_usd_kWhth_conditional_on_adequacy
    axes[1].errorbar(med,y,xerr=[med-q.raw_cost_p05_usd_kWhth_conditional_on_adequacy,q.raw_cost_p95_usd_kWhth_conditional_on_adequacy-med],fmt='o',ms=5.0,color=MUSTARD,ecolor=MID_GREY,elinewidth=1.05,capsize=2.3); [value_badge(axes[1],float(v),i,f'{v:.3f}',dx=5,dy=0,color=MUSTARD) for i,v in enumerate(med)]; axes[1].set_xlim(0,float(q.raw_cost_p95_usd_kWhth_conditional_on_adequacy.max())*1.24); axes[1].set_yticks(y,[f"{scenario_code(a)} · {short_candidate(b)}" for a,b in zip(q.scenario,q.display_system)]); axes[1].set_xlabel('Conditional raw-material cost proxy\n(USD kWh$_{th}^{-1}$; 5–95%)'); categorical_marker_padding(axes[1],len(q),.62); axes[1].tick_params(axis='y',labelsize=6.5); clean(axes[1],'x')
    save_figure(fig,'4','Pairwise energy superiority and the separate raw-material-cost boundary',['pairwise_superiority_matrix','system_value_monte_carlo_summary'],True)

def make_ed5():
    fig,ax=plt.subplots(figsize=(SUPP_W,3.10),constrained_layout=True)
    p=PENGRP.sort_values('partial_minus_complete_kWh_m3').copy(); p['label']=p.apply(lambda r:f"{short_candidate(r.display_system)} · {chem_label(str(r.member_labels))}",axis=1)
    y=np.arange(len(p)); point_size=64
    ax.hlines(y,0,p.partial_minus_complete_kWh_m3,color=LIGHT_GREY,lw=2.25); ax.scatter(p.partial_minus_complete_kWh_m3,y,s=point_size,c=MUSTARD,edgecolor='white',lw=.55,zorder=3)
    coverage_artists=[]; value_artists=[]
    for i,r in enumerate(p.itertuples(index=False)):
        value_artist=value_badge(ax,r.partial_minus_complete_kWh_m3,i,f'{r.partial_minus_complete_kWh_m3:.1f}',dx=7,dy=0,color=MUSTARD)
        coverage_artist=ax.annotate(f'coverage {r.fixed_window_coverage:.2f}',(r.partial_minus_complete_kWh_m3,i),xytext=(-8,0),textcoords='offset points',fontsize=5.6,ha='right',va='center',color=MID_GREY,clip_on=True,zorder=7,bbox=dict(facecolor='white',edgecolor='none',pad=.16,alpha=.94))
        coverage_artists.append((i,r.label,float(r.partial_minus_complete_kWh_m3),coverage_artist))
        value_artists.append((i,r.label,float(r.partial_minus_complete_kWh_m3),value_artist))
    xlo=min(-8.0,float(p.partial_minus_complete_kWh_m3.min())-8.0); xhi=float(p.partial_minus_complete_kWh_m3.max())+38.0
    ax.set_xlim(xlo,xhi); ax.set_yticks(y,p.label); categorical_marker_padding(ax,len(p),.66); ax.set_xlabel('Partial-overlap energy overclaim (kWh m$^{-3}$)'); ax.tick_params(axis='y',labelsize=6.5); clean(ax,'x')

    # Publication QA: coverage belongs before the sphere, the overclaim value
    # belongs after it, and neither label may collide with another label.
    fig.canvas.draw(); renderer=fig.canvas.get_renderer(); axes_bbox=ax.bbox
    marker_radius_px=(point_size**.5)/2*fig.dpi/72
    layout_rows=[]
    for (i,label,x,coverage_artist),(_,_,_,value_artist) in zip(coverage_artists,value_artists):
        centre_x=float(ax.transData.transform((x,i))[0])
        coverage_bbox=coverage_artist.get_window_extent(renderer=renderer); value_bbox=value_artist.get_window_extent(renderer=renderer)
        overlap_w=max(0,min(coverage_bbox.x1,value_bbox.x1)-max(coverage_bbox.x0,value_bbox.x0))
        overlap_h=max(0,min(coverage_bbox.y1,value_bbox.y1)-max(coverage_bbox.y0,value_bbox.y0))
        layout_rows.append({
            'row':i,'label':label,'sphere_x':x,
            'coverage_before_sphere':bool(coverage_bbox.x1<=centre_x-marker_radius_px+.75),
            'value_after_sphere':bool(value_bbox.x0>=centre_x+marker_radius_px-.75),
            'coverage_inside_axes':bool(coverage_bbox.x0>=axes_bbox.x0-.75 and coverage_bbox.x1<=axes_bbox.x1+.75 and coverage_bbox.y0>=axes_bbox.y0-.75 and coverage_bbox.y1<=axes_bbox.y1+.75),
            'value_inside_axes':bool(value_bbox.x0>=axes_bbox.x0-.75 and value_bbox.x1<=axes_bbox.x1+.75 and value_bbox.y0>=axes_bbox.y0-.75 and value_bbox.y1<=axes_bbox.y1+.75),
            'same_row_overlap_area_px2':overlap_w*overlap_h,
            'same_row_collision':bool(overlap_w>0 and overlap_h>0),
        })
    all_labels=[('coverage',i,label,artist) for i,label,_,artist in coverage_artists]+[('value',i,label,artist) for i,label,_,artist in value_artists]
    collision_rows=[]
    for k,(kind_a,row_a,label_a,artist_a) in enumerate(all_labels):
        bbox_a=artist_a.get_window_extent(renderer=renderer)
        for kind_b,row_b,label_b,artist_b in all_labels[k+1:]:
            bbox_b=artist_b.get_window_extent(renderer=renderer)
            overlap_w=max(0,min(bbox_a.x1,bbox_b.x1)-max(bbox_a.x0,bbox_b.x0))
            overlap_h=max(0,min(bbox_a.y1,bbox_b.y1)-max(bbox_a.y0,bbox_b.y0))
            collision_rows.append({'kind_a':kind_a,'row_a':row_a,'label_a':label_a,'kind_b':kind_b,'row_b':row_b,'label_b':label_b,'overlap_area_px2':overlap_w*overlap_h,'collision':bool(overlap_w>0 and overlap_h>0)})
    pd.DataFrame(layout_rows).to_csv(QA/'supp5_coverage_label_layout_audit.csv',index=False)
    pd.DataFrame(collision_rows).to_csv(QA/'supp5_label_collision_audit.csv',index=False)
    save_figure(fig,'5','Unique non-zero complete-service penalty profiles',['unique_partial_service_penalty_profiles'],True)

def make_ed6():
    fig,axes=plt.subplots(1,2,figsize=(SUPP_W,3.85),constrained_layout=True,gridspec_kw={'wspace':.11})
    ax=axes[0]; panel(ax,'a')
    stable=[]
    for scenario in SCENARIOS:
        g=THRESH[THRESH.scenario==scenario].sort_values('coverage_threshold')
        if (g.no_selection_frequency.max()-g.no_selection_frequency.min())>0.02:
            ax.plot(g.coverage_threshold,g.no_selection_frequency,marker='o',ms=2.7,lw=.9,color=SCENARIO_COLOR[scenario],label=scenario_code(scenario))
        else:
            stable.append((scenario,float(g.no_selection_frequency.mean())))
    ax.set_xlabel('Required service-coverage threshold'); ax.set_ylabel('No-selection frequency'); clean(ax,'both'); top_legend(ax,ncol=3,anchor=(.5,1.13),fontsize=5.8)

    ax=axes[1]; panel(ax,'b')
    ax.plot(CVSUM.n_draws,CVSUM.median_absolute_error,marker='o',ms=3,color=NAVY,label='Median')
    ax.plot(CVSUM.n_draws,CVSUM.p95_absolute_error,marker='s',ms=3,color=BURGUNDY,label='95th percentile')
    ax.set_xscale('log'); ax.xaxis.set_major_formatter(FuncFormatter(lambda value, pos: f'{value:g}')); ax.xaxis.set_minor_formatter(NullFormatter()); ax.set_xlabel('Independent draws'); ax.set_ylabel('Absolute modal-frequency error'); clean(ax,'both'); top_legend(ax,ncol=2,anchor=(.5,1.13),fontsize=5.8)
    save_figure(fig,'6','Threshold sensitivity and independent sampling convergence',['service_coverage_threshold_sensitivity','independent_convergence_summary'],True)

def make_ed7():
    fig,axes=plt.subplots(3,1,figsize=(SUPP_W,5.55),constrained_layout=True,gridspec_kw={'hspace':.045})
    roots=[('corrosion_compatibility','Corrosion'),('cycling_phase_stability','Cycling/phase'),('containment_validation','Containment')]
    for letter,ax,(root,title) in zip('abc',axes,roots):
        panel(ax,letter)
        rows=AINTDIM[AINTDIM.dimension.eq(root)].copy().sort_values('mid').reset_index(drop=True)
        y=np.arange(len(rows)); mid=rows['mid']
        ax.errorbar(mid,y,xerr=[mid-rows['low'],rows['high']-mid],fmt='o',ms=5.0,color=NAVY,ecolor=MID_GREY,capsize=2.2)
        [value_badge(ax,float(v),i,f'{v:.2f}',dx=5,dy=0,color=NAVY) for i,v in enumerate(mid)]
        ax.set_xlim(-.03,1.15); ax.set_xlabel(title); clean(ax,'x')
        # Exact memberships remain in the source table; the figure retains only profile identity and size.
        labels=[f"{r.profile_id} · n={int(r.member_count)}" for r in rows.itertuples(index=False)]
        ax.set_yticks(y,labels); ax.tick_params(axis='y',labelsize=6.5)
    save_figure(fig,'7','Panel-specific unique analytical sensitivity intervals for atomic credibility',['atomic_interval_profiles_by_dimension'],True)

def make_ed8():
    fig,axes=plt.subplots(1,2,figsize=(SUPP_W,6.0),constrained_layout=True,gridspec_kw={'wspace':.075})
    panel(axes[0],'a')
    l=SOMDEC.copy().sort_values(['scenario','delta_top1_top2_frequency_gap'])
    offsets={
        'coal_flexibility_storage':(10,10,'left'),
        'industrial_medium_heat':(-58,12,'left'),
        'sco2_high_temperature_storage':(10,-18,'left'),
    }
    for r in l.itertuples(index=False):
        axes[0].scatter(r.delta_top1_top2_frequency_gap,r.delta_modal_leader_frequency,
                        s=44+90*min(1.0,abs(r.influence_magnitude)),
                        color=SCENARIO_COLOR[r.scenario],
                        edgecolor=INK if r.leader_changed else 'white',lw=.75,zorder=3)
        dx,dy,ha=offsets.get(r.scenario,(5,5,'left'))
        axes[0].annotate(f'{scenario_code(r.scenario)} · {short_candidate(r.omitted_label)}',
                         (r.delta_top1_top2_frequency_gap,r.delta_modal_leader_frequency),
                         xytext=(dx,dy),textcoords='offset points',fontsize=6.5,ha=ha,
                         arrowprops=dict(arrowstyle='-',color=MID_GREY,lw=.45,shrinkA=1,shrinkB=2))
    legend_scenarios=[x for x in ['coal_flexibility_storage','industrial_medium_heat','sco2_high_temperature_storage'] if x in set(l.scenario)]
    handles=[Line2D([0],[0],marker='o',ls='',color=SCENARIO_COLOR[x],label=scenario_code(x),markersize=4) for x in legend_scenarios]
    axes[0].legend(handles=handles,loc='lower right',bbox_to_anchor=(.98,.02),frameon=False,ncol=1,fontsize=6.5,borderaxespad=0)
    axes[0].axvline(0,color=INK,lw=.7); axes[0].axhline(0,color=INK,lw=.7); axes[0].margins(x=.28,y=.34)
    axes[0].set_xlabel('Δ top1–top2 rank-frequency gap'); axes[0].set_ylabel('Δ modal-leader frequency'); clean(axes[0],'both')

    panel(axes[1],'b')
    metrics=['delta_selection_entropy','delta_modal_leader_frequency','delta_top1_top2_frequency_gap','delta_mean_top_two_utility_margin']
    ls=SOGRP.copy()
    ls=ls[ls[metrics].fillna(0).abs().max(axis=1)>0.0005].copy()
    ls=ls.sort_values(['scenario','source_count'],ascending=[True,False]).reset_index(drop=True)
    ls['row_label']=[f"G{i+1} · {scenario_code(r.scenario)} · n={int(r.source_count)}" for i,r in ls.iterrows()]
    image=heatmap(axes[1],ls[metrics].fillna(0),ls.row_label,['Entropy','Leader freq.','Top1–top2','Utility margin'],cmap=LinearSegmentedColormap.from_list('source_signed',[BURGUNDY,VERY_LIGHT,OLIVE]),center=0,annotate=True,fmt='{:+.2f}'); attached_top_colorbar(fig,axes[1],image,'Change after exact source-group omission',y=1.018,height=.032)
    axes[1].tick_params(axis='y',labelsize=6.5); axes[1].tick_params(axis='x',labelsize=6.5)
    save_figure(fig,'8','Residual candidate-omission decisiveness and exact source-omission outcome groups',['supplementary_candidate_omission_decisiveness_residuals','source_omission_effect_groups'],True)

def make_ed9():
    fig=plt.figure(figsize=(SUPP_W,5.35),constrained_layout=True)
    gs=fig.add_gridspec(1,2,width_ratios=[1.02,.98],wspace=.070)
    ax=fig.add_subplot(gs[0,0]); panel(ax,'a')
    cols=['corrosion','cycling_phase','containment','literature_replication','data_completeness','inverse_burden']
    p=USPROF.copy(); labels=p.apply(lambda r:r.display_label if r.member_count==1 else f"{r.profile_id} · n={int(r.member_count)}",axis=1)
    image=heatmap(ax,p[cols],labels,['Corrosion','Cycling','Containment','Replication','Data','Burden'],cmap=LinearSegmentedColormap.from_list('shortfall',[VERY_LIGHT,CREAM,BURGUNDY]),vmin=0,vmax=1,annotate=False); attached_top_colorbar(fig,ax,image,'Share of total log-credibility shortfall',y=1.018,height=.032); ax.tick_params(axis='y',labelsize=6.5); ax.tick_params(axis='x',labelsize=6.5)

    ax=fig.add_subplot(gs[0,1]); panel(ax,'b')
    base=CREDMODEL[CREDMODEL.credibility_model.eq('hierarchical_geometric')][['scenario','no_selection_frequency','selection_entropy']].rename(columns={'no_selection_frequency':'base_no_selection','selection_entropy':'base_entropy'})
    cm=CREDMODEL[CREDMODEL.credibility_model.isin(['hierarchical_arithmetic','bottleneck_minimum'])].merge(base,on='scenario',validate='many_to_one')
    cm['abs_delta_no_selection']=(cm.no_selection_frequency-cm.base_no_selection).abs()
    cm['abs_delta_entropy']=(cm.selection_entropy-cm.base_entropy).abs()
    model_order=['hierarchical_arithmetic','bottleneck_minimum']; model_short={'hierarchical_arithmetic':'Arithmetic','bottleneck_minimum':'Bottleneck'}
    rows=[]
    for model in model_order:
        q=cm[cm.credibility_model.eq(model)]
        rows.extend([(f'{model_short[model]} · entropy',float(q.abs_delta_entropy.max()),NAVY),(f'{model_short[model]} · no selection',float(q.abs_delta_no_selection.max()),BURGUNDY)])
    y=np.arange(len(rows))[::-1]
    for yy,(label,value,color) in zip(y,rows):
        ax.hlines(yy,0,value,color=PALE_BLUE,lw=2.2)
        ax.scatter(value,yy,s=38,color=color,edgecolor='white',lw=.55,zorder=3)
        ax.annotate(f'{value:.6f}',(value,yy),xytext=(5,0),textcoords='offset points',ha='left',va='center',fontsize=6.0,fontweight='bold',color=color)
    threshold=.005
    ax.axvline(threshold,color=MID_GREY,lw=.8,ls='--')
    ax.text(threshold-.00005,3.42,'registered threshold = 0.005',ha='right',va='bottom',fontsize=6.0,color=MID_GREY)
    ax.set_yticks(y,[r[0] for r in rows]); ax.set_xlim(-.00015,.00575); ax.set_ylim(-.55,3.72); ax.tick_params(axis='y',labelsize=6.5)
    ax.set_xlabel('Maximum |change| across services'); clean(ax,'x')
    ax.text(.50,.065,f'{len(cm)} contrasts across 7 services\n0 reach the registered threshold',transform=ax.transAxes,ha='center',va='bottom',fontsize=6.2,fontweight='bold',color=OLIVE,linespacing=1.05)
    save_figure(fig,'9','Unique credibility-shortfall profiles and registered model-structure invariance',['unique_credibility_shortfall_profiles','credibility_model_sensitivity'],True)

def make_ed10():
    fig=plt.figure(figsize=(SUPP_W,6.75),constrained_layout=True)
    gs=fig.add_gridspec(2,2,height_ratios=[1.06,.94],hspace=.090,wspace=.105)
    axa=fig.add_subplot(gs[0,0]); axb=fig.add_subplot(gs[0,1]); axc=fig.add_subplot(gs[1,0]); axd=fig.add_subplot(gs[1,1])
    panel(axa,'a')
    rd=RPROF.copy()
    def compact_service_members(value):
        text=chem_label(str(value))
        return (text.replace('PCM350 + PCM425 + PCM500','PCM350/425/500')
                    .replace('Coal + CSP + Industrial','Coal/CSP/Industrial')
                    .replace('CSP + Industrial','CSP/Industrial'))
    rd['row']=rd.apply(lambda r:f"{short_candidate(r.display_system)} · {compact_service_members(r.member_labels)}",axis=1)
    cols=['corrosion_compatibility_score','cycling_phase_stability_score','containment_validation_score','literature_replication_score','data_completeness_score','inverse_burden','evidence_qualified_selection_frequency']; labs=['Corrosion','Cycling','Containment','Replication','Data','Inv. burden','Selection']
    image=heatmap(axa,rd[cols],rd.row,labs,cmap=LinearSegmentedColormap.from_list('readiness',[VERY_LIGHT,PALE_BLUE,NAVY]),vmin=0,vmax=1,annotate=False); attached_top_colorbar(fig,axa,image,'Readiness score / selection frequency',y=1.018,height=.032); axa.tick_params(axis='y',labelsize=6.5); axa.tick_params(axis='x',labelsize=6.5)

    panel(axb,'b')
    pcm=READY[READY.scenario.str.startswith('pcm_target')].copy(); mat=pcm.pivot(index='display_system',columns='scenario',values='strict_complete_service_probability').reindex(columns=['pcm_target_350C','pcm_target_425C','pcm_target_500C']).fillna(0); mat.index=[short_candidate(x) for x in mat.index]
    image=heatmap(axb,mat,mat.index,['350 °C','425 °C','500 °C'],cmap=LinearSegmentedColormap.from_list('pcm',[VERY_LIGHT,ROSE_LIGHT,BURGUNDY]),vmin=0,vmax=1,annotate=True,fmt='{:.2f}'); attached_top_colorbar(fig,axb,image,'Strict-complete probability',y=1.018,height=.032); axb.tick_params(axis='y',labelsize=6.5)

    panel(axc,'c')
    tm=MGRP.sort_values('group_order').copy(); y=np.arange(len(tm)); left=np.zeros(len(tm))
    for field,label,color in [('multiple_candidate_draw_frequency','Multiple',OLIVE),('single_candidate_draw_frequency','Single',MUSTARD),('no_candidate_draw_frequency','No candidate',BURGUNDY)]:
        vals=tm[field].fillna(0).to_numpy(); axc.barh(y,vals,left=left,height=.65,color=color,label=label); left+=vals
    axc.set_yticks(y,[compact_service_members(x) for x in tm.member_labels]); axc.set_xlim(0,1); barh_headroom(axc,len(tm),.26); axc.set_xlabel('Bounded-candidate multiplicity'); clean(axc,'x'); axc.legend(frameon=False,ncol=3,loc='lower center',bbox_to_anchor=(.50,1.018),fontsize=6.5,handlelength=.95,handletextpad=.30,columnspacing=.48,borderaxespad=0)

    panel(axd,'d')
    ar=ARCHSUM.sort_values('archetype_cluster_id'); metrics=['performance_normalized_mean','strict_complete_service_probability_mean','engineering_credibility_geometric_mean','inverse_burden_mean','robustness_mean']; m=ar[metrics].copy(); archetype_short={'High-performance evidence opportunity':'Evidence opportunity','Service-mismatched or bounded-out':'Service-mismatched','Robust deployability benchmark':'Deployability benchmark','Lower-burden service-bounded profile':'Lower-burden service-bounded'}; m.index=[f"C{int(i)} · {archetype_short.get(str(lab),str(lab))}" for i,lab in zip(ar.archetype_cluster_id,ar.archetype_label)]
    image=heatmap(axd,m,m.index,['Performance','Service','Credibility','Inv. burden','Robustness'],cmap=LinearSegmentedColormap.from_list('arch',[VERY_LIGHT,CREAM,OLIVE]),vmin=0,vmax=1,annotate=True,fmt='{:.2f}'); attached_top_colorbar(fig,axd,image,'Cluster mean',y=1.018,height=.032); axd.tick_params(axis='y',labelsize=6.5); axd.tick_params(axis='x',labelsize=6.5)
    save_figure(fig,'10','Deduplicated readiness, PCM specificity, bounded competition and exploratory archetypes',['unique_readiness_profiles','candidate_readiness_profile','bounded_multiplicity_groups','candidate_archetype_cluster_summary'],True)

def make_contact_sheet(paths: list[Path], output: Path, columns: int = 2, thumb_width: int = 1250) -> None:
    images=[]
    for path in paths:
        with Image.open(path) as _src:
            image=_src.convert("RGB")
        scale=thumb_width/image.width
        images.append(image.resize((thumb_width,int(image.height*scale)),Image.Resampling.LANCZOS))
    if not images: return
    rows=math.ceil(len(images)/columns); margin=35; label_h=45
    row_heights=[]
    for row in range(rows): row_heights.append(max(im.height for im in images[row*columns:(row+1)*columns])+label_h)
    canvas=Image.new("RGB",(columns*thumb_width+(columns+1)*margin,sum(row_heights)+(rows+1)*margin),"white")
    draw=ImageDraw.Draw(canvas)
    y=margin
    for row in range(rows):
        x=margin
        for col in range(columns):
            idx=row*columns+col
            if idx>=len(images): break
            im=images[idx]; canvas.paste(im,(x,y+label_h)); draw.text((x,y+10),paths[idx].stem,fill="#263238")
            x+=thumb_width+margin
        y+=row_heights[row]+margin
    canvas.save(output,quality=92)




def write_captions():
    captions={
      'Fig. 1':'Evidence-qualified deployability is a staged contraction rather than a database count. a, Record attrition through melting, service and coverage screens. b, Declared evidence streams linked to chemistry families. c, Candidate-level atomic evidence and scope matrix across all ten curated salts; colour encodes normalized evidence or scope, the left strip identifies chemistry family, Apps reports registered services and MSD link identifies exact raw-database formula linkage. d, Formula-group cross-validation and the formal model-output boundary; interval coverage is calibration coverage, not independent external validation, and model-estimated values remain outside bounded decisions. e, Candidate–service contraction from registration to material selection; exact duplicate service trajectories are collapsed and labelled jointly.',
      'Fig. 2':'Complete-service translation connects usable energy, thermal transport and ranking pathways. a, Service-temperature windows and candidate melting temperatures. b, Robust, uncertain and unavailable complete-service classification shares, with exact duplicate service rows collapsed. c, Candidate-level strict-complete service probability versus evidence-bounded selection frequency, with engineering credibility encoded by marker area. d, Service-temperature thermal conductivity versus conditional median usable energy density; black outlines identify candidate–service pairs selected in at least 1% of draws. e, Draw-level decomposition into stable, service-only, evidence-only, joint service-and-evidence and no-evidence-bounded-selection pathways.',
      'Fig. 3':'Evidence gating redirects choices within a fixed strict-service scope through identifiable shortfalls, route concentration and engineering trade-offs. a, Draw-matched transitions from strict-complete thermophysical leaders to strict-complete evidence-bounded outcomes. b, Composition of displaced-leader log-credibility shortfalls; services without displaced leaders are reported in text rather than plotted as all-zero rows. c, Top-route share and effective route count for services with non-zero redirection. d, Route-level storage-volume penalty versus engineering-credibility change; marker area is route frequency and edge colour indicates the direction of the conditional raw-material-cost proxy, not installed TES cost.',
      'Fig. 4':'Deployability bottlenecks differ in prevalence, co-occurrence, closure depth and substitution. a, Service-specific failure-gate prevalence. b, Highest-frequency gate intersections. c, Application-level Shapley attribution of retained-frequency restoration. d, Baseline retained frequency versus retained frequency after closing the highest-Shapley gate, together with the residual dominant bottleneck. e, Median and full subset range as increasing numbers of gates are jointly closed.',
      'Fig. 5':'Robustness is resolved without repeated all-equal heatmaps. a, Five-to-fifty-to-ninety-five percentile ranges of modal-leader frequency and top-one–top-two gap across continuous performance–credibility weights. b, SMAA rank-one acceptability with identical PCM outcomes collapsed. c, Joint coverage–evidence threshold regimes. d, Strongest non-trivial candidate or source omission for each service and omission type, all referenced to the hierarchical-geometric baseline. e, Draw-matched change in selection entropy (bits) and no-selection frequency from strict-complete thermophysical to strict-complete evidence-bounded outcomes; lower entropy is explicitly distinguished from collapse to universal no selection.',
      'Fig. 6':'Evidence actions differ in value, decision quality, burden, redistribution and programme interaction. a, All non-zero eligible action–service gains. b, Mean signed changes in four decision-quality dimensions. c, Benefit versus registered ordinal research burden for comparison-eligible evidence actions; horizontal spacing is categorical and has no cardinal interpretation, and highlighted actions are non-dominated under the full registered ordering rather than a continuous cost-efficiency frontier. d, Largest signed candidate-selection changes above the 1% materiality threshold. e, Combined evidence-programme value minus the sum of atomic actions, distinguishing complementarity, additivity and overlap.'}
    (DOCS/f'{VERSION}_MAIN_FIGURE_CAPTIONS.md').write_text('\n\n'.join(f'## {k}\n\n{v}' for k,v in captions.items()),encoding='utf-8')
    supp_captions={
      'Supplementary Fig. 1':'Database support and candidate-registry provenance. a, Formula-system composition-record density by number of components in the raw MSD-TP snapshot. b, Chemistry-family shares in the raw formula-system database and the independently curated ten-candidate registry; totals are reported separately, so the panel distinguishes corpus size from composition. Nitrate- and carbonate-containing candidates enter through the literature-curated registry rather than the raw MSD-TP formula inventory. c, Non-zero lower-bound compatibility of raw-database chloride and fluoride formula systems across the seven service definitions.',
      'Supplementary Fig. 2':'Candidate provenance context and atomic engineering credibility. a, Best component-set correspondence to the raw database, separating the single exact formula-system link from literature-anchored candidates. b, Candidate-level mean corrosion, cycling/phase, containment, literature-replication and data-completeness scores.',
      'Supplementary Fig. 3':'Unique deterministic thermophysical profiles after exact displayed-vector collapse. Numerically identical rows from different candidate–service pairs are shown once, while the combined row label retains every contributing pair; no thermophysical value or eligibility result is averaged or altered.',
      'Supplementary Fig. 4':'Pairwise energy-density superiority probabilities and conditional raw-material-cost proxy intervals from the Monte Carlo analysis.',
      'Supplementary Fig. 5':'Unique non-zero partial-service overclaim profiles.',
      'Supplementary Fig. 6':'Service-coverage threshold sensitivity and independent sampling convergence to the 20,000-draw reference.',
      'Supplementary Fig. 7':'Unique analytical uncertainty intervals for corrosion, cycling/phase and containment evidence.',
      'Supplementary Fig. 8':'Residual candidate-omission decisiveness and exact source-omission outcome groups.',
      'Supplementary Fig. 9':'Unique credibility-shortfall profiles and non-zero credibility-model sensitivity.',
      'Supplementary Fig. 10':'Unique readiness profiles, PCM target specificity, bounded-candidate multiplicity and exploratory candidate archetypes.'}
    (DOCS/f'{VERSION}_SUPPLEMENTARY_FIGURE_CAPTIONS.md').write_text('\n\n'.join(f'## {k}\n\n{v}' for k,v in supp_captions.items()),encoding='utf-8')


def _srcset(value: str) -> set[str]:
    return {x.strip() for x in str(value).split(';') if x.strip()}


TABLE_ANCESTORS = {
    'deployability_trajectory_groups': {'deployability_contraction'},
    'service_feasibility_groups': {'service_feasibility_composition'},
    'thermal_transport_frontier': {'candidate_readiness_profile','candidate_property_registry'},
    'ranking_pathway_summary': {'rank_ladder_transition_summary','rank_ladder_by_draw'},
    'figure_selection_alluvial_flows': {'strict_complete_selection_transition_matrix'},
    'redirection_route_diversity': {'strict_complete_selection_transition_matrix'},
    'redirection_tradeoff_routes': {'decision_redirection_draw_consequences'},
    'omission_influence_summary': {'leave_one_candidate_out_sensitivity','leave_one_source_out_sensitivity'},
    'supplementary_candidate_omission_rank_residuals': {'leave_one_candidate_out_sensitivity','omission_influence_summary'},
    'source_omission_effect_groups': {'leave_one_source_out_sensitivity'},
    'smaa_rank1_groups': {'smaa_rank_acceptability'},
    'atomic_interval_profiles_by_dimension': {'atomic_engineering_credibility_registry'},
    'unique_atomic_interval_profiles': {'atomic_engineering_credibility_registry'},
    'unique_thermophysical_profiles': {'candidate_readiness_profile'},
    'unique_readiness_profiles': {'candidate_readiness_profile'},
    'bounded_multiplicity_groups': {'bounded_candidate_count_summary'},
}

def _expanded_srcset(value: str) -> set[str]:
    direct=_srcset(value); expanded=set(direct)
    for item in list(direct): expanded.update(TABLE_ANCESTORS.get(item,set()))
    return expanded


def _pair_audit(frame_a: pd.DataFrame, frame_b: pd.DataFrame | None = None, cross: bool = False) -> pd.DataFrame:
    rows=[]
    if frame_b is None:
        pairs=combinations(frame_a.to_dict('records'),2)
    else:
        pairs=((a,b) for a in frame_a.to_dict('records') for b in frame_b.to_dict('records'))
    for a,b in pairs:
        same_metric=a['displayed_metric']==b['displayed_metric']
        same_construct=a['primary_construct']==b['primary_construct']
        overlap=sorted(_expanded_srcset(a['source_table'])&_expanded_srcset(b['source_table']))
        same_unit=a['root_observation_unit']==b['root_observation_unit']
        if same_metric or same_construct:
            dep='direct_duplicate'; disallowed=True
        elif overlap and same_unit and a['filter_transform']==b['filter_transform'] and a['aggregation']==b['aggregation']:
            dep='deterministic_reexpression'; disallowed=True
        elif overlap:
            dep='shared_source_independent_claim'; disallowed=False
        else:
            dep='independent_source'; disallowed=False
        rows.append({
            'panel_a':f"{a['figure']}{a['panel']}", 'panel_b':f"{b['figure']}{b['panel']}",
            'dependency_class':dep,'shared_source_tables':';'.join(overlap),
            'same_observation_unit':bool(same_unit),'same_metric':bool(same_metric),
            'same_construct':bool(same_construct),'disallowed':bool(disallowed),
            'audit_scope':'cross' if cross else 'within'})
    return pd.DataFrame(rows)


def run_qc():
    records=[]
    for record in FIGURE_RECORDS:
        passed=record['width_px']>=1800 and record['height_px']>=900 and 0.70<=record['aspect_ratio']<=4.0
        records.append({**record,'passed_dimension_qc':passed})
    q=pd.DataFrame(records); q.to_csv(QC/f'{VERSION}_FIGURE_INDEX.csv',index=False)
    main=q[~q.figure.str.startswith('Supplementary')]; supp=q[q.figure.str.startswith('Supplementary')]

    rows=[
      ('Fig. 1','a','ordered retained-record counts','database_to_shortlist_transition','database record','ordered eligibility screens','count by screen stage','database attrition','evidence foundation','show all stages'),
      ('Fig. 1','b','unique evidence-source–family links','literature_evidence_flow','declared source–candidate link','deduplicate source and candidate','weighted alluvial link flow','evidence provenance','evidence foundation','omit zero-width links'),
      ('Fig. 1','c','candidate-level atomic evidence completeness and scope','candidate_readiness_profile;candidate_scope_and_inclusion_audit','curated candidate','mean atomic evidence scores plus registered scope','heatmap across five evidence dimensions with application count and MSD-link indicators','candidate evidence completeness','evidence foundation','retain all curated candidates and explicit zero links'),
      ('Fig. 1','d','three-metric internal validation and model-output-boundary disposition','ai_model_validation;ai_candidate_applicability_audit','target-level validation metric and AI audit row','formula-group R2, random-CV R2 and conformal coverage','metric values plus categorical boundary audit','model-output trust boundary','evidence foundation','keep external validation, applicability and decision-use boundaries explicit'),
      ('Fig. 1','e','deduplicated deployability trajectories','deployability_trajectory_groups','candidate–service pair and Monte Carlo draw','exact trajectory signature collapse','stage shares by unique trajectory','deployability contraction','evidence foundation','retain endpoint zeros; collapse identical rows'),
      ('Fig. 2','a','service bands and candidate melting positions','candidate_service_coverage_map;system_benchmarks','candidate–service pair','strict service-window mapping','interval and point overlay','service compatibility','service translation','show all registered pairs'),
      ('Fig. 2','b','deduplicated complete-service composition','service_feasibility_groups','candidate–service pair','strict probability class and exact-row collapse','share by unique service profile','service feasibility composition','service translation','collapse identical service rows'),
      ('Fig. 2','c','strict-service probability versus bounded-selection frequency','candidate_readiness_profile','candidate–service pair','finite strict-service probability, bounded-selection frequency and credibility','two-axis probability frontier with credibility size','service-to-selection translation','service translation','retain true zero selection; label material selections'),
      ('Fig. 2','d','thermal conductivity–energy-density frontier','thermal_transport_frontier','candidate–service pair','finite transport and energy values','two-axis frontier','thermal transport frontier','service translation','omit missing transport values'),
      ('Fig. 2','e','draw-level ranking-pathway shares','ranking_pathway_summary','Monte Carlo draw','five mutually exclusive pathways; ≥2 pathways each ≥5%','share by informative service','ranking pathway decomposition','service translation','omit single-pathway-dominated services'),
      ('Fig. 3','a','strict-scope leader transition flow','figure_selection_alluvial_flows','draw-matched source and destination leader','fixed strict-complete scope','weighted transition flow','evidence redirection topology','evidence redirection','retain no-selection destination'),
      ('Fig. 3','b','non-zero displaced-leader shortfall shares','displaced_leader_shortfall_composition','displaced thermophysical leader','exclude services with no displaced leader','share by atomic evidence dimension','displaced-leader shortfall anatomy','evidence redirection','omit all-zero service rows and annotate'),
      ('Fig. 3','c','redirection top-route share and effective route count','redirection_route_diversity','service-specific redirected route','exclude zero-redirection services','route entropy, top share and frequency','redirection concentration','evidence redirection','omit structural zero-redirection services'),
      ('Fig. 3','d','route-level volume, credibility and raw-cost-proxy direction','redirection_tradeoff_routes','redirected route','route frequency ≥0.05%','route-level multiaxis frontier','route engineering trade-off','evidence redirection','omit negligible routes; retain signed outcomes'),
      ('Fig. 4','a','service-specific gate failure frequency','gate_multilabel_failure_breakdown','candidate–service draw','six non-compensatory gates','frequency by gate and service','gate prevalence','gate mechanism','retain meaningful zero gates'),
      ('Fig. 4','b','highest-frequency gate intersections','gate_intersection_horizontal_summary','failure pattern','non-empty intersection and ≥0.4%','horizontal frequency ranking','gate co-occurrence','gate mechanism','omit negligible intersections'),
      ('Fig. 4','c','Shapley retained-restoration contribution','gate_shapley_attribution','application-level gate subset','exact subset Shapley decomposition','conserved contribution stack','gate marginal leverage','gate mechanism','retain zero contribution as mechanism'),
      ('Fig. 4','d','retention and residual gate after top-gate closure','gate_bottleneck_transfer','service counterfactual','close highest-Shapley gate only','paired retention and residual label','bottleneck substitution','gate mechanism','retain zero recovery as diagnosis'),
      ('Fig. 4','e','service-faceted retention response by joint closure depth','gate_closure_depth_response','gate-closure subset','group by service and closed-gate count; collapse exact PCM duplicates','median line and full min-max ribbon','closure depth response','gate mechanism','show all closure depths without overlapping error bars'),
      ('Fig. 5','a','weight-space decisiveness intervals','weight_space_stability_summary','continuous weight vector','non-PCM services; exact percentile summary','5–50–95% intervals','preference decisiveness','robustness','replace repeated leader-bin heatmap'),
      ('Fig. 5','b','deduplicated SMAA rank-one acceptability','smaa_rank1_groups','random weight vector and physical draw','rank one plus no selection; exact-row collapse','share by unique service profile','SMAA acceptability','robustness','collapse identical PCM outcomes'),
      ('Fig. 5','c','joint threshold regime composition','joint_threshold_regime_summary','coverage–evidence threshold cell','PCM targets grouped as one service class','share of robust, conditional and no-access regimes','threshold robustness','robustness','retain no-access as substantive outcome'),
      ('Fig. 5','d','strongest omission effect on modal-leader stability','omission_influence_summary','candidate or source omission case','maximum influence per service and omission type; non-trivial only','signed modal-leader-frequency change with influence magnitude','omission decisiveness','robustness','omit zero and dominated omission cases'),
      ('Fig. 5','e','entropy–no-selection transition','selection_uncertainty_transition','service-level thermophysical and evidence-bounded distributions','matched before–after comparison','two-axis signed transition','uncertainty-transition guard','robustness','retain collapse-to-no-selection cases'),
      ('Fig. 6','a','non-zero action–service value gain','atomic_action_service_nonzero_scorecard','eligible action–service pair','evidence actions and non-zero response only','signed value with selection-size encoding','action service value','research action','omit structural zero rows'),
      ('Fig. 6','b','decision-quality response by action','uncertainty_reduction_value','eligible action–service pair','mean by action over four quality axes','signed heatmap','decision-quality response','research action','retain signed near-zero values'),
      ('Fig. 6','c','ordinal burden–benefit non-dominance map','research_action_nondominance_assessment','comparison-eligible research action','evidence acquisition/programme only','registered ordinal burden versus no-selection reduction','non-dominated action comparison','research action','exclude redesign and diagnostic bounds; ordinal spacing is non-metric'),
      ('Fig. 6','d','material signed candidate-selection changes','counterfactual_candidate_signed_changes','action–service–candidate','absolute change ≥1%','largest signed changes','candidate redistribution','research action','omit sub-material changes'),
      ('Fig. 6','e','programme nonadditivity','evidence_programme_nonadditivity','service-level combined versus atomic action effects','combined minus sum of atomic effects','signed interaction with class','programme interaction','research action','retain exact additive zeros as a defined class'),
    ]
    cols=['figure','panel','displayed_metric','source_table','root_observation_unit','filter_transform','aggregation','primary_construct','claim_axis','structural_zero_policy']
    lineage=pd.DataFrame(rows,columns=cols); lineage['panel_id']=lineage.figure.str.replace('Fig. ','F',regex=False)+lineage.panel; lineage['disallowed_dependency']=False
    lineage.to_csv(QA/f'{VERSION}_MAIN_PANEL_LINEAGE_REGISTRY.csv',index=False); lineage.to_csv(QA/f'{VERSION}_MAIN_FIGURE_INFORMATION_INDEPENDENCE_AUDIT.csv',index=False)

    srows=[
      ('Supplementary Fig. 1','a','formula-system record density','unique_formula_system_inventory','formula system','none','records by component count','database formula granularity','database support','retain sparse systems'),
      ('Supplementary Fig. 1','b','database-versus-curated chemistry-family composition','database_family_summary;candidate_scope_and_inclusion_audit','database family group or curated candidate','harmonized family regrouping','100% stacked family shares with total counts for raw database and curated registry','chemistry-family provenance contrast','database support','retain zero nitrate and carbonate counts in raw database'),
      ('Supplementary Fig. 1','c','non-zero family–service lower-bound compatibility','database_application_lower_bound_compatibility','formula system–service pair','omit chemistry families with all-zero compatibility','mean compatibility by family and service','database application compatibility','database support','all-zero family listed in annotation'),
      ('Supplementary Fig. 2','a','candidate provenance similarity','candidate_database_linkage_audit','candidate','best declared component match','candidate-level point range','candidate provenance context','evidence detail','retain non-exact links'),
      ('Supplementary Fig. 2','b','candidate-level atomic credibility means','atomic_engineering_credibility_registry','candidate–service evidence row','mean by candidate','five-dimension heatmap','candidate credibility profile','evidence detail','retain true low scores'),
      ('Supplementary Fig. 3','a','unique thermophysical profiles','unique_thermophysical_profiles','candidate–service deterministic profile','exact numeric profile collapse','column-normalized profile heatmap','thermophysical profile diversity','engineering detail','exact duplicates collapsed'),
      ('Supplementary Fig. 4','a','pairwise energy-superiority probability','pairwise_superiority_matrix','candidate pair within service','energy-comparable draws','selected extreme pair probabilities','pairwise performance uncertainty','engineering detail','omit non-comparable pairs'),
      ('Supplementary Fig. 4','b','conditional raw-material-cost proxy','system_value_monte_carlo_summary','adequate candidate–service draws','finite conditional cost proxy','p05–p50–p95','raw-material cost boundary','economic boundary','not installed TES cost'),
      ('Supplementary Fig. 5','a','unique partial-service penalty profiles','unique_partial_service_penalty_profiles','candidate–service penalty profile','positive penalty and exact-profile collapse','penalty by unique profile','partial-overlap overclaim','service detail','zero penalties omitted'),
      ('Supplementary Fig. 6','a','threshold-sensitive no-selection curves','service_coverage_threshold_sensitivity','service threshold sweep','varying services only','line by threshold','coverage threshold sensitivity','robustness detail','stable services annotated'),
      ('Supplementary Fig. 6','b','independent sampling convergence','independent_convergence_summary','independent draw replicate','reference against maximum draws','median and p95 absolute error','sampling convergence','robustness detail','show all draw sizes'),
      ('Supplementary Fig. 7','a','unique corrosion intervals','atomic_interval_profiles_by_dimension','candidate evidence profile','exact interval collapse','corrosion low–mid–high interval','corrosion uncertainty interval','evidence detail','duplicates collapsed'),
      ('Supplementary Fig. 7','b','unique cycling/phase intervals','atomic_interval_profiles_by_dimension','candidate evidence profile','exact interval collapse','cycling/phase low–mid–high interval','cycling uncertainty interval','evidence detail','duplicates collapsed'),
      ('Supplementary Fig. 7','c','unique containment intervals','atomic_interval_profiles_by_dimension','candidate evidence profile','exact interval collapse','containment low–mid–high interval','containment uncertainty interval','evidence detail','duplicates collapsed'),
      ('Supplementary Fig. 8','a','residual candidate-omission rank decisiveness','supplementary_candidate_omission_decisiveness_residuals','candidate omission case','Fig. 5d cases excluded; unified hierarchical-geometric baseline','rank-gap versus modal-leader-frequency scatter','secondary omission decisiveness','robustness detail','main-figure cases excluded; finite non-trivial axes required'),
      ('Supplementary Fig. 8','b','exact source-group omission outcome vectors','source_omission_effect_groups','source omission equivalence group','non-zero change in any displayed decision outcome','four-axis signed heatmap','source omission equivalence classes','robustness detail','exact outcome vectors grouped; zero-only groups omitted'),
      ('Supplementary Fig. 9','a','unique credibility-shortfall profiles','unique_credibility_shortfall_profiles','candidate–service shortfall vector','exact profile collapse','six-dimension heatmap','credibility shortfall diversity','evidence detail','duplicate profiles collapsed'),
      ('Supplementary Fig. 9','b','registered credibility-model null audit','credibility_model_sensitivity','model–service sensitivity contrast','all arithmetic and bottleneck contrasts against hierarchical geometric baseline','maximum absolute entropy and no-selection change by model','model-structure invariance','robustness detail','zeros retained as the preregistered null result'),
      ('Supplementary Fig. 10','a','unique readiness profiles','unique_readiness_profiles','candidate–service readiness vector','exact profile collapse','seven-dimension heatmap','readiness profile diversity','evidence detail','duplicates collapsed'),
      ('Supplementary Fig. 10','b','PCM target specificity','candidate_readiness_profile','PCM candidate–target pair','latent services only','strict-service probability heatmap','PCM target discrimination','service detail','retain target-specific zeros'),
      ('Supplementary Fig. 10','c','deduplicated bounded-candidate multiplicity','bounded_multiplicity_groups','service draw','exact multiplicity-profile collapse','multiple/single/none composition','bounded competition','robustness detail','identical PCM rows collapsed'),
      ('Supplementary Fig. 10','d','exploratory archetype means','candidate_archetype_cluster_summary','candidate archetype','cluster mean','five-dimension heatmap','candidate archetypes','exploratory detail','retain low cluster means'),
    ]
    supp_lineage=pd.DataFrame(srows,columns=cols); supp_lineage['panel_id']=supp_lineage.figure.str.replace('Supplementary Fig. ','S',regex=False)+supp_lineage.panel; supp_lineage['disallowed_dependency']=False
    supp_lineage.to_csv(QA/f'{VERSION}_SUPPLEMENTARY_PANEL_LINEAGE_REGISTRY.csv',index=False)

    pair_audit=_pair_audit(lineage); supp_pair=_pair_audit(supp_lineage); cross=_pair_audit(lineage,supp_lineage,cross=True)
    pair_audit.to_csv(QA/f'{VERSION}_MAIN_PANEL_PAIR_DEPENDENCY_AUDIT.csv',index=False)
    supp_pair.to_csv(QA/f'{VERSION}_SUPPLEMENTARY_PANEL_PAIR_DEPENDENCY_AUDIT.csv',index=False)
    cross.to_csv(QA/f'{VERSION}_MAIN_SUPPLEMENTARY_CROSS_DEPENDENCY_AUDIT.csv',index=False)
    allpairs=pd.concat([pair_audit.assign(scope='main-main'),supp_pair.assign(scope='supp-supp'),cross.assign(scope='main-supp')],ignore_index=True)
    allpairs.to_csv(QA/f'{VERSION}_ALL_FIGURE_PANEL_PAIR_DEPENDENCY_AUDIT.csv',index=False)

    active_smaa=[c for c in SMAAG.columns if c not in {'profile_signature','member_count','member_scenarios','member_labels','group_order'} and (float(SMAAG[c].max())>=.01 or c=='No formal selection')]
    sp=DSHORT.pivot(index='scenario',columns='credibility_dimension',values='weighted_shortfall_share').reindex(SCENARIOS).fillna(0); sp=sp.loc[sp.sum(axis=1)>EPS]
    density_rows=[]
    def add(panel_id,arr,unique_rows,decision,zero_policy):
        a=np.asarray(arr,dtype=float); density_rows.append({'panel_id':panel_id,'displayed_rows':int(a.shape[0] if a.ndim>1 else len(a)),'displayed_cells':int(a.size),'unique_displayed_rows':int(unique_rows),'duplicate_displayed_rows':int((a.shape[0] if a.ndim>1 else len(a))-unique_rows),'zero_share':float(np.isclose(a,0).mean()),'one_share':float(np.isclose(a,1).mean()),'zero_policy':zero_policy,'editorial_decision':decision})
    add('F1e',DTRAJ[['registered_share','complete_service_share','evidence_qualified_share','any_selected_share','material_selected_share']],DTRAJ.profile_signature.nunique(),'identical trajectories collapsed','contraction endpoints retained')
    add('F2b',FGRP[['robust_complete_service','uncertain_complete_service','no_complete_service']],FGRP.profile_signature.nunique(),'identical compositions collapsed','zero class share retained')
    add('F3b',sp.to_numpy(),len(sp),'all-zero services omitted and annotated','non-zero shortfall composition only')
    add('F3c',RDIV.loc[RDIV.redirected_draw_frequency>0,['top_route_share_within_redirected','effective_route_count','redirected_draw_frequency']],int((RDIV.redirected_draw_frequency>0).sum()),'zero-redirection services omitted','non-zero route services only')
    add('F5a',WSTAB[['top1_top2_gap_p05','top1_top2_gap_p50','top1_top2_gap_p95','leader_frequency_p05','leader_frequency_p50','leader_frequency_p95']],len(WSTAB),'repeated weight-bin leaders replaced by intervals','continuous summary')
    add('F5b',SMAAG[active_smaa],SMAAG.profile_signature.nunique(),'identical PCM rows collapsed','no-selection retained as outcome')
    add('F5d',OMSUM[['delta_modal_leader_frequency','influence_magnitude']],len(OMSUM),'only strongest non-trivial omissions','zero cases omitted')
    add('S3a',UPROF[['fixed_window_coverage','cp_at_service_J_gK','density_at_service_kg_m3','thermal_k_at_service_W_mK','complete_service_energy_fixed_kWh_m3']],UPROF.profile_signature.nunique(),'exact profiles collapsed','physical zeros retained')
    add('S5a',PENGRP[['fixed_window_coverage','partial_minus_complete_kWh_m3','partial_overlap_overclaim_fraction']],PENGRP.profile_signature.nunique(),'exact positive penalty profiles collapsed','zero penalties omitted')
    for dimension,panel_id in [('corrosion_compatibility','S7a'),('cycling_phase_stability','S7b'),('containment_validation','S7c')]:
        part=AINTDIM[AINTDIM.dimension.eq(dimension)]
        add(panel_id,part[['low','mid','high']],part.profile_signature.nunique(),'exact intervals collapsed within displayed panel','true low bounds retained')
    add('S8a',SOMDEC[['delta_top1_top2_frequency_gap','delta_modal_leader_frequency']],len(SOMDEC),'main-figure omission cases excluded; unified baseline','finite non-trivial decisiveness effects retained')
    add('S8b',SOGRP[['delta_no_selection','source_count']],len(SOGRP),'identical complete outcome vectors grouped','non-zero effects only')
    model_base=CREDMODEL[CREDMODEL.credibility_model.eq('hierarchical_geometric')][['scenario','no_selection_frequency','selection_entropy']].rename(columns={'no_selection_frequency':'base_no_selection','selection_entropy':'base_entropy'})
    model_contrasts=CREDMODEL[CREDMODEL.credibility_model.isin(['hierarchical_arithmetic','bottleneck_minimum'])].merge(model_base,on='scenario',validate='many_to_one')
    model_contrasts['delta_no_selection']=model_contrasts.no_selection_frequency-model_contrasts.base_no_selection
    model_contrasts['delta_entropy']=model_contrasts.selection_entropy-model_contrasts.base_entropy
    add('S9b',model_contrasts[['delta_no_selection','delta_entropy']],len(model_contrasts),'all registered model-service contrasts retained','zeros retained as the preregistered null result')
    add('S10a',RPROF[['corrosion_compatibility_score','cycling_phase_stability_score','containment_validation_score','literature_replication_score','data_completeness_score','inverse_burden','evidence_qualified_selection_frequency']],RPROF.profile_signature.nunique(),'exact readiness profiles collapsed','true zero selection retained')
    add('S10c',MGRP[['multiple_candidate_draw_frequency','single_candidate_draw_frequency','no_candidate_draw_frequency']],MGRP.profile_signature.nunique(),'identical multiplicity rows collapsed','no-candidate outcome retained')
    density=pd.DataFrame(density_rows); density['weak_panel_flag']=(density.duplicate_displayed_rows>0)|((density.zero_share>.75)&~density.zero_policy.str.contains('retained|physical|outcome'))
    density.to_csv(QA/f'{VERSION}_PANEL_ZERO_EQUAL_DENSITY_AUDIT.csv',index=False); density[density.weak_panel_flag].to_csv(QA/f'{VERSION}_WEAK_PANEL_EXCLUSION_REPORT.csv',index=False)

    numeric_tests=pd.DataFrame([
      {'test':'Fig1e unique displayed trajectories','value':int(DTRAJ.profile_signature.nunique()),'criterion':f'= {len(DTRAJ)} rows','passed':DTRAJ.profile_signature.nunique()==len(DTRAJ),'decision':'retained'},
      {'test':'Fig2b unique displayed compositions','value':int(FGRP.profile_signature.nunique()),'criterion':f'= {len(FGRP)} rows','passed':FGRP.profile_signature.nunique()==len(FGRP),'decision':'retained'},
      {'test':'Fig3b all-zero service rows','value':int((sp.sum(axis=1)<=EPS).sum()),'criterion':'= 0 displayed','passed':bool((sp.sum(axis=1)>EPS).all()),'decision':'retained'},
      {'test':'Fig3c non-zero redirection services','value':int((RDIV.redirected_draw_frequency>0).sum()),'criterion':'≥ 1 when any strict-to-bounded redirection exists','passed':bool((RDIV.redirected_draw_frequency>0).sum()>=1),'decision':'retained'},
      {'test':'Fig5a interval-summary integrity','value':int(len(WSTAB)),'criterion':'one row per non-PCM service and ordered 5th-50th-95th intervals','passed':bool(not WSTAB.scenario.duplicated().any() and (WSTAB.leader_frequency_p05<=WSTAB.leader_frequency_p50).all() and (WSTAB.leader_frequency_p50<=WSTAB.leader_frequency_p95).all() and (WSTAB.top1_top2_gap_p05<=WSTAB.top1_top2_gap_p50).all() and (WSTAB.top1_top2_gap_p50<=WSTAB.top1_top2_gap_p95).all()),'decision':'retained'},
      {'test':'Fig5b unique SMAA service profiles','value':int(SMAAG.profile_signature.nunique()),'criterion':f'= {len(SMAAG)} rows','passed':SMAAG.profile_signature.nunique()==len(SMAAG),'decision':'retained'},
      {'test':'Fig5d non-trivial omission rows','value':float(OMSUM.influence_magnitude.min()),'criterion':'> 0.005','passed':bool((OMSUM.influence_magnitude>0.005).all()),'decision':'retained'},
      {'test':'Supp3 unique thermophysical profiles','value':int(UPROF.profile_signature.nunique()),'criterion':f'= {len(UPROF)} rows','passed':UPROF.profile_signature.nunique()==len(UPROF),'decision':'retained'},
      {'test':'Supp5 unique penalty profiles','value':int(PENGRP.profile_signature.nunique()),'criterion':f'= {len(PENGRP)} rows','passed':PENGRP.profile_signature.nunique()==len(PENGRP),'decision':'retained'},
      {'test':'Supp7 panel-specific unique atomic intervals','value':int(AINTDIM.groupby('dimension').profile_signature.nunique().sum()),'criterion':f'= {len(AINTDIM)} displayed rows','passed':bool(AINTDIM.groupby('dimension').profile_signature.apply(lambda x:x.nunique()==len(x)).all()),'decision':'retained'},
      {'test':'Supp8a excludes all main Fig5d candidate omissions','value':int(len(set(zip(SOMDEC.scenario,SOMDEC.omitted_id)) & set(zip(OMSUM.loc[OMSUM.omission_type.eq('candidate'),'scenario'],OMSUM.loc[OMSUM.omission_type.eq('candidate'),'omitted_id'])))),'criterion':'= 0 overlapping omission cases','passed':not bool(set(zip(SOMDEC.scenario,SOMDEC.omitted_id)) & set(zip(OMSUM.loc[OMSUM.omission_type.eq('candidate'),'scenario'],OMSUM.loc[OMSUM.omission_type.eq('candidate'),'omitted_id']))),'decision':'retained'},
      {'test':'Supp8b grouped repeated source effects','value':int(SOGRP.source_count.max()),'criterion':'> 1 source in at least one group','passed':bool((SOGRP.source_count>1).any()),'decision':'retained'},
      {'test':'Supp9b registered credibility-model null audit','value':int(((model_contrasts.delta_no_selection.abs()>=.005)|(model_contrasts.delta_entropy.abs()>=.005)).sum()),'criterion':'0 of 14 contrasts reach the preregistered 0.005 threshold','passed':bool(len(model_contrasts)==14 and not ((model_contrasts.delta_no_selection.abs()>=.005)|(model_contrasts.delta_entropy.abs()>=.005)).any()),'decision':'retained as explicit negative result'},
      {'test':'Supp10c unique multiplicity profiles','value':int(MGRP.profile_signature.nunique()),'criterion':f'= {len(MGRP)} rows','passed':MGRP.profile_signature.nunique()==len(MGRP),'decision':'retained'},
    ])
    numeric_tests['passed']=numeric_tests.passed.astype(bool); numeric_tests.to_csv(QA/f'{VERSION}_KEY_NUMERIC_DEPENDENCE_TESTS.csv',index=False)

    width_mm=main.width_px/300*25.4
    checks=[
      {'check':'six_main_figures','passed':set(main.figure)=={f'Fig. {i}' for i in range(1,7)},'detail':main.figure.tolist()},
      {'check':'ten_supplementary_figures','passed':len(supp)==10,'detail':len(supp)},
      {'check':'all_png_pdf_pairs','passed':all((ROOT/r.png).exists() and (ROOT/r.pdf).exists() for r in q.itertuples()),'detail':'all registered pairs'},
      {'check':'dimension_qc','passed':bool(q.passed_dimension_qc.all()),'detail':q.loc[~q.passed_dimension_qc,['figure','width_px','height_px']].to_dict('records')},
      {'check':'native_main_width_180mm','passed':bool(((width_mm>=175)&(width_mm<=182)).all()),'detail':dict(zip(main.figure,width_mm.round(2)))},
      {'check':'main_panel_count_4_to_6','passed':bool(lineage.groupby('figure').size().between(4,6).all()),'detail':lineage.groupby('figure').size().to_dict()},
      {'check':'main_metrics_unique','passed':not lineage.displayed_metric.duplicated().any(),'detail':lineage[lineage.displayed_metric.duplicated(False)].displayed_metric.tolist()},
      {'check':'main_constructs_unique','passed':not lineage.primary_construct.duplicated().any(),'detail':lineage[lineage.primary_construct.duplicated(False)].primary_construct.tolist()},
      {'check':'supp_metrics_unique','passed':not supp_lineage.displayed_metric.duplicated().any(),'detail':supp_lineage[supp_lineage.displayed_metric.duplicated(False)].displayed_metric.tolist()},
      {'check':'supp_constructs_unique','passed':not supp_lineage.primary_construct.duplicated().any(),'detail':supp_lineage[supp_lineage.primary_construct.duplicated(False)].primary_construct.tolist()},
      {'check':'all_1275_pairs_audited','passed':len(allpairs)==1275,'detail':{'main':len(pair_audit),'supp':len(supp_pair),'cross':len(cross),'all':len(allpairs)}},
      {'check':'no_disallowed_pair_dependencies','passed':not allpairs.disallowed.any(),'detail':allpairs[allpairs.disallowed].to_dict('records')},
      {'check':'no_duplicate_displayed_rows_after_grouping','passed':bool((density.duplicate_displayed_rows==0).all()),'detail':density.loc[density.duplicate_displayed_rows>0].to_dict('records')},
      {'check':'no_weak_panel_flags','passed':bool(~density.weak_panel_flag.any()),'detail':density[density.weak_panel_flag].to_dict('records')},
      {'check':'all_numeric_dedup_tests_pass','passed':bool(numeric_tests.passed.all()),'detail':numeric_tests[~numeric_tests.passed].to_dict('records')},
      {'check':'strict_scope_redirection','passed':set(load('selection_transition_matrix').from_layer)=={'strict_complete_thermophysical'},'detail':sorted(load('selection_transition_matrix').from_layer.unique())},
      {'check':'formal_model_output_boundary_wording','passed':'model-output boundary' in (DOCS/f'{VERSION}_MAIN_FIGURE_CAPTIONS.md').read_text(encoding='utf-8').lower(),'detail':'explicit'},
      {'check':'research_action_boundary','passed':set(PORT.loc[PORT.comparison_eligible,'action_type']).issubset({'evidence_acquisition','evidence_programme'}),'detail':PORT.loc[PORT.comparison_eligible,['closure_action','action_type']].to_dict('records')},
      {'check':'fig4_bottleneck_non_decreasing','passed':bool((GTRANSFER.retained_frequency_after_top_gate_closure+EPS>=GTRANSFER.baseline_retained_frequency).all()),'detail':GTRANSFER[['scenario','closed_gate','residual_dominant_gate']].to_dict('records')},
      {'check':'fig5_entropy_collapse_guard','passed':bool(UTRANS.collapse_to_no_selection.any() and (UTRANS.delta_selection_entropy<0).any()),'detail':UTRANS.loc[UTRANS.collapse_to_no_selection,['scenario','delta_selection_entropy','delta_no_selection_frequency']].to_dict('records')},
      {'check':'fig5_entropy_units_bits','passed':bool('entropy_unit' in UTRANS.columns and set(UTRANS.entropy_unit)=={'bits'} and set(UTRANS.entropy_log_base)=={2}),'detail':UTRANS[['entropy_unit','entropy_log_base']].drop_duplicates().to_dict('records') if 'entropy_unit' in UTRANS.columns else 'missing'},
      {'check':'supp8a_main_omission_cases_disjoint','passed':not bool(set(zip(SOMDEC.scenario,SOMDEC.omitted_id)) & set(zip(OMSUM.loc[OMSUM.omission_type.eq('candidate'),'scenario'],OMSUM.loc[OMSUM.omission_type.eq('candidate'),'omitted_id']))),'detail':'residual-only candidate omission cases'},
      {'check':'supp8a_decisiveness_axes_finite','passed':bool(SOMDEC[['delta_top1_top2_frequency_gap','delta_modal_leader_frequency']].notna().all().all()),'detail':SOMDEC[['scenario','omitted_id','delta_top1_top2_frequency_gap','delta_modal_leader_frequency']].to_dict('records')},
      {'check':'fig6_programme_interaction_classes','passed':bool(NONADD.interaction_class.nunique()>=2),'detail':NONADD.interaction_class.value_counts().to_dict()},
    ]
    checks=[{**c,'passed':bool(c['passed'])} for c in checks]
    status='PASS' if all(c['passed'] for c in checks) else 'FAIL'
    (QC/f'{VERSION}_POSTPROCESS_QC.json').write_text(json.dumps({'status':status,'checks':checks},indent=2,ensure_ascii=False),encoding='utf-8')
    pd.DataFrame(checks).to_csv(QC/f'{VERSION}_POSTPROCESS_CHECKS.csv',index=False)
    if status!='PASS': raise RuntimeError('postprocess QC failed')


def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda:f.read(1<<20),b""):
            h.update(block)
    return h.hexdigest()


def write_manifest():
    path=ROOT/"PACKAGE_MANIFEST_SHA256.csv"; rows=[]
    for f in sorted(ROOT.rglob("*")):
        if f.is_file() and f!=path and "__pycache__" not in f.parts and f.suffix!=".pyc":
            rows.append({"relative_path":str(f.relative_to(ROOT)),"size_bytes":f.stat().st_size,"sha256":sha256(f)})
    pd.DataFrame(rows).to_csv(path,index=False)


def rebuild_figure_records() -> None:
    FIGURE_RECORDS.clear()
    source_map={
        '1':'database_to_shortlist_transition;literature_evidence_flow;candidate_readiness_profile;candidate_scope_and_inclusion_audit;ai_model_validation;ai_candidate_applicability_audit;deployability_trajectory_groups',
        '2':'candidate_service_coverage_map;service_feasibility_groups;candidate_readiness_profile;thermal_transport_frontier;ranking_pathway_summary',
        '3':'figure_selection_alluvial_flows;displaced_leader_shortfall_composition;redirection_route_diversity;redirection_tradeoff_routes',
        '4':'gate_multilabel_failure_breakdown;gate_intersection_horizontal_summary;gate_shapley_attribution;gate_bottleneck_transfer;gate_closure_depth_response',
        '5':'weight_space_stability_summary;smaa_rank1_groups;joint_threshold_regime_summary;omission_influence_summary;selection_uncertainty_transition',
        '6':'atomic_action_service_nonzero_scorecard;uncertainty_reduction_value;research_action_nondominance_assessment;counterfactual_candidate_signed_changes;evidence_programme_nonadditivity',
    }
    for i in range(1,7):
        png=MAIN/f'{VERSION}_Fig{i}.png'; pdf=MAIN/f'{VERSION}_Fig{i}.pdf'
        with Image.open(png) as _im:
            width,height=_im.size
        FIGURE_RECORDS.append({'figure':f'Fig. {i}','title':f'core main figure {i}','png':str(png.relative_to(ROOT)),'pdf':str(pdf.relative_to(ROOT)),'width_px':width,'height_px':height,'aspect_ratio':width/height,'source_tables':source_map[str(i)]})
    for i in range(1,11):
        png=SUPP/f'{VERSION}_Supp_Fig{i}.png'; pdf=SUPP/f'{VERSION}_Supp_Fig{i}.pdf'
        with Image.open(png) as _im:
            width,height=_im.size
        FIGURE_RECORDS.append({'figure':f'Supplementary Fig. {i}','title':f'core supplementary figure {i}','png':str(png.relative_to(ROOT)),'pdf':str(pdf.relative_to(ROOT)),'width_px':width,'height_px':height,'aspect_ratio':width/height,'source_tables':'supplementary support tables'})


def write_label_and_callout_audit() -> None:
    label_audit = pd.DataFrame([
        {'figure':'Fig. 1','panel':'a–e','status':'PASS','audit':'Panel c obsolete violin/boxplot legend removed; family-strip legend and normalized evidence/scope colour scale match the replacement matrix.'},
        {'figure':'Fig. 2','panel':'a–e','status':'PASS','audit':'Melting temperature written in words; service probability, conditional median and draw-level shares stated explicitly.'},
        {'figure':'Fig. 3','panel':'c–d','status':'PASS','audit':'Panel c leaders occupy local whitespace; panel d places the CSP–QNCC-to-Solar-Salt label to the right with a longer leader and retains a separate down-right Industrial leader, with no callout collision.'},
        {'figure':'Fig. 4','panel':'a–e','status':'PASS','audit':'Axes and caption identify observed frequency, gate intersections, Shapley restoration, top-gate transfer and joint closure depth in the correct panel order.'},
        {'figure':'Fig. 5','panel':'b,d,e','status':'PASS','audit':'Panel a legend moved into the lower-left in-axis whitespace; panel b remains widened and panels d–e retain separated legends.'},
        {'figure':'Fig. 6','panel':'a–e','status':'PASS','audit':'Value, model selection frequency, burden, frequency change and programme nonadditivity roles stated explicitly.'},
    ])
    label_audit.to_csv(QC/f'{VERSION}_MAIN_FIGURE_LABEL_AND_CALLOUT_AUDIT.csv',index=False)


def render_key(key: str) -> None:
    mapping={**{f'fig{i}':globals()[f'make_fig{i}'] for i in range(1,7)},**{f'supp{i}':globals()[f'make_ed{i}'] for i in range(1,11)}}
    if key not in mapping:
        raise KeyError(key)
    mapping[key]()


def write_font_math_audit() -> dict:
    math_font = font_manager.findfont("STIXGeneral", fallback_to_default=False)
    font_audit = {
        "status": "PASS",
        "text_font": FONT,
        "text_font_policy": "Arial required for the Windows publication render; declared sans-serif fallback allowed only for non-Windows reproducibility testing.",
        "mathtext_fontset": "stixsans",
        "math_font_resolved": math_font,
        "policy": "Arial (or declared sans-serif fallback) for prose; STIX Sans mathtext for chemical subscripts, superscripts and mathematical units.",
        "samples": [chem_label("sCO2"), chem_label("MgCl2-KCl-NaCl"), r"kWh m$^{-3}$", r"USD kWh$_{th}^{-1}$"],
    }
    (QC / f"{VERSION}_FONT_MATH_AUDIT.json").write_text(json.dumps(font_audit, indent=2, ensure_ascii=False), encoding="utf-8")
    return font_audit


def main() -> None:
    raise SystemExit(
        "certified_figure_support.py is an import-only support module. "
        "Run RUN_POSTPROCESS.bat (Windows) or RUN_POSTPROCESS.sh (Linux/macOS)."
    )


if __name__ == "__main__":
    main()
