from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def copy_tree(source: Path, destination: Path) -> None:
    if not source.exists():
        raise FileNotFoundError(source)
    if destination.exists():
        shutil.rmtree(destination)
    shutil.copytree(source, destination)


def main() -> None:
    parser = argparse.ArgumentParser(description="Synchronize the registered upstream release identically on all operating systems")
    parser.add_argument("upstream_root", nargs="?", default="../upstream_reproducible_code")
    args = parser.parse_args()
    upstream = Path(args.upstream_root).resolve()

    status_path = upstream / "outputs" / "qc" / "UPSTREAM_RELEASE_STATUS.json"
    expanded_path = upstream / "outputs" / "qc" / "expanded_v3_independent_validation.json"
    if not status_path.exists() or not expanded_path.exists():
        raise SystemExit("Upstream full-run status files are missing. Run the upstream full workflow first.")
    status = json.loads(status_path.read_text(encoding="utf-8"))
    expanded = json.loads(expanded_path.read_text(encoding="utf-8"))
    if status.get("status") != "PASS" or status.get("mc_iterations") != 20_000:
        raise SystemExit(f"Upstream release is not a registered 20,000-draw PASS: {status}")
    if expanded.get("validation_pass") is not True or expanded.get("monte_carlo_iterations") != 20_000:
        raise SystemExit(f"Expanded-library release is not a registered 20,000-draw PASS: {expanded}")

    copy_tree(upstream / "outputs" / "tables", ROOT / "outputs" / "tables")
    copy_tree(upstream / "outputs" / "qc", ROOT / "outputs" / "upstream_qc")
    copy_tree(upstream / "data" / "input", ROOT / "data" / "input")
    copy_tree(upstream / "data" / "provenance", ROOT / "data" / "provenance")

    source_registry = upstream / "data" / "expanded_library_v3" / "expanded_library_v3_source_registry.csv"
    registry_dest = ROOT / "data" / "provenance" / "expanded_library_v3_source_registry.csv"
    registry_dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source_registry, registry_dest)

    rows = []
    for base_name, base in [
        ("tables", ROOT / "outputs" / "tables"),
        ("upstream_qc", ROOT / "outputs" / "upstream_qc"),
        ("input", ROOT / "data" / "input"),
        ("provenance", ROOT / "data" / "provenance"),
    ]:
        for path in sorted(base.rglob("*")):
            if path.is_file():
                rows.append({
                    "collection": base_name,
                    "relative_path": path.relative_to(ROOT).as_posix(),
                    "size_bytes": path.stat().st_size,
                    "sha256": sha256(path),
                })
    pd.DataFrame(rows).to_csv(ROOT / "outputs" / "UPSTREAM_SYNC_MANIFEST_SHA256.csv", index=False, encoding="utf-8-sig")
    sync_status = {
        "status": "PASS",
        "release_id": status.get("release_id"),
        "upstream_mc_iterations": status.get("mc_iterations"),
        "expanded_mc_iterations": expanded.get("monte_carlo_iterations"),
        "files_synchronized": len(rows),
        "policy": "Windows, Linux and macOS wrappers invoke this same Python synchronization implementation.",
    }
    (ROOT / "outputs" / "UPSTREAM_SYNC_STATUS.json").write_text(json.dumps(sync_status, indent=2), encoding="utf-8")
    print(json.dumps(sync_status, indent=2))


if __name__ == "__main__":
    main()
