from __future__ import annotations
from pathlib import Path
import json, os, platform, sys
from importlib.metadata import version, PackageNotFoundError
from matplotlib import font_manager
from release_paths import ENVIRONMENT_STATUS, POSTPROCESS_ENVIRONMENT_STATUS

ROOT = Path(__file__).resolve().parents[1]
QC = ROOT / "outputs" / "qc"
QC.mkdir(parents=True, exist_ok=True)
REQUIRED = {
    "numpy": "2.3.5",
    "pandas": "2.2.3",
    "matplotlib": "3.10.8",
    "Pillow": "12.3.0",
    "PyMuPDF": "1.26.7",
}
versions, errors, warnings = {}, [], []
for package, expected in REQUIRED.items():
    try:
        actual = version(package)
    except PackageNotFoundError:
        actual = "NOT INSTALLED"
    versions[package] = actual
    if actual != expected:
        message = f"{package}: expected {expected}, found {actual}"
        if os.environ.get("ALLOW_VERSION_MISMATCH", "0") == "1":
            warnings.append(message)
        else:
            errors.append(message)
try:
    font_manager.findfont("Arial", fallback_to_default=False)
    arial_available = True
except Exception:
    arial_available = False
    if os.environ.get("ALLOW_ARIAL_FALLBACK", "0") != "1":
        errors.append("Arial is required for the submission figures but was not found. Install Arial as a system font; the package does not distribute font files.")
try:
    font_manager.findfont("STIXGeneral", fallback_to_default=False)
    stix_available = True
except Exception:
    stix_available = False
    errors.append("STIXGeneral is required as the mathtext fallback for subscripts and superscripts")
if sys.version_info[:2] != (3, 12) and os.environ.get("ALLOW_UNSUPPORTED_PYTHON", "0") != "1":
    errors.append(f"CPython 3.12 required, found {platform.python_version()}")
out = {
    "status": "PASS" if not errors else "FAIL",
    "python": platform.python_version(),
    "platform": platform.platform(),
    "packages": versions,
    "font": {
        "text": "Arial",
        "arial_available": arial_available,
        "font_location_disclosed": False,
        "mathtext_fallback": "STIX Sans",
        "stix_available": stix_available,
    },
    "errors": errors,
    "warnings": warnings,
    "policy": "Exact Python/package versions and a real Arial font hit are required for submission rendering. ALLOW_ARIAL_FALLBACK=1, ALLOW_UNSUPPORTED_PYTHON=1 and ALLOW_VERSION_MISMATCH=1 are for non-release smoke tests only.",
}
payload = json.dumps(out, indent=2)
(QC / ENVIRONMENT_STATUS).write_text(payload, encoding="utf-8")
(QC / POSTPROCESS_ENVIRONMENT_STATUS).write_text(payload, encoding="utf-8")
print(json.dumps(out, indent=2))
if errors:
    sys.exit(2)
