from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd

from release_paths import UPSTREAM_RELEASE_STATUS, UPSTREAM_RELEASE_STATUS_COMPAT, first_existing

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
UQC = ROOT / "outputs" / "upstream_qc"
QC = ROOT / "outputs" / "qc"
QC.mkdir(parents=True, exist_ok=True)
V = "submission"
RELEASE_ID = "TES-PUB-V10.1.0-MANUSCRIPT-AUDITED-20260816"

required = [
    "core_candidate_readiness_profile.csv",
    "core_joint_threshold_regime_map.csv",
    "core_candidate_service_coverage_map.csv",
    "statistical_decision_scope_matrix.csv",
    "statistical_pareto_joint_uncertainty_and_robustness.csv",
    "statistical_continuous_decision_variance_attribution.csv",
    "statistical_categorical_selection_information_attribution.csv",
    "statistical_dag_constrained_minimal_action_sets.csv",
    "submission_service_regime_archetype_summary.csv",
    "submission_pareto_dominance_mechanism_summary.csv",
    "submission_property_domain_contraction_summary.csv",
    "submission_atomic_evidence_unlock_summary.csv",
    "submission_nonzero_gate_interaction_summary.csv",
    "submission_research_action_frontier_summary.csv",
    "submission_candidate_research_priority_summary.csv",
    "core_selection_frequency_numerical_uncertainty.csv",
    "expanded_v3_candidate_service_screen.csv",
    "expanded_v3_evidence_attrition.csv",
    "expanded_v3_cross_layer_storyline.csv",
    "expanded_v3_thermophysical_opportunity_mc.csv",
    "expanded_v3_domain_validated_thermophysical_mc.csv",
    "expanded_v3_new_candidate_entry_audit.csv",
]
rows = [{"file": name, "exists": (TABLES / name).exists()} for name in required]
frame = pd.DataFrame(rows)
frame.to_csv(QC / f"{V}_UPSTREAM_CONTRACT.csv", index=False)

stat_path = first_existing(UQC, UPSTREAM_RELEASE_STATUS, UPSTREAM_RELEASE_STATUS_COMPAT)
stat = json.loads(stat_path.read_text(encoding="utf-8")) if stat_path else {}
expanded_path = UQC / "expanded_v3_independent_validation.json"
expanded = json.loads(expanded_path.read_text(encoding="utf-8")) if expanded_path.exists() else {}
sync_path = ROOT / "outputs" / "UPSTREAM_SYNC_STATUS.json"
sync = json.loads(sync_path.read_text(encoding="utf-8")) if sync_path.exists() else {}

mc_values: list[int] = []
mc_path = TABLES / "core_system_value_monte_carlo_summary.csv"
if mc_path.exists():
    mc_values = sorted(set(pd.to_numeric(pd.read_csv(mc_path, usecols=["mc_iterations"])["mc_iterations"], errors="coerce").dropna().astype(int)))
expanded_values: dict[str, list[int]] = {}
for name in ["expanded_v3_thermophysical_opportunity_mc.csv", "expanded_v3_domain_validated_thermophysical_mc.csv"]:
    path = TABLES / name
    values: list[int] = []
    if path.exists():
        values = sorted(set(pd.to_numeric(pd.read_csv(path, usecols=["iterations"])["iterations"], errors="coerce").dropna().astype(int)))
    expanded_values[name] = values

registry_path = ROOT / "data" / "input" / "core_candidate_property_registry.csv"
registry_summary_path = TABLES / "core_curated_candidate_registry_summary.csv"
input_candidate_count = int(pd.read_csv(registry_path, usecols=["system_id"])["system_id"].dropna().astype(str).nunique()) if registry_path.exists() else 0
output_candidate_count = -1
if registry_summary_path.exists():
    summary = pd.read_csv(registry_summary_path, usecols=["curated_candidate_count"])
    if not summary.empty:
        output_candidate_count = int(pd.to_numeric(summary["curated_candidate_count"], errors="coerce").iloc[0])

screen_ok = False
screen_path = TABLES / "expanded_v3_candidate_service_screen.csv"
if screen_path.exists():
    screen = pd.read_csv(screen_path)
    def _as_bool(series):
        return series.map(lambda value: value if isinstance(value, bool) else str(value).strip().lower() in {'true','1','yes','y'})
    screen_ok = bool(
        "formal_new_entrant" not in screen.columns
        and _as_bool(screen["formal_assessment_completed"]).equals(_as_bool(screen["engineering_registry_linked"]))
        and bool(screen["formal_assessment_scope"].astype(str).eq("frozen_15_candidate_engineering_registry_only").all())
    )

checks = {
    "required_tables_present": bool(frame["exists"].all()),
    "upstream_release_pass": stat.get("status") == "PASS",
    "release_id_current": stat.get("release_id") == RELEASE_ID,
    "frozen_core_unchanged": stat.get("science_changed") is False,
    "registered_core_draw_count": mc_values == [20_000],
    "expanded_validation_pass": expanded.get("validation_pass") is True,
    "expanded_registered_draw_count": expanded.get("monte_carlo_iterations") == 20_000 and all(v == [20_000] for v in expanded_values.values()),
    "candidate_count_consistent": input_candidate_count > 0 and input_candidate_count == output_candidate_count,
    "expanded_scope_semantics_valid": screen_ok,
    "cross_platform_sync_status_pass": sync.get("status") == "PASS" and sync.get("release_id") == RELEASE_ID,
}
status = "PASS" if all(checks.values()) else "FAIL"
out = {
    "version": V,
    "status": status,
    "release_id": RELEASE_ID,
    "required_tables": len(frame),
    "tables_present": int(frame["exists"].sum()),
    "upstream_status_file": stat_path.name if stat_path else "MISSING",
    "mc_iterations_found": mc_values,
    "expanded_mc_iterations_found": expanded_values,
    "input_candidate_count": input_candidate_count,
    "output_candidate_count": output_candidate_count,
    "checks": checks,
}
(QC / f"{V}_UPSTREAM_CONTRACT_STATUS.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
print(json.dumps(out, indent=2))
if status != "PASS":
    sys.exit(2)
