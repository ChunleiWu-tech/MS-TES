from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
QC = ROOT / "outputs" / "qc"
RELEASE_ID = "TES-PUB-V10.1.0-MANUSCRIPT-AUDITED-20260816"
STAGES = [
    "clean_generated_outputs.py",
    "check_env.py",
    "check_upstream_contract.py",
    "run_postprocess.py",
    "validate_postprocess.py",
    "validate_release_contract.py",
    "write_package_manifest.py",
]


def main() -> None:
    parser = argparse.ArgumentParser(description="Canonical OS-independent post-processing workflow")
    parser.add_argument("--upstream-root", default="../upstream_reproducible_code")
    parser.add_argument("--no-sync", action="store_true")
    args = parser.parse_args()

    env = os.environ.copy()
    env.setdefault("PYTHONFAULTHANDLER", "1")
    env.setdefault("PYTHONUNBUFFERED", "1")
    for key in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"]:
        env[key] = "1"

    if not args.no_sync:
        sync = subprocess.run([sys.executable, "-X", "faulthandler", "-u", str(SRC / "sync_upstream.py"), args.upstream_root], cwd=ROOT, env=env)
        if sync.returncode != 0:
            raise SystemExit(sync.returncode)

    started = time.time()
    records = []
    for index, stage in enumerate(STAGES, 1):
        print(f"\n=== [{index:02d}/{len(STAGES):02d}] {stage} ===", flush=True)
        t0 = time.time()
        result = subprocess.run([sys.executable, "-X", "faulthandler", "-u", str(SRC / stage)], cwd=ROOT, env=env)
        records.append({"index": index, "stage": stage, "returncode": result.returncode, "elapsed_s": round(time.time() - t0, 6)})
        if result.returncode != 0:
            QC.mkdir(parents=True, exist_ok=True)
            payload = {"status": "FAIL", "release_id": RELEASE_ID, "failed_stage": stage, "stages": records}
            (QC / "pipeline_execution_status.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
            raise SystemExit(result.returncode)
    payload = {"status": "PASS", "release_id": RELEASE_ID, "failed_stage": None, "elapsed_s": round(time.time() - started, 6), "stages": records}
    (QC / "pipeline_execution_status.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
