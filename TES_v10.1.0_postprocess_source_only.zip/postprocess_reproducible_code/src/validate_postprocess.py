from __future__ import annotations

from pathlib import Path
import hashlib
import json
import os
import re
import sys

import numpy as np
import pandas as pd
from PIL import Image

try:
    import fitz  # PyMuPDF
except Exception:
    fitz = None


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
QC = OUT / "qc"
QA = OUT / "qa"
TABLES = OUT / "tables"
VERSION = "submission"
STATISTICAL_VERSION = "statistical"

QC.mkdir(parents=True, exist_ok=True)

checks: list[tuple[str, bool]] = []


def add_check(name: str, passed: object) -> None:
    """Append one release-gate check as an explicit Python bool."""
    checks.append((name, bool(passed)))


def read_csv_or_empty(path: Path, required_columns: tuple[str, ...] = ()) -> pd.DataFrame:
    """Read a CSV safely; return an empty typed frame when absent or invalid."""
    if not path.is_file():
        return pd.DataFrame(columns=list(required_columns))
    try:
        frame = pd.read_csv(path)
    except Exception:
        return pd.DataFrame(columns=list(required_columns))
    for column in required_columns:
        if column not in frame.columns:
            frame[column] = pd.Series(dtype="object")
    return frame


def figure_number(value: object, prefix: str) -> int:
    """Extract a numeric figure identifier from values such as Fig5 or Supp_Fig11."""
    text = str(value)
    text = text.replace(prefix, "", 1)
    return int(text)


def expected_figure_paths(row: object) -> tuple[Path, Path]:
    figure_type = str(row.figure_type)
    if figure_type == "main":
        folder = OUT / "main_figures"
        prefix = "Fig"
    elif figure_type == "supplementary":
        folder = OUT / "supplementary_figures"
        prefix = "Supp_Fig"
    else:
        raise ValueError(f"Unknown figure_type: {figure_type}")
    number = figure_number(row.figure, prefix)
    stem = f"{VERSION}_{prefix}{number}"
    return folder / f"{stem}.png", folder / f"{stem}.pdf"


def source_tables_for(source: pd.DataFrame, figure: str) -> str:
    if not {"figure", "source_tables"}.issubset(source.columns):
        return ""
    rows = source.loc[source["figure"].astype(str).eq(figure), "source_tables"]
    if rows.empty:
        return ""
    return ";".join(rows.fillna("").astype(str).tolist())


def contains_source(source: pd.DataFrame, figure: str, pattern: str) -> bool:
    return bool(re.search(pattern, source_tables_for(source, figure)))


def project_owned_files(root: Path):
    """
    Yield only project-owned files while pruning environments, caches and
    third-party dependencies before descent.

    Matplotlib legitimately installs files such as
    ``seaborn-v0_8-*.mplstyle`` under ``.venv/Lib/site-packages``. Those are
    dependency files, not generated or historical project artefacts.
    """
    ignored_directory_names = {
        ".venv",
        "venv",
        "env",
        "site-packages",
        "__pycache__",
        ".git",
        ".github",
        ".vscode",
        ".idea",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
    }

    for directory, subdirectories, filenames in os.walk(root, topdown=True):
        subdirectories[:] = [
            name
            for name in subdirectories
            if name.lower() not in ignored_directory_names
        ]
        base = Path(directory)
        for filename in filenames:
            yield base / filename


# ---------------------------------------------------------------------------
# Figure inventory, raster integrity and PDF/font audit
# ---------------------------------------------------------------------------
index_path = QC / "figure_index.csv"
index = read_csv_or_empty(
    index_path,
    required_columns=(
        "figure",
        "figure_type",
        "png_exists",
        "pdf_exists",
        "width_px",
    ),
)

valid_inventory = (
    len(index) == 18
    and index["figure"].astype(str).nunique() == 18
    and int(index["figure_type"].astype(str).eq("main").sum()) == 6
    and int(index["figure_type"].astype(str).eq("supplementary").sum()) == 12
)
add_check("Six main and twelve supplementary figures indexed", valid_inventory)

if len(index):
    png_flags = index["png_exists"].fillna(False).astype(bool)
    pdf_flags = index["pdf_exists"].fillna(False).astype(bool)
    files_declared = bool(png_flags.all() and pdf_flags.all())
    width_values = pd.to_numeric(index["width_px"], errors="coerce")
    exact_width = bool(width_values.notna().all() and width_values.eq(2126).all())
else:
    files_declared = False
    exact_width = False

add_check("All PNG and PDF figure files exist", files_declared)
add_check("All figures use exact 2126-pixel 180-mm width at 300 dpi", exact_width)

png_ok = bool(valid_inventory)
pdf_ok = bool(valid_inventory and fitz is not None)
pdf_font_rows: list[dict[str, object]] = []
strict_arial = os.environ.get("ALLOW_ARIAL_FALLBACK", "0") != "1"

if valid_inventory:
    for row in index.itertuples(index=False):
        try:
            png_path, pdf_path = expected_figure_paths(row)
        except Exception:
            png_ok = False
            pdf_ok = False
            continue

        try:
            with Image.open(png_path) as image:
                image.verify()
        except Exception:
            png_ok = False

        names: list[str] = []
        if fitz is None:
            pdf_ok = False
        else:
            try:
                document = fitz.open(pdf_path)
                if len(document) < 1:
                    pdf_ok = False
                for page in document:
                    names.extend(str(item[3]) for item in page.get_fonts(full=True))
                document.close()
            except Exception:
                pdf_ok = False

        unique_names = sorted(set(names))
        pdf_font_rows.append(
            {
                "figure": str(row.figure),
                "fonts": ";".join(unique_names),
                "arial_present": any("Arial" in name for name in unique_names),
                "forbidden_fallback_present": any(
                    token in name
                    for name in unique_names
                    for token in ("DejaVu", "Liberation", "Arimo")
                ),
            }
        )

add_check("All PNG files pass image-integrity validation", png_ok)
add_check("All PDFs open and contain at least one page", pdf_ok)

font_columns = [
    "figure",
    "fonts",
    "arial_present",
    "forbidden_fallback_present",
]
font_audit = pd.DataFrame(pdf_font_rows, columns=font_columns)
font_audit.to_csv(QC / "pdf_font_audit.csv", index=False)

if strict_arial:
    font_ok = (
        len(font_audit) == len(index) == 18
        and bool(font_audit["arial_present"].fillna(False).all())
        and bool((~font_audit["forbidden_fallback_present"].fillna(True)).all())
    )
else:
    # CI smoke tests may permit fallback, but every PDF must still be audited.
    font_ok = len(font_audit) == len(index) == 18
add_check("Submission PDFs embed Arial and no silent fallback font", font_ok)


# ---------------------------------------------------------------------------
# Scientific/visual release gates and source-map non-duplication checks
# ---------------------------------------------------------------------------
release_gate = read_csv_or_empty(QA / "release_gate.csv", ("passed",))
release_gate_pass = (
    len(release_gate) > 0
    and bool(release_gate["passed"].fillna(False).astype(bool).all())
)
add_check("Scientific and visual release gate passes", release_gate_pass)

source = read_csv_or_empty(
    QA / "figure_source_map.csv", ("figure", "source_tables")
)
source_map_complete = (
    len(source) == 18
    and source["figure"].astype(str).nunique() == 18
    and not source["source_tables"].fillna("").astype(str).str.strip().eq("").any()
)
add_check("Every rendered figure has one current source-map entry", source_map_complete)

stage_source = read_csv_or_empty(
    TABLES / "core_database_to_shortlist_transition.csv",
    ("screen_step", "retained_count"),
)
registered_steps = [
    "Raw MSD-TP composition records",
    "Melting temperature available",
    "Application-specific melting/phase lower-bound compatibility",
    "Minimum thermophysical coverage (melting + at least two fields)",
]
registered_counts = []
for step in registered_steps:
    matched = stage_source.loc[stage_source["screen_step"].astype(str).eq(step), "retained_count"]
    registered_counts.append(int(pd.to_numeric(matched, errors="coerce").iloc[0]) if len(matched) == 1 else None)
attrition = read_csv_or_empty(
    TABLES / "expanded_v3_evidence_attrition.csv", ("stage", "count")
)
attrition_stages = [
    "Exact-composition candidates after canonical deduplication",
    "Candidate-service pairs across seven frozen duties",
    "Physical-window-compatible pairs",
    "Quantitative thermophysical pairs",
    "Service-domain-supported thermophysical pairs",
    "Service-domain-supported pairs linked to frozen engineering registry",
]
attrition_counts = []
for stage in attrition_stages:
    matched = attrition.loc[attrition["stage"].astype(str).eq(stage), "count"]
    attrition_counts.append(int(pd.to_numeric(matched, errors="coerce").iloc[0]) if len(matched) == 1 else None)
add_check(
    "Fig. 1 preserves official and expanded full-library count logic",
    registered_counts == [976, 937, 250, 74]
    and attrition_counts == [142, 994, 76, 18, 11, 8],
)

fig1e = read_csv_or_empty(
    QA / "fig1e_conditional_retention_audit.csv",
    ("gate", "numerator", "preceding_denominator", "conditional_retention"),
)
expected_retention = np.array([76 / 994, 18 / 76, 11 / 18, 8 / 11])
add_check(
    "Fig. 1e reports gate-specific conditional retention rather than a second count funnel",
    len(fig1e) == 4
    and np.allclose(pd.to_numeric(fig1e["conditional_retention"], errors="coerce"), expected_retention),
)

fig2b = read_csv_or_empty(
    QA / "fig2b_rank_reversal_audit.csv",
    ("service_id", "all_scalar_thermophysical_leader", "domain_validated_thermophysical_leader", "formal_display", "scalar_domain_changed", "domain_formal_changed"),
)
fig2b_changed = fig2b["scalar_domain_changed"].astype(str).str.lower().eq("true") if len(fig2b) else pd.Series(dtype=bool)
add_check(
    "Fig. 2b audits complete seven-service layer trajectories without duplicating frequency distributions",
    len(fig2b) == 7
    and fig2b["service_id"].nunique() == 7
    and int(fig2b_changed.sum()) == 3
    and int(fig2b["formal_display"].astype(str).eq("No selection").sum()) == 4,
)

active_path = ROOT / "src" / "run_postprocess.py"
active = active_path.read_text(encoding="utf-8") if active_path.is_file() else ""
add_check(
    "Main-figure chemical labels register subscripts and avoid formula truncation",
    all(token in active for token in ["NaNO$_3$", "Ca(NO$_3$)$_2$", "MgCl$_2$", "CaCl$_2$", "sCO$_2$"])
    and "q['label']=[f'{compact_service_label(s)} · {textwrap.shorten" not in active,
)
add_check(
    "Single active renderer is present",
    active_path.is_file() and "import run_postprocess_" not in active,
)
add_check(
    "Categorical and continuous attribution remain explicitly separated",
    "categorical state" in active and "continuous margin" in active,
)
add_check(
    "Main Fig. 5 uses service-specific closure depth",
    contains_source(source, "Fig5", r"gate_closure_depth_response"),
)
add_check(
    "Supplementary Fig. 11 does not redraw main closure-depth response",
    not contains_source(source, "Supp_Fig11", r"gate_closure_depth_response"),
)
add_check(
    "Main Fig. 6 contains complete minimum action sets and candidate redistribution",
    contains_source(source, "Fig6", r"dag_constrained_minimal_action_sets")
    and contains_source(source, "Fig6", r"counterfactual_candidate_signed_changes"),
)
add_check(
    "Supplementary Fig. 11 does not repeat minimum-set or redistribution panels",
    not contains_source(
        source,
        "Supp_Fig11",
        r"dag_constrained_minimal_action_sets|counterfactual_candidate_signed_changes",
    ),
)
add_check(
    "Fig. 3 and Supplementary Fig. 6 answer distinct threshold questions",
    bool(
        source_tables_for(source, "Fig3")
        and source_tables_for(source, "Supp_Fig6")
        and source_tables_for(source, "Fig3")
        != source_tables_for(source, "Supp_Fig6")
    ),
)


# ---------------------------------------------------------------------------
# Typography, active renderer and known figure-regression checks
# ---------------------------------------------------------------------------
add_check(
    "Chemical and unit typography uses mathtext conversion",
    "scenario_code(s)" in active and "kWh m$^{-3}$" in active,
)
add_check(
    "Arial is the required ordinary-text font",
    "'font.family':_TEXT_FONT" in active and "findfont('Arial'" in active,
)

support_path = ROOT / "src" / "certified_figure_support.py"
support = support_path.read_text(encoding="utf-8") if support_path.is_file() else ""
add_check(
    "Certified support preserves the same strict Arial mathtext policy",
    "FONT = _TEXT_FONT" in support
    and '"mathtext.fontset": "custom"' in support
    and "def resolve_font" not in support,
)
add_check(
    "No release-version token occurs in the active renderer",
    active_path.is_file() and not bool(re.search(r"(?i)\bvv\d+", active)),
)
add_check(
    "Fig. 5f shared legend is centred above the seven-panel strip",
    "bbox_to_anchor=(.5,1.18)" in active and "if k==3:" in active,
)
add_check(
    "Fig. 5f strip is narrowed and aligned to the paired panels above",
    "width_ratios=[.70,1,1,1,1,1,1,1,1.60]" in active,
)

fig2_pcm = read_csv_or_empty(
    QA / "fig2_pcm500_opportunity_audit.csv",
    ("candidate", "rank1_frequency"),
)
new_pcm = fig2_pcm.loc[
    fig2_pcm["candidate"].astype(str).str.contains("23.5-25.0-51.5", regex=False)
]
add_check(
    "Fig. 2e preserves the new 2025 chloride PCM500 opportunity",
    len(new_pcm) == 1
    and pd.to_numeric(new_pcm["rank1_frequency"], errors="coerce").between(.20, .25).all(),
)

fig3d = read_csv_or_empty(
    QA / "fig3d_candidate_service_thermal_margin_audit.csv",
    ("display_system", "service_id", "thermal_margin_C", "thermal_margin_status", "physical_window_pass", "service_domain_supported", "engineering_registry_linked", "formal_assessment_completed", "first_post_thermal_boundary"),
)
fig3d_resolved = fig3d["thermal_margin_status"].astype(str).eq("resolved") if len(fig3d) else pd.Series(dtype=bool)
fig3d_margin = pd.to_numeric(fig3d["thermal_margin_C"], errors="coerce") if len(fig3d) else pd.Series(dtype=float)
fig3d_physical = fig3d["physical_window_pass"].astype(str).str.lower().eq("true") if len(fig3d) else pd.Series(dtype=bool)
fig3d_hxln_sco2 = fig3d.loc[
    fig3d["display_system"].astype(str).str.contains("HXLN", case=False, na=False)
    & fig3d["service_id"].astype(str).eq("sco2_high_temperature_storage")
    & fig3d_resolved
] if len(fig3d) else pd.DataFrame()
add_check(
    "Fig. 3d reconstructs signed thermal headroom without conflating measured failure and missing upper boundaries",
    len(fig3d) == 28
    and fig3d["display_system"].nunique() == 4
    and fig3d["service_id"].nunique() == 7
    and int(fig3d_resolved.sum()) == 21
    and int(fig3d["thermal_margin_status"].astype(str).eq("upper_boundary_unreported").sum()) == 7
    and fig3d_margin.loc[fig3d_resolved].notna().all()
    and bool((fig3d_margin.loc[fig3d_resolved].abs() > 1e-9).all())
    and bool(((fig3d_margin.loc[fig3d_resolved] >= 0).to_numpy() == fig3d_physical.loc[fig3d_resolved].to_numpy()).all())
    and len(fig3d_hxln_sco2) == 1
    and pd.to_numeric(fig3d_hxln_sco2["thermal_margin_C"], errors="coerce").lt(0).all()
    and pd.to_numeric(fig3d["service_domain_supported"], errors="coerce").sum() == 1
    and pd.to_numeric(fig3d["engineering_registry_linked"], errors="coerce").sum() == 0
    and pd.to_numeric(fig3d["formal_assessment_completed"], errors="coerce").sum() == 0
    and fig3d["first_post_thermal_boundary"].notna().all(),
)

fig3d_nondup = read_csv_or_empty(
    QA / "fig3d_supplement_nonduplication_audit.csv",
    ("supplementary_figure", "supplementary_role", "fig3d_role", "shared_primary_metric", "duplicate_panel"),
)
add_check(
    "Fig. 3d has a unique primary metric and scientific role across all supplementary figures",
    len(fig3d_nondup) == 12
    and fig3d_nondup["supplementary_figure"].nunique() == 12
    and not bool(fig3d_nondup["shared_primary_metric"].astype(str).str.lower().eq("true").any())
    and not bool(fig3d_nondup["duplicate_panel"].astype(str).str.lower().eq("true").any()),
)
add_check(
    "Fig. 3d uses a distinct blue-hatched N/R state for unreported upper-stability evidence",
    "cmap.set_bad(PALE_BLUE)" in active
    and "axd.text(j,i,'N/R',ha='center',va='center',fontsize=4.15,fontweight='bold',color=NAVY)" in active,
)

fig3c = read_csv_or_empty(
    QA / "fig3c_evidence_response_audit.csv",
    ("minimum_no_selection", "maximum_no_selection", "transition_count"),
)
fig3c_range = pd.to_numeric(fig3c["maximum_no_selection"], errors="coerce") - pd.to_numeric(fig3c["minimum_no_selection"], errors="coerce")
add_check(
    "Fig. 3c exposes non-flat evidence-threshold decision cliffs",
    len(fig3c) == 3 and fig3c_range.notna().all() and bool((fig3c_range > .45).all()),
)

fig4a = read_csv_or_empty(
    QA / "fig4a_within_service_geometry_audit.csv",
    ("scenario", "system_id", "joint_valid_draws", "displayed_in_fig4a", "fig4a_role", "representative_credibility_score", "credibility_q05", "credibility_q95"),
)
fig4a_displayed = fig4a["displayed_in_fig4a"].astype(str).str.lower().eq("true") if len(fig4a) else pd.Series(dtype=bool)
comparative = fig4a.loc[fig4a["fig4a_role"].eq("comparative_service_facet")].copy() if len(fig4a) else pd.DataFrame()
singletons = fig4a.loc[fig4a["fig4a_role"].eq("singleton_scope_interval")].copy() if len(fig4a) else pd.DataFrame()
singleton_interval_ordered = False
if len(singletons) == 2:
    singleton_interval_ordered = bool(
        (pd.to_numeric(singletons["credibility_q05"], errors="coerce")
         <= pd.to_numeric(singletons["representative_credibility_score"], errors="coerce")).all()
        and (pd.to_numeric(singletons["representative_credibility_score"], errors="coerce")
             <= pd.to_numeric(singletons["credibility_q95"], errors="coerce")).all()
    )
add_check(
    "Fig. 4a separates comparative Pareto geometry from scope-only singleton evidence intervals",
    len(fig4a) == 19
    and bool(fig4a_displayed.all())
    and comparative["scenario"].nunique() == 5
    and bool(comparative.groupby("scenario").size().ge(2).all())
    and set(singletons["scenario"].astype(str)) == {"pcm_target_350C", "pcm_target_425C"}
    and singleton_interval_ordered,
)

fig4a_layout = read_csv_or_empty(
    QA / "fig4a_layout_alignment_audit.csv",
    ("panel", "x0", "y0", "x1", "y1", "width", "height"),
)
fig4_alignment = read_csv_or_empty(
    QA / "fig4_panel_alignment_audit.csv",
    ("check", "observed", "target", "absolute_difference", "tolerance", "passed"),
)
fig4a_layout_ok = False
if len(fig4a_layout) == 6 and set(fig4a_layout["panel"].astype(str)) == {
    "coal_top", "csp_top", "industrial_top", "sco2_bottom", "pcm500_bottom", "singleton_bottom"
}:
    fl = fig4a_layout.set_index("panel")
    heights = pd.to_numeric(fl["height"], errors="coerce")
    fig4a_layout_ok = bool(
        abs(float(fl.loc["coal_top", "x0"]) - float(fl.loc["sco2_bottom", "x0"])) < .002
        and abs(float(fl.loc["industrial_top", "x0"]) - float(fl.loc["singleton_bottom", "x0"])) < .002
        and heights.notna().all()
        and heights.max() / heights.min() < 1.02
        and np.allclose(pd.to_numeric(fl["width"], errors="coerce"), .260, atol=.002)
        and abs(
            (float(fl.loc["csp_top", "x0"]) - float(fl.loc["coal_top", "x1"]))
            - (float(fl.loc["industrial_top", "x0"]) - float(fl.loc["csp_top", "x1"]))
        ) < .002
        and .025 < (float(fl.loc["csp_top", "x0"]) - float(fl.loc["coal_top", "x1"])) < .050
        and len(fig4_alignment) == 10
        and fig4_alignment["passed"].astype(str).str.lower().eq("true").all()
        and float(fl.loc["coal_top", "y0"]) - float(fl.loc["sco2_bottom", "y1"]) < .05
    )
add_check("Fig. 4a outer axes align exactly with Fig. 4b-left and Fig. 4c-right", fig4a_layout_ok)

fig4a_labels = read_csv_or_empty(
    QA / "fig4a_label_collision_audit.csv",
    ("panel", "label_a", "label_b", "overlap_area_px2", "collision"),
)
fig4a_collision = fig4a_labels["collision"].astype(str).str.lower().eq("true") if len(fig4a_labels) else pd.Series(dtype=bool)
add_check(
    "Fig. 4a uses visible capped 5–95% error bars and has no within-facet label collisions",
    "ecolor=MID_GREY,elinewidth=.90,capsize=2.0,capthick=.75" in active
    and len(fig4a_labels) > 0
    and not bool(fig4a_collision.any()),
)

fig4_direct_bounds = read_csv_or_empty(
    QA / "fig4_direct_label_boundary_audit.csv",
    ("panel", "label", "inside_figure", "inside_parent_axes", "x0_px", "x1_px", "y0_px", "y1_px"),
)
fig4_direct_collisions = read_csv_or_empty(
    QA / "fig4_direct_label_collision_audit.csv",
    ("panel", "label_a", "label_b", "overlap_area_px2", "collision"),
)
add_check(
    "Fig. 4d shares the 4b–4c and 4e–4f outer anchors; all direct labels remain in-axis and collision-free",
    len(fig4_alignment) == 10
    and fig4_alignment["passed"].astype(str).str.lower().eq("true").all()
    and len(fig4_direct_bounds) > 0
    and fig4_direct_bounds["inside_figure"].astype(str).str.lower().eq("true").all()
    and fig4_direct_bounds["inside_parent_axes"].astype(str).str.lower().eq("true").all()
    and len(fig4_direct_collisions) > 0
    and not fig4_direct_collisions["collision"].astype(str).str.lower().eq("true").any(),
)

supp5_layout = read_csv_or_empty(
    QA / "supp5_coverage_label_layout_audit.csv",
    ("row", "label", "sphere_x", "coverage_before_sphere", "value_after_sphere", "coverage_inside_axes", "value_inside_axes", "same_row_overlap_area_px2", "same_row_collision"),
)
supp5_collisions = read_csv_or_empty(
    QA / "supp5_label_collision_audit.csv",
    ("kind_a", "row_a", "label_a", "kind_b", "row_b", "label_b", "overlap_area_px2", "collision"),
)
add_check(
    "Supplementary Fig. 5 places coverage before each sphere and overclaim values after it without label collisions",
    len(supp5_layout) == 14
    and supp5_layout["coverage_before_sphere"].astype(str).str.lower().eq("true").all()
    and supp5_layout["value_after_sphere"].astype(str).str.lower().eq("true").all()
    and supp5_layout["coverage_inside_axes"].astype(str).str.lower().eq("true").all()
    and supp5_layout["value_inside_axes"].astype(str).str.lower().eq("true").all()
    and not supp5_layout["same_row_collision"].astype(str).str.lower().eq("true").any()
    and len(supp5_collisions) > 0
    and not supp5_collisions["collision"].astype(str).str.lower().eq("true").any(),
)

supp11c_layout = read_csv_or_empty(
    QA / "supp11c_value_label_layout_audit.csv",
    ("row", "pair_label", "value", "label_below_sphere", "label_inside_axes", "x0_px", "x1_px", "y0_px", "y1_px"),
)
supp11c_collisions = read_csv_or_empty(
    QA / "supp11c_value_label_collision_audit.csv",
    ("row_a", "label_a", "row_b", "label_b", "overlap_area_px2", "collision"),
)
add_check(
    "Supplementary Fig. 11c places all exact synergy values below their spheres, inside the axis and collision-free",
    len(supp11c_layout) == 3
    and supp11c_layout["label_below_sphere"].astype(str).str.lower().eq("true").all()
    and supp11c_layout["label_inside_axes"].astype(str).str.lower().eq("true").all()
    and len(supp11c_collisions) > 0
    and not supp11c_collisions["collision"].astype(str).str.lower().eq("true").any(),
)

supp11d_layout = read_csv_or_empty(
    QA / "supp11d_value_label_layout_audit.csv",
    ("row", "scenario", "value", "display_label", "is_98_percent", "inward_placement", "label_clear_of_sphere", "label_inside_axes", "x0_px", "x1_px", "y0_px", "y1_px"),
)
supp11_panels = read_csv_or_empty(
    QA / "supp11_panel_layout_audit.csv",
    ("panel", "x0", "x1", "width", "y0", "y1", "height"),
)
supp11_panel_map = supp11_panels.set_index("panel") if len(supp11_panels) else pd.DataFrame()
supp11_width_ok = bool(
    len(supp11_panel_map)
    and {"11c", "11d"}.issubset(supp11_panel_map.index)
    and float(supp11_panel_map.loc["11d", "width"]) >= 1.45 * float(supp11_panel_map.loc["11c", "width"])
)
supp11_98 = supp11d_layout["is_98_percent"].astype(str).str.lower().eq("true") if len(supp11d_layout) else pd.Series(dtype=bool)
add_check(
    "Supplementary Fig. 11d is widened and the 98% endpoint badge remains inside the quantitative axis",
    supp11_width_ok
    and len(supp11d_layout) == 4
    and supp11d_layout["label_clear_of_sphere"].astype(str).str.lower().eq("true").all()
    and supp11d_layout["label_inside_axes"].astype(str).str.lower().eq("true").all()
    and int(supp11_98.sum()) == 1
    and supp11d_layout.loc[supp11_98, "inward_placement"].astype(str).str.lower().eq("true").all(),
)

fig3e = read_csv_or_empty(
    QA / "fig3e_populated_regime_archetypes.csv",
    ("regime_archetype", "service_count", "displayed_in_fig3e"),
)
fig3e_displayed = fig3e["displayed_in_fig3e"].astype(str).str.lower().eq("true") if len(fig3e) else pd.Series(dtype=bool)
add_check(
    "Fig. 3e displays populated archetypes only and omits the unobserved stable class",
    len(fig3e) == 4
    and bool(fig3e_displayed.all())
    and bool(pd.to_numeric(fig3e["service_count"], errors="coerce").gt(0).all())
    and "stable single regime" not in set(fig3e["regime_archetype"].astype(str)),
)

renderer_before_qa = active.split("def build_qa():", 1)[0]
pareto_badge_call = "value_badge(axe,float(r.pareto),i,str(int(r.pareto))"
add_check(
    "Fig. 4e contains only one Pareto breadth badge loop",
    renderer_before_qa.count(pareto_badge_call) == 1,
)


# ---------------------------------------------------------------------------
# Evidence-action DAG semantics
# ---------------------------------------------------------------------------
dag = read_csv_or_empty(
    TABLES / f"{STATISTICAL_VERSION}_evidence_action_dag_registry.csv",
    ("action_id", "prerequisite_dimensions"),
)
prerequisites = (
    dag.set_index("action_id")["prerequisite_dimensions"]
    .fillna("")
    .astype(str)
    .to_dict()
    if len(dag) and dag["action_id"].astype(str).is_unique
    else {}
)
dag_ok = (
    prerequisites.get("system_containment_qualification")
    == "corrosion_compatibility"
    and prerequisites.get("independent_replication") == "data_completeness"
    and prerequisites.get("long_duration_cycling") == ""
)
add_check("DAG prerequisite semantics match the implemented registry", dag_ok)


# ---------------------------------------------------------------------------
# Clean-package audit: project-owned files only
# ---------------------------------------------------------------------------
historical_artifacts: list[str] = []
version_pattern = re.compile(r"(?i)(?:^|[_-])v\d+(?:[_-]|$)")
allowed_current_version_prefixes = ("expanded_v3_", "expanded_library_v3_", "publication_package_v3_")
for path in project_owned_files(ROOT):
    relative = path.relative_to(ROOT)
    if version_pattern.search(path.name) and not path.name.lower().startswith(allowed_current_version_prefixes):
        historical_artifacts.append(str(relative))
historical_artifacts.sort()
add_check(
    "No version-numbered project artefact remains in the clean package",
    len(historical_artifacts) == 0,
)

python_hashes: dict[str, list[str]] = {}
for path in sorted((ROOT / "src").glob("*.py")):
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    python_hashes.setdefault(digest, []).append(path.name)
duplicate_python_groups = sorted(
    (sorted(group) for group in python_hashes.values() if len(group) > 1),
    key=lambda group: group[0],
)
add_check(
    "No duplicate Python source files by SHA-256",
    len(duplicate_python_groups) == 0,
)


# ---------------------------------------------------------------------------
# Write canonical validation outputs and fail closed
# ---------------------------------------------------------------------------
release_gate_frame = pd.DataFrame(checks, columns=["check", "passed"])
release_gate_frame.to_csv(QC / "postprocess_release_gate.csv", index=False)

status = "PASS" if bool(release_gate_frame["passed"].all()) else "FAIL"
output = {
    "status": status,
    "science_changed": "frozen upstream model/results unchanged; candidate-service thermal-headroom diagnostic added",
    "release_id": "TES-PUB-V10.1.0-MANUSCRIPT-AUDITED-20260816",
    "checks": int(len(release_gate_frame)),
    "checks_passed": int(release_gate_frame["passed"].sum()),
    "main_figures": 6,
    "supplementary_figures": 12,
    "active_renderer": "src/run_postprocess.py",
    "historical_artifacts": historical_artifacts,
    "duplicate_python_groups": duplicate_python_groups,
    "clean_scan_policy": (
        "Only project-owned files are scanned. Virtual environments, caches "
        "and site-packages are excluded before directory descent."
    ),
}

(QC / "postprocess_validation_status.json").write_text(
    json.dumps(output, indent=2, ensure_ascii=False),
    encoding="utf-8",
)
print(json.dumps(output, indent=2, ensure_ascii=False))

if status != "PASS":
    failed = release_gate_frame.loc[~release_gate_frame["passed"]]
    if len(failed):
        print(failed.to_string(index=False))
    sys.exit(2)
