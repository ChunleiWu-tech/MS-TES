
# Post-processing source contract — V10

The post-processing package does not contain an independent scientific data copy. Before rendering, `src/sync_upstream.py` requires:

- upstream release ID `TES-PUB-V10.1.0-MANUSCRIPT-AUDITED-20260816`;
- upstream 20,000-draw PASS;
- expanded-library 20,000-draw independent PASS;
- canonical upstream tables, QC, registered inputs and provenance.

A SHA-256 synchronization manifest is created locally after copying. The renderer and validator therefore consume one authoritative upstream release rather than manually maintained duplicate tables.
