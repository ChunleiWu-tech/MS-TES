
# Generated locally

This directory is intentionally empty in the distributed V10 package. `RUN_POSTPROCESS.bat` or `RUN_POSTPROCESS.sh` will synchronize the sibling upstream release and generate all figures, contact sheets, QC records and manifests here.
