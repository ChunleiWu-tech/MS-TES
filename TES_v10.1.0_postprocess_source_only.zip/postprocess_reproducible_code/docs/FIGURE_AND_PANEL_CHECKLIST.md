# figure and panel checklist

## Main figures

### Figure 1 | Two-universe evidence architecture and gate-specific retention
- **1a** Separate official-screen and application-library count lanes; denominators are not pooled.
- **1b** Evidence provenance alluvial: evidence streams to chemistry families.
- **1c** Family-resolved property coverage across 142 exact candidates.
- **1d** Claim-boundary map: evidence score across database-validated, exact-measured, commercial-benchmark and derived/predicted classes.
- **1e** Gate-specific conditional retention: 76/994 physical (7.6%) → 18/76 quantitative (23.7%) → 11/18 service-domain supported (61.1%) → 8/11 linked to the frozen engineering registry (72.7%).

### Figure 2 | Cross-layer rank reversal and new-salt counterexample
- **2a** Physical, quantitative and temperature-domain pair counts by service.
- **2b** Complete seven-service scalar → service-domain → formal trajectories; this panel audits transitions, whereas 2c and 2d retain the distributions.
- **2c** Temperature-domain rank-1 frequencies.
- **2d** Formal outcome composition with no-selection treated as an outcome.
- **2e** PCM500 opportunity: new 2025 chloride at 23.48% thermophysical rank-1 frequency; formal assessment is pending outside the frozen registry.

### Figure 3 | Gradient regimes and application-dependent switching
- **3a** Stacked shares of robust, conditional and no-bounded-access states across all services.
- **3b** Coverage-threshold no-selection response for Coal, CSP and Industrial heat.
- **3c** Full evidence-threshold response exposing the decision cliff.
- **3d** Candidate-service signed thermal-headroom matrix with exact °C margins and the first post-thermal evidence boundary; non-negative cells are thermally admissible and blue-hatched N/R cells mark an unreported upper stability boundary.
- **3e** Service-level regime archetype matrix; only populated archetypes are shown, so no empty stable class is implied.

### Figure 4 | Uncertainty-aware Pareto structure
- **4a** Five multi-candidate performance–evidence maps plus a matched evidence-readiness interval panel for the two singleton services; the singleton panel is scope-only and makes no Pareto claim.
- **4b** Bootstrap Pareto-membership frequency forest.
- **4c** Dominance-mechanism matrix.
- **4d** Full-width ≥50% Pareto-membership, decision-ready-evidence and ≥1%-formal-selection intersections.
- **4e** Cross-service ≥50% Pareto-membership and formal-selection breadth.
- **4f** Retained, redirected and no-selection strict-layer transition shares.

### Figure 5 | Uncertainty-source attribution and structural bottlenecks
- **5a** TES service to decision-uncertainty structure alluvial.
- **5b** Continuous decision-margin Shapley variance attribution.
- **5c** Categorical selected-state Shapley information attribution.
- **5d** Service coverage lost to registered property domains.
- **5e** Atomic evidence unlock contribution.
- **5f** Seven service-specific evidence-closure-depth responses.
- **5g** Pearson–Spearman performance–evidence dependence and near-zero inset.

### Figure 6 | Decision-boundary back-tracing and evidence priorities
- **6a** Current state → precedence-valid action → endpoint alluvial.
- **6b** Complete minimum admissible action-set matrix for scientifically evaluable candidate–service pairs.
- **6c** Registered action decision-benefit forest.
- **6d** Ordinal evidence burden versus decision benefit.
- **6e** Candidate selection-frequency redistribution for |Δ| ≥1%.
- **6f** Service-level research-priority and stopping-rule composition.

## Supplementary figures

### Supplementary Figure 1 | Complete full-library evidence audit
- **S1a** Exact-candidate counts for all chemistry families.
- **S1b** Complete family-by-property coverage matrix.
- **S1c** Independent-source density versus property-record density for all 142 candidates.
- **S1d** Explicit material-boundary disposition.

### Supplementary Figure 2 | Provenance linkage and atomic credibility
- **S2a** Candidate database/provenance match lollipop with numerical match badges.
- **S2b** Candidate atomic-credibility heatmap.

### Supplementary Figure 3 | Unique thermophysical profiles
- **S3** Column-normalized deterministic thermophysical profile heatmap after exact-duplicate collapse.

### Supplementary Figure 4 | Pairwise performance and material-cost boundary
- **S4a** Pairwise energy-density superiority probabilities with endpoint badges.
- **S4b** Conditional raw-material-cost 5–95% forest with median badges.

### Supplementary Figure 5 | Complete-service overclaim penalty
- **S5** Partial-overlap energy-overclaim lollipop with overclaim and coverage annotations.

### Supplementary Figure 6 | Threshold sensitivity and convergence
- **S6a** Full seven-service 630-state coverage–evidence regime registry.
- **S6b** Evidence-threshold response of expected strict-complete candidate count.
- **S6c** Independent Monte Carlo convergence of modal-frequency error.

### Supplementary Figure 7 | Atomic evidence interval profiles
- **S7a** Corrosion credibility intervals.
- **S7b** Cycling/phase credibility intervals.
- **S7c** Containment credibility intervals.

### Supplementary Figure 8 | Omission sensitivity
- **S8a** Candidate-omission decisiveness scatter.
- **S8b** Exact source-omission outcome-group heatmap.

### Supplementary Figure 9 | Credibility shortfall and model sensitivity
- **S9a** Unique credibility-shortfall profile heatmap.
- **S9b** Registered null audit across 14 credibility-model–service contrasts.

### Supplementary Figure 10 | Readiness and candidate archetypes
- **S10a** Deduplicated readiness profiles.
- **S10b** PCM strict-complete probabilities.
- **S10c** Bounded-candidate multiplicity.
- **S10d** Exploratory candidate archetype clusters.

### Supplementary Figure 11 | Complementary evidence-action diagnostics
- **S11a** Registered evidence-action ordinal burden.
- **S11b** Action-to-evidence-dimension closure matrix.
- **S11c** Non-zero gate-pair interaction diagnostics.
- **S11d** Programme non-additivity and complementarity.
- **S11e** Favourable, adverse and interpretation-boundary outcome registry.

### Supplementary Figure 12 | Model-upgrade validation and value-function audit
- **S12a** Formula-system grouped versus random-record validation performance.
- **S12b** Independently evaluated split-conformal coverage and interval width.
- **S12c** Candidate-level applicability-domain disposition with unseen-element blocking.
- **S12d** Benchmark-anchored versus within-draw min–max selection frequencies and IIA audit.


## Global submission typography and layout checks
- Legends requested above axes are single-row and outside data fields.
- Obsolete legend reserve space is removed.
- Lollipop/forest endpoints use consistent numerical badges where scientifically useful.
- Chemical formulae and units use mathtext subscripts/superscripts, including sCO$_2$, MgCl$_2$, kWh m$^{-3}$ and kWh$_{th}^{-1}$.
- Structurally flat or repeated services are compressed rather than redrawn.
- Main and supplementary figures answer distinct questions; full-detail scans remain supplementary.
- Registered DAG semantics are explicit: containment qualification requires corrosion compatibility; independent replication requires data completeness; atomic cycling can begin independently within a defensible service window.
