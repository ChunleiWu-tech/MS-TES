# scientific storyline

Two non-interchangeable evidence universes → 142 exact candidates and 994 candidate–service pairs → physical and service-domain contraction → evidence-bounded formal decisions → threshold cliffs and non-compensatory Pareto structure → uncertainty attribution → precedence-constrained experiments.

The full-library upgrade changes the opportunity layer, not the formal evidence rule. A newly documented 2025 NaCl–KCl–CaCl2 composition acquires a 23.48% PCM500 thermophysical rank-1 frequency in the service-domain-supported opportunity layer. It lies outside the frozen 15-candidate engineering registry, so no formal selection or formal-failure outcome is assigned; corrosion and long-cycle evidence remain unresolved. Within the frozen engineering registry, commercial benchmarks retain formal comparability because their evidence chains are more continuous; this is not a claim of universal thermophysical superiority.
