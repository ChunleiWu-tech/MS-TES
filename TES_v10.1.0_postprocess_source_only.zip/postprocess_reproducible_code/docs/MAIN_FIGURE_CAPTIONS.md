# main figures

## Fig. 1 — Two-universe evidence architecture and gate-specific retention
**a**, separate official-screen and application-library count lanes. **b**, evidence-stream to chemistry-family alluvial. **c**, property coverage across the ten largest exact-composition families. **d**, registered engineering-evidence score by claim class. **e**, gate-specific conditional retention after the 142-candidate by seven-service expansion, with the denominator at every gate stated explicitly.

## Fig. 2 — Cross-layer rank reversal and the new-salt counterexample
**a**, physical, quantitative and service-domain-supported pair counts by service. **b**, complete seven-service trajectories from scalar-property leader to service-domain-supported leader and formal outcome; percentages give the leading outcome at each layer and burgundy connectors identify layer transitions. **c**, service-domain-supported rank-1 frequencies for every non-negligible candidate. **d**, formal evidence-bounded outcome composition, including explicit no-selection states. **e**, PCM500 comparison showing a 23.48% thermophysical opportunity for the new 2025 NaCl–KCl–CaCl₂ composition while formal assessment remains outside the frozen registry.

## Fig. 3 — Evidence thresholds and traceable new-candidate exclusion
**a**, compact stacked shares of all registered coverage–evidence states. **b**, coverage-threshold response for the three non-degenerate services. **c**, full evidence-threshold no-selection response exposing the 0.75–0.85 decision cliff. **d**, candidate-service signed thermal-headroom matrix for the four newly added exact compositions, with exact °C margins and the first post-thermal evidence boundary; non-negative values are thermally admissible and blue-hatched N/R cells denote an unreported upper stability boundary. **e**, service-level regime archetypes; structurally flat services are compressed rather than repeated.

## Fig. 4 — No universal salt: uncertainty-aware non-compensatory Pareto structure
**a**, five service-faceted representative performance–evidence maps with marginal 5–95% draw ranges; PCM350 and PCM425 are omitted from geometric comparison because each has only one evaluable candidate. **b**, bootstrap Pareto-membership forest. **c**, dominance-mechanism matrix. **d**, full-width intersections of ≥50% Pareto membership, decision-ready evidence and ≥1% formal selection. **e**, cross-service ≥50% Pareto-membership and formal-selection breadth. **f**, strict-layer transition summary.

## Fig. 5 — Uncertainty-source attribution and structural bottlenecks
**a**, service-to-uncertainty-structure alluvial. **b**, continuous-margin Shapley variance shares. **c**, categorical-state Shapley information shares. **d**, property-domain coverage losses with endpoint badges. **e**, atomic evidence unlock contributions with endpoint badges. **f**, seven service-specific evidence-closure-depth responses showing the median retained frequency and registered minimum–maximum range. **g**, performance–evidence dependence with the PCM500 label displaced from the data point.

## Fig. 6 — Decision-boundary back-tracing and evidence investment priorities
**a**, precedence-valid state–action–endpoint alluvial. **b**, complete minimum admissible action-set matrix for scientifically evaluable candidate–service pairs. **c**, compact action-benefit forest with shortened action labels, widened x range and endpoint badges inside the axis. **d**, ordinal burden–gain map. **e**, candidate selection-frequency redistribution for registered effects with |Δ| ≥1%. **f**, service-level research-priority and stopping-rule summary.
