
# V10 figure story and release semantics

## Main figures

1. **Figure 1 — Evidence objects and gate-specific retention.** Separates official reference records from the bounded application library and reports 76/994 physical pairs, 18/76 quantitative pairs, 11/18 service-domain-supported pairs and 8/11 links to the frozen engineering registry.
2. **Figure 2 — Cross-layer rank changes and the new-salt counterexample.** Reports thermophysical opportunity separately from formal registry outcomes. The 2025 NaCl-KCl-CaCl₂ PCM500 candidate has a 23.48% rank-one opportunity frequency but no assigned formal outcome outside the registry.
3. **Figure 3 — Decision regimes and stopping gates.** Distinguishes coverage, atomic evidence and registry linkage; explicit zeros appear only for gates actually evaluated.
4. **Figure 4 — Uncertainty-aware Pareto structure.** Separates performance opportunity, decision-ready evidence and formal selection.
5. **Figure 5 — Uncertainty attribution and structural bottlenecks.** Reports continuous and categorical attribution without treating evidence gaps as compensable performance penalties.
6. **Figure 6 — Decision-boundary back-tracing and experiment priorities.** Converts registered gaps into precedence-valid actions and stopping rules.

## Supplementary figures

Supplementary Figures 1–12 provide the complete library audit, provenance and credibility matrices, unique thermophysical profiles, cost boundaries, overclaim penalties, threshold/convergence diagnostics, atomic evidence profiles, omission sensitivity, model sensitivity, readiness archetypes, evidence-action diagnostics, and the candidate-invariant/ML applicability audit.

## Mandatory terminology

- Use **thermophysical opportunity frequency** for the expanded 142-candidate screen.
- Use **formal selection frequency** only for candidates inside the frozen 15-candidate engineering registry.
- Use **no formal selection** for a registered service draw with no qualified candidate.
- Use **formal outcome not assigned outside the frozen registry** for external candidates.
- Tier A and Tier B are service-domain support classes, not engineering qualification levels.
