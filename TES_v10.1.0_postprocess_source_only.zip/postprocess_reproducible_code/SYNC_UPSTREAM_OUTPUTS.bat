@echo off
setlocal
cd /d "%~dp0"
if "%TES_PYTHON%"=="" set "TES_PYTHON=%CD%\.venv\Scripts\python.exe"
if not exist "%TES_PYTHON%" (echo Run SETUP_ENV.bat first, or set TES_PYTHON.& exit /b 2)
"%TES_PYTHON%" -X faulthandler -u src\sync_upstream.py "%~1"
exit /b %ERRORLEVEL%
