
# Data licensing boundary

Project-authored derived tables, evidence classifications and machine-readable audit records may be reused under Creative Commons Attribution 4.0, subject to citation of this release and the underlying sources.

This permission does not override rights in third-party databases, publisher content, source articles, reports, trademarks or raw materials. Third-party source identity and locators are provided for provenance and verification. Users are responsible for obtaining any source material under the applicable licence or access conditions.
